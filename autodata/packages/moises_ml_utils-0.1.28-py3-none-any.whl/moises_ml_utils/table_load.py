import pandas as pd
from google.cloud import bigquery, storage
from musicdata.etl.validators import kind_validators
from collections import defaultdict
from moises_ml_utils.utils import get_bq_client, get_sa_credentials_from_secret, generate_signed_url, upload_dataframe_to_gcs
from musicdata.annotations.validators import KindRegistry, StemTypeRegistry
from musicdata.annotations import StemTypesSchema
from musicdata.db.models import AnnotationKind, Standard, AnnotationSource
from jsonschema import Draft202012Validator, ValidationError as JsonSchemaValidationError
from uuid import UUID
import json
from loguru import logger

class VerificationError(Exception):
    """Raised when there's a configuration issue."""
    pass

class TableLoad:

    def __init__(self):

        self.columns_types = {'file_id': {'type': str}, 'song_id': {'type': str}, 'path': {'type': str}, 
                              'dataset': {'type': str}, 'creation_method': {'type': str},
                              'predicted_leak': {'type': bool}, 'has_leaks': {'type': bool}, 
                              'stem_names': {'type': list, 'item_type': str}, 'predicted_tags': {'type': list, 'item_type': str}}
        
        self.base_columns = list(self.columns_types.keys())
        self.client = get_bq_client('moises-ds-data')

        query_annotation_kinds = "SELECT * FROM data_catalog.annotation_kinds WHERE kind NOT IN ('file_data', 'media_metadata') AND active is true"
        df_annotation_kinds = self.client.query(query_annotation_kinds).to_dataframe()

        self.possible_columns = self.base_columns.copy()
        self.annotation_columns = list(df_annotation_kinds['kind'])

        annotation_kinds_col_types = {key: {'type': str} for key in self.annotation_columns}
        self.columns_types.update(annotation_kinds_col_types)

        self.possible_columns.extend(self.annotation_columns)

        self.df_schema = df_annotation_kinds[['kind', 'json_schema', 'constraints', 'id', 'revision']].set_index('kind')

        self.errors = []

        try:
            for kind, row in self.df_schema.iterrows():
                # Parse JSON fields if they're strings
                constraints = row.get('constraints')
                if isinstance(constraints, str) and constraints:
                    constraints = json.loads(constraints)
                elif pd.isna(constraints):
                    constraints = None

                if constraints and isinstance(constraints, dict):
                    # If the structure is {"constraints": {"tags": [...]}, "kind": "..."}
                    # Extract just the inner constraints part
                    if "constraints" in constraints:
                        constraints = constraints["constraints"]
                
                json_schema = row.get('json_schema')
                if isinstance(json_schema, str):
                    json_schema = json.loads(json_schema)
                
                # Create AnnotationKind object - only required fields: id, kind, revision, json_schema
                kind_obj = AnnotationKind(
                    id=UUID(row['id']) if isinstance(row['id'], str) else row['id'],
                    kind=kind,  # This is AnnotationKindType (string enum)
                    revision=int(row['revision']),
                    json_schema=json_schema,
                    constraints=constraints  # Optional
                )
                
                # Register in the cache
                KindRegistry._register_kind(kind_obj)
            
            # Mark cache as populated
            KindRegistry._cache_populated = True
            
            logger.info(f"Successfully populated KindRegistry cache with {len(df_annotation_kinds)} kinds from BigQuery")
        except Exception as e:
            logger.error(f"Failed to populate KindRegistry cache from BigQuery: {e}")


    def _check_if_table_exists(self, table_id, should_exist):
        try:
            table = self.client.get_table(table_id)
            if should_exist:
                return table
            else:
                self.errors.append({
                    'check': 'table_existence',
                    'error_type': 'table_already_exists',
                    'message': f"Trying to create new table, but table already exists.",
                    'details': f"table_id: {table_id}"
                })
        except Exception:
            if should_exist:
                self.errors.append({
                    'check': 'table_existence',
                    'error_type': 'table_not_found',
                    'message': f"Trying to append to {table_id}, but table does not exist.",
                    'details': f"table_id: {table_id}"
                })


    def _check_existing_table_column_names(self, table, columns):
        columns_table = [field.name for field in table.schema]

        if sorted(columns) != sorted(columns_table):
            missing = set(columns_table) - set(columns)
            extra = set(columns) - set(columns_table)
            
            error_msg = "Columns in DataFrame do not match the table."
            if missing:
                error_msg += f"\n  Missing columns: {sorted(missing)}"
            if extra:
                error_msg += f"\n  Extra columns: {sorted(extra)}"
            
            details = f"expected: {sorted(columns_table)}, actual: {sorted(columns)}"
            
            self.errors.append({
                'check': 'existing_table_columns',
                'error_type': 'column_mismatch',
                'message': error_msg,
                'details': details
            })


    def _check_new_table_column_names(self, columns):
        
        error_cols = [col for col in columns if col not in self.possible_columns]
        if len(error_cols):
            error_msg = "Invalid columns present in Dataframe."
            error_msg += f"\n Invalid columns: {sorted(error_cols)}"

            self.errors.append({
                'check': 'new_table_columns',
                'error_type': 'invalid_columns',
                'message': error_msg,
                'details': f"valid_columns: {self.possible_columns}"
            })

    def _check_columns_present_and_not_null(self, df, required_columns, prohibited_columns):
        
        df_cols = list(df.columns)
        problems = {'missing': [], 'prohibited': [], 'null_values': [], 'other': []}

        if prohibited_columns:
            present_prohibited = list(set(df_cols) & set(prohibited_columns))
            problems['prohibited'] = present_prohibited

        if 'predicted_leak' in df_cols and 'has_leaks' in df_cols:
            problems['other'].append('There is more than one column specifying leaks')

        if 'predicted_tags' in df_cols and 'stem_names' in df_cols:
            problems['other'].append('There is more than one column specifying stem_types')
        
        has_leak_column = 'predicted_leak' in df_cols or 'has_leaks' in df_cols
        has_no_stem_column = (
            'stem_names' not in df_cols and 
            'predicted_tags' not in df_cols and 
            'stem_types' not in df_cols
        )
        if has_leak_column and has_no_stem_column:
            problems['other'].append('You cannot specify leaks without specifying stem types')

        for col in required_columns:
            if col == 'annotation':
                present_annotations = set(df_cols) & set(self.annotation_columns)
                if not present_annotations:
                    problems['other'].append('An annotation column should be present in the DataFrame')
                continue
            elif type(col) == str and col not in df_cols:
                problems['missing'].append(col)
                continue
            elif type(col) == tuple:
                present_annotations = set(df_cols) & set(col)

                if not len(present_annotations):
                    problems['missing'].append('stem_names')
                    continue
                elif len(present_annotations) > 1:
                    problems['other'].append('There is more than one column specifying the stem names')
                    continue
                
                column_name_on_df = list(present_annotations)[0]
            else:
                column_name_on_df = col

            if df[column_name_on_df].isnull().any():
                problems['null_values'].append(column_name_on_df)

        # Aggregate and report problems similarly to _check_new_table_column_names
        if any(problems.values()):
            error_msg = "Issues found with required columns."
            if problems['missing']:
                error_msg += f"\n Missing columns: {sorted(problems['missing'])}"
            if problems['prohibited']:
                error_msg += f"\n Prohibited columns for this type of data load present: {sorted(problems['prohibited'])}"
            if problems['null_values']:
                error_msg += f"\n Columns containing null values: {sorted(problems['null_values'])}"
            if problems['other']:
                error_msg += f"\n Other problems: {problems['other']}"

            details = f"required_columns: {required_columns}"
            
            self.errors.append({
                'check': 'required_columns',
                'error_type': 'column_validation_failed',
                'message': error_msg,
                'details': details
            })


    def _check_unique_itself_and_catalog(self, df, columns, already_on_catalog=True):

        problems = {'in_column': [], 'in_catalog': []}
        for col in columns:
            if col not in df.columns:
                continue

            # Song id should only be unique when adding songs without files
            if not df[col].is_unique and (col != 'song_id' or (col == 'song_id' and self.new_songs and not self.new_files)):
                problems['in_column'].append(col)

            ids = df[col].dropna().unique().tolist()

            table = 'files' if col == 'file_id' else 'songs'
            if already_on_catalog:
                query = f"""
                    WITH input_ids AS (
                        SELECT id FROM UNNEST(@ids) AS id
                    )
                    SELECT id
                    FROM input_ids
                    WHERE id NOT IN (
                        SELECT id
                        FROM `moises-ds-data.raw_ds_catalog_psql_stream.public_{table}`
                    )
                    """
            else:
                query = f"""
                    SELECT id
                    FROM `moises-ds-data.raw_ds_catalog_psql_stream.public_{table}`
                    WHERE id IN UNNEST(@ids)
                    """
            
            job_config = bigquery.QueryJobConfig(
                query_parameters=[
                    bigquery.ArrayQueryParameter("ids", "STRING", ids)
                ]
            )

            existing_ids = self.client.query(query, job_config=job_config).to_dataframe()
            if not existing_ids.empty:
                problems['in_catalog'].append(col)

        if any(problems.values()):
            error_msg = "ID uniqueness validation failed:"
            if problems['in_column']:
                error_msg += f"\n  Duplicate IDs in columns: {problems['in_column']}"
            if problems['in_catalog']:
                msg_complement = 'do not' if already_on_catalog else 'already'
                error_msg += f"\n  IDs {msg_complement} exist in catalog for columns: {problems['in_catalog']}"
            
            details = f"already_on_catalog: {already_on_catalog}, checked_columns: {columns}"
            self.errors.append({
                'check': 'id_uniqueness',
                'error_type': 'uniqueness_validation_failed',
                'message': error_msg,
                'details': details
            })

    def _check_master_mix_correct_annotation(self, df):

        def valid_stem_pattern(stem_list):
            if (('Master' in stem_list) or ('Mix' in stem_list)) and (len(stem_list) > 1):
                return False
            else:
                return True
        
        stem_column_set = set(list(df.columns)) & set(['stem_names', 'predicted_tags'])
        if not len(stem_column_set):
            return
        
        stem_col = list(stem_column_set)[0]
        stem_validity = df[stem_col].apply(valid_stem_pattern)

        if not stem_validity.all():
            self.errors.append({
                'check': 'master_mix_annotation',
                'error_type': 'invalid_stem_combination',
                'message': 'Please ensure that the stem annotations for Master or Mix do not contain other stems.',
                'details': f"stem_column: {stem_col}"
            })


    def _check_content_types(self, df):
        
        type_mismatch_cols = []
        type_details = []
        
        for col in df.columns:
            col_type = self.columns_types[col]['type']
            if col_type == str and not pd.api.types.is_string_dtype(df[col].dropna()):
                type_mismatch_cols.append(col)
                type_details.append(f"{col}: expected {col_type}")

            elif col_type == bool:
                cleaned = df[col].dropna()
                unique_vals = set(cleaned.unique())
                if not unique_vals.issubset({True, False}):
                    type_mismatch_cols.append(col)
                    type_details.append(f"{col}: expected {col_type}")

            elif col_type == list:
                col_values = df[col].dropna()
                # Check if all values are lists
                if not col_values.apply(lambda x: isinstance(x, list)).all():
                    type_mismatch_cols.append(col)
                    type_details.append(f"{col}: expected {col_type}")

                # Check item_type and no None values in lists
                else:
                    item_type = self.columns_types[col]['item_type']
                    valid = col_values.apply(
                        lambda lst: all(isinstance(item, item_type) for item in lst)
                    ).all()
                    if not valid:
                        type_mismatch_cols.append(col)
                        type_details.append(f"{col}: expected {col_type}[{item_type}]")

        if type_mismatch_cols:            
            self.errors.append({
                'check': 'content_types',
                'error_type': 'type_mismatch',
                'message': 'Columns:\n' + ' | '.join(type_mismatch_cols) + ' not following the defined type.\nPlease ensure all columns match their defined types.',
                'details': ', '.join(type_details)
            })


    def _check_schema_and_constraints(self, df):
        
        present_annotations = list(set(df.columns) & set(self.annotation_columns))
        stem_annotations = ['stem_names', 'predicted_tags']

        validation_errors = defaultdict(list)

        for stem_col in stem_annotations:
            if stem_col not in df.columns:
                continue

            validator = kind_validators.get_validator_for_kind('stem_types')
            
            for idx, value in enumerate(list(df[stem_col])):
                try:
                    stem_ids = StemTypeRegistry.map_names_to_ids(value)
                    annotation_value = StemTypesSchema(stem_types=list(stem_ids))

                except Exception as e:
                    validation_errors[stem_col].append({
                        'row_index': idx,
                        'error': str(e)
                    })

        for annot in present_annotations:
            validator = kind_validators.get_validator_for_kind(annot, available_columns=list(df.columns))
            valid_rows = df[df[annot].notna()]

            try:
                valid_rows[annot] = valid_rows[annot].apply(json.loads)
            except Exception as e:
                validation_errors[annot].append({
                'row_index': 'undefined',
                'error': f'JSON parsing failed: {str(e)}'
                })
                continue
            
            for row in valid_rows.itertuples():
                try:
                    row_dict = row._asdict()
                    annotation = validator.create_annotation_model(row_dict)
                    final_annotation = annotation.model_dump()
                    
                    if row_dict[annot] != final_annotation:
                        validation_errors[annot].append({
                            'row_index': idx,
                            'error': f'{row_dict[annot]} not allowed, expected {final_annotation if final_annotation else None}'
                        })

                except Exception as e:
                    validation_errors[annot].append({
                        'row_index': idx,
                        'error': str(e)
                    })
                    
        
        if validation_errors:
            error_msg = "Schema validation failed for annotation columns:"
            details_parts = []
            
            for annot, errors in validation_errors.items():
                error_count = len(errors)
                error_msg += f"\n  {annot}: {error_count} validation error(s)"
                
                # Include ALL errors in both message and details
                all_error_details = [f"row {err['row_index']}: {err['error']}" for err in errors]
                details_parts.append("; \n".join(all_error_details))

            self.errors.append({
                'check': 'schema_validation',
                'error_type': 'schema_constraint_violation',
                'message': error_msg,
                'details': ' | \n\n'.join(details_parts)
            })

    def _check_annotation_and_stem_type_match_no_files(self, df):
        
        none_possible = ['transcription', 'guitar_chord']
        present_annotations = set(list(df.columns)) & set(self.annotation_columns)
        if not len(present_annotations):
            return

        columns_with_incorrect_mapping = []

        for annotation in list(present_annotations):
            if annotation not in none_possible:
                columns_with_incorrect_mapping.append(annotation)
        
        if columns_with_incorrect_mapping:
            self.errors.append({
                'check': 'annotation_stem_type_match',
                'error_type': 'incorrect_stem_type_mapping',
                'message': 'Columns:\n ' + ' | '.join(columns_with_incorrect_mapping) + 
                ' are not allowed to be associated with songs without files.\nPlease ensure all annotations are valid for this load type.'
            })


    def _check_annotation_and_stem_type_match_files(self, df):

        only_master_or_mix = ['beat', 'chord', 'segment', 'meter', 'key', 'tempo', 'genre', 'mood', 'era', 'predicted_segment']
        vocals_possible = ['transcription', 'predicted_transcription']

        present_annotations = set(list(df.columns)) & set(self.annotation_columns)
        if not len(present_annotations):
            return

        present_stem_types = set(list(df.columns)) & set(['stem_names', 'predicted_tags'])

        if len(present_stem_types):
            st_col = list(present_stem_types)[0]
            merged_df = df.copy(deep=True)
        else:
            st_col = 'stem_names'
            file_ids = df['file_id'].dropna().unique().tolist()
    
            query = f"""
                    SELECT file_id, stems_arr as stem_names
                    FROM `moises-ds-data.data_catalog.stem_types_annotations`
                    WHERE file_id IN UNNEST(@ids)
                    """
            
            job_config = bigquery.QueryJobConfig(
                query_parameters=[
                    bigquery.ArrayQueryParameter("ids", "STRING", file_ids)
                ]
            )
            stems_df = self.client.query(query, job_config=job_config).to_dataframe()
            merged_df = pd.merge(df, stems_df, on='file_id')
        
        # Get all possible Vocals instruments
        if len(list(set(list(df.columns)) & set(vocals_possible))):
            query = '''SELECT child FROM `moises-ds-data.data_catalog.stem_types_tree` where root = 'Vocals' and child is not null'''

            vocal_instruments = ['Vocals']
            vocal_instruments.extend(list(self.client.query(query).to_dataframe()['child']))

        columns_with_incorrect_mapping = []
        incorrect_details = []

        for annotation in list(present_annotations):
            if annotation not in only_master_or_mix and annotation not in vocals_possible:
                continue

            possible_values = ['Mix', 'Master']
            if annotation in vocals_possible:
                possible_values.extend(vocal_instruments)
            
            stem_values = merged_df[merged_df[annotation].notna()][st_col].apply(lambda x: x[0])
            if not stem_values.isin(possible_values).all():
                columns_with_incorrect_mapping.append(annotation)
                incorrect_details.append(f"{annotation}: allowed stems {possible_values}")
        
        if columns_with_incorrect_mapping:
            self.errors.append({
                'check': 'annotation_stem_type_match',
                'error_type': 'incorrect_stem_type_mapping',
                'message': 'Columns:\n' + ' | '.join(columns_with_incorrect_mapping) + 
                ' not associated to the appropriate stem types.\nPlease ensure all annotations are only associated to the corresponding stem types.',
                'details': ', '.join(incorrect_details)
            })

    def _raise_error_and_upload(self):

        print("\nERRORS DETECTED:")
        # Print only first 10 errors for console
        for error in self.errors:
            print(f"\n[{error['check']}] {error['error_type']}:")
            print(f"  {error['message']}")

            if ';' in error['details']:
                details_truncated = error['details'].split(';')
                print(';  '.join(details_truncated[:10]))
                if len(details_truncated) > 10:
                    print(f"\n... and {len(details_truncated) - 10} more error(s). See GCS file for complete details.")
            else:
                print(f"  {error['details']}")
            print('\n')


        # Upload ALL errors to GCS
        df_errors = pd.DataFrame(self.errors)
        file_path = upload_dataframe_to_gcs(df_errors, folder_error_name='load-dataframe_checks', bucket_name='data_load_errors', project_id='machine-learning')

        gcs_console_url = f"https://console.cloud.google.com/storage/browser/_details/data_load_errors/{file_path}?project=moises-machine-learning"
        raise VerificationError(f"Errors detected on dataframe verification: {gcs_console_url}")

    def upload_table(self, df):

        table_ref = self.client.dataset(self.bq_table_id.split('.')[0]).table(self.bq_table_id.split('.')[1])

        job_config = bigquery.LoadJobConfig(
            write_disposition=f"WRITE_{self.write_type}",
            autodetect=True
        )

        job = self.client.load_table_from_dataframe(
            df,
            table_ref,
            job_config=job_config
        )

        job.result()
        print(f"✅ Table '{self.bq_table_id}' created with {job.output_rows} rows.")


    def verify_table(self, df, bq_table_id, write_type='EMPTY', new_files=False, new_songs=False):

        self.errors = []

        self.new_files = new_files
        self.new_songs = new_songs

        if not len(df) or not isinstance(df, pd.DataFrame):
            raise VerificationError('DataFrame is invalid.')

        if write_type not in ('APPEND', 'EMPTY'):
            self.errors.append({
                'check': 'write_type_validation',
                'error_type': 'invalid_write_type',
                'message': f"Invalid write type: {write_type}. Please use either APPEND or EMPTY.",
                'details': f"provided: {write_type}, allowed: ['APPEND', 'EMPTY']",
            })
        elif write_type == 'APPEND':
            table = self._check_if_table_exists(bq_table_id, should_exist=True)
            self._check_existing_table_column_names(table, list(df.columns))
        else:
            self._check_if_table_exists(bq_table_id, should_exist=False)
            self._check_new_table_column_names(list(df.columns))


        verify_file_data, new_song_verification = False, False
        if new_files and new_songs:
            # New files and new songs
            self._check_columns_present_and_not_null(df, ['file_id', 'song_id', 'path', 'dataset', ('stem_names', 'predicted_tags')], '')
            self._check_unique_itself_and_catalog(df, ['file_id', 'song_id'], already_on_catalog=False)
            verify_file_data, new_song_verification = True, True
        elif new_files:
            # New files on existing songs
            self._check_columns_present_and_not_null(df, ['file_id', 'song_id', 'path', ('stem_names', 'predicted_tags')], '')
            self._check_unique_itself_and_catalog(df, ['file_id'], already_on_catalog=False)
            self._check_unique_itself_and_catalog(df, ['song_id'], already_on_catalog=True)
            verify_file_data = True
        elif new_songs:
            # New songs with no files
            self._check_columns_present_and_not_null(df, ['song_id', 'dataset', 'annotation'], ['file_id', 'path'])
            self._check_unique_itself_and_catalog(df, ['song_id'], already_on_catalog=False)
        else:
            # New annotations on existing files and songs
            self._check_columns_present_and_not_null(df, ['file_id', 'annotation'], '')
            self._check_unique_itself_and_catalog(df, ['file_id'], already_on_catalog=True)

        if len(self.errors):
            self._raise_error_and_upload()

        self.bq_table_id = bq_table_id
        self.write_type = write_type

        self._check_master_mix_correct_annotation(df)
        self._check_content_types(df)
        self._check_schema_and_constraints(df)

        if new_files or not new_songs:
            self._check_annotation_and_stem_type_match_files(df)
        else:
            self._check_annotation_and_stem_type_match_no_files(df)

        if len(self.errors):
            self._raise_error_and_upload()
