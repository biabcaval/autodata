from google.cloud import storage, bigquery
from google.cloud.exceptions import NotFound
import json
import concurrent.futures
import pandas as pd
from typing import Dict, Any, List, Optional, Union, Callable
from tqdm import tqdm
from moises_ml_utils import alert as ml_alert
from moises_ml_utils.utils import get_bq_client, get_music_ai_client, get_sa_credentials_from_secret, generate_signed_url, upload_dataframe_to_gcs


class MonitorError(Exception):
    """Base exception for MonitorProcessor errors."""
    pass


class JobFailedError(MonitorError):
    """Raised when a Music AI job fails."""
    pass


class ConfigurationError(MonitorError):
    """Raised when there's a configuration issue."""
    pass

class MonitorProcessor:
    """A processor for monitoring and executing ML workflows with Music AI."""
    
    # Class constants
    DEFAULT_RETRY_COUNT = 5
    
    def __init__(
        self, 
        name: str, 
        workflow_name: str, 
        result_columns: Union[str, List[str]], 
        dataset_id: str, 
        table_id: str, 
        bucket_name: str = 'moises-data-catalog', 
        project_id: str = 'moises-ds-data',
        error_bucket_project_id: str = 'machine-learning',
        slack_secret_id: str = 'slack-webhook-url',
        signed_url_secret_id: str = 'sign-read-url-only',
        music_ai_secret_id: str = 'stage-musicai-machine-learning-api-key',
        music_ai_url: str = 'https://api-stage.music.ai/api',
        max_workers: int = 25,
        batch_size: int = 100,
        client: Optional[Any] = None,
        storage_client: Optional[Any] = None
    ) -> None:
        """
        Initialize MonitorProcessor.
        
        Args:
            name: Name of the monitor
            workflow_name: Name of the Music AI workflow
            result_columns: Column name(s) for storing results. Can be a single string or list of strings
            dataset_id: BigQuery dataset ID
            table_id: BigQuery table ID
            bucket_name: GCS bucket name
            project_id: Google Cloud project ID
            error_bucket_project_id: Google Cloud project ID for error bucket (default: machine-learning)
            slack_secret_id: Secret ID for Slack webhook
            signed_url_secret_id: Secret ID for signed URL credentials
            music_ai_secret_id: Secret ID for Music AI API key
            music_ai_url: Music AI API base URL
            client: Optional BigQuery client
            storage_client: Optional GCS client
            
        Raises:
            ConfigurationError: If required parameters are invalid
        """
        # Validate required parameters
        if not all([name, workflow_name, result_columns, dataset_id, table_id]):
            raise ConfigurationError("All required parameters must be provided and non-empty")
        
        # Convert single string to list for consistent handling
        if isinstance(result_columns, str):
            self.result_columns = [result_columns]
        else:
            self.result_columns = result_columns
        
        self.name = name
        self.workflow_name = workflow_name
        self.dataset_id = dataset_id
        self.table_id = table_id
        self.project_id = project_id
        self.error_bucket_project_id = error_bucket_project_id
        self.max_workers = max_workers
        self.batch_size = batch_size
        self.storage_client = storage_client

        if not client:
            self.client = get_bq_client(self.project_id)

        if not storage_client:
            self.storage_client = storage.Client.from_service_account_info(get_sa_credentials_from_secret(signed_url_secret_id, self.project_id))
        self.bucket = self.storage_client.bucket(bucket_name)

        self.music_ai = get_music_ai_client(self.project_id, music_ai_secret_id, music_ai_url)

        self.webhook_url = get_sa_credentials_from_secret(slack_secret_id, self.project_id)

    def get_write_type(self) -> str:
        """
        Determine the write disposition for BigQuery table.
        
        Returns:
            'APPEND' if table exists, 'TRUNCATE' if table doesn't exist
            
        Raises:
            MonitorError: If there's an error other than table not found
        """
        try:
            self.client.get_table(f"{self.dataset_id}.{self.table_id}")
            return 'APPEND'
        except NotFound:
            return 'TRUNCATE'
        except Exception as e:
            raise MonitorError(f"Error checking table '{self.dataset_id}.{self.table_id}': {str(e)}")

    def get_df_to_process(self, query: str, file_ids_to_ignore = None) -> None:
        """
        Execute a BigQuery query and store results in self.df.
        
        Args:
            query: SQL query string to execute
            file_ids_to_ignore: List of file IDs to exclude from the query
        """
        # Add WHERE condition to exclude specified file IDs
        if file_ids_to_ignore:
            # Convert file_ids_to_ignore to a comma-separated string for SQL IN clause
            file_ids_str = "', '".join(file_ids_to_ignore)
            
            query_upper = query.upper()
            where_pos = query_upper.find('WHERE')
            limit_pos = query_upper.find('LIMIT')
            offset_pos = query_upper.find('OFFSET')
            
            # Check if query already has WHERE clause
            if where_pos != -1:
                # Find where the existing WHERE clause ends (before LIMIT/OFFSET)
                where_end_pos = len(query)
                if limit_pos != -1:
                    where_end_pos = min(where_end_pos, limit_pos)
                if offset_pos != -1:
                    where_end_pos = min(where_end_pos, offset_pos)
                
                # Insert AND condition at the end of existing WHERE clause
                modified_query = query[:where_end_pos].rstrip() + f" AND file_id NOT IN ('{file_ids_str}') " + query[where_end_pos:]
            else:
                # No WHERE clause exists, need to add one
                # Find the position where to insert WHERE clause (before LIMIT/OFFSET)
                insert_pos = len(query)
                if limit_pos != -1:
                    insert_pos = min(insert_pos, limit_pos)
                if offset_pos != -1:
                    insert_pos = min(insert_pos, offset_pos)
                
                # Insert WHERE clause before LIMIT/OFFSET
                modified_query = query[:insert_pos].rstrip() + f" WHERE file_id NOT IN ('{file_ids_str}') " + query[insert_pos:]
        else:
            modified_query = query
            
        query_job = self.client.query(modified_query)
        self.df = query_job.to_dataframe()
  

    def process_single_file(self, process_result: Callable[[Dict[str, Any]], Dict[str, Any]], file_path: str) -> Dict[str, Any]:
        """
        Process a single audio file and return the results.
        
        Args:
            process_result: Function to process the job result. Should return a dictionary with keys matching result_columns
            file_path: Path to the audio file
            
        Returns:
            Processed result dictionary with keys matching result_columns
            
        Raises:
            JobFailedError: If the Music AI job fails
        """
        # Submit the job
        signed_url = generate_signed_url(self.bucket, '/'.join(file_path.split('/')[1:]))

        job_id = self.music_ai.add_job(
            self.workflow_name,
            self.workflow_name,
            {"inputUrl": signed_url}
        )["id"]

        # Wait for completion
        job = self.music_ai.wait_for_job_completion(job_id)

        # Process results
        if job["status"] != "SUCCEEDED":
            print(f"Job failed for file: {file_path}")
            print(job)
            self.music_ai.delete_job(job_id)
            raise JobFailedError(f'Music AI job failed for file: {file_path}')

        # Process Result with custom function
        result = process_result(job['result'])

        # Clean up
        self.music_ai.delete_job(job_id)

        return result

    def process_files_in_parallel(self, process_result_function: Callable[[Dict[str, Any]], Dict[str, Any]], df: pd.DataFrame, warn: bool = False) -> pd.DataFrame:
        """
        Process multiple files in parallel for better performance.
        
        Args:
            process_result_function: Function to process job results
            df: DataFrame containing file information
            warn: Whether to send alerts for failed files
            
        Returns:
            DataFrame with processing results
        """
        results_list = []
        failed_files = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Map each file to a future
            future_to_path = {
                executor.submit(self.process_single_file, process_result_function, row['path']): row
                for _, row in df.iterrows()
            }

            # Process completed futures
            for future in concurrent.futures.as_completed(future_to_path):
                row = future_to_path[future]
                try:
                    result = future.result()
                    row_dict = row.to_dict()
                    
                    # Multiple output columns
                    if len(self.result_columns) > 1:
                        for col in self.result_columns:
                            if col in result:
                                row_dict[col] = result[col]
                    else:
                        # Only one output column
                        row_dict[self.result_columns[0]] = result

                    results_list.append(row_dict)
                except Exception as e:
                    print(f"Error processing {row['path']}: {str(e)}")
                    failed_files.append({'dataset': row['dataset'], 'file_id': row['file_id'], 'error': str(e)})

        if failed_files and warn:

            df_failed_files = pd.DataFrame(failed_files)
            
            print(f"Failed to process {len(failed_files)} files.")
            
            # Upload failed files to GCS
            gcs_file_path = upload_dataframe_to_gcs(
                df=df_failed_files,
                folder_error_name=self.workflow_name,
                bucket_name='monitor_errors',
                project_id=self.error_bucket_project_id
            )
            
            # Group failed files by dataset and count
            dataset_counts = df_failed_files.groupby('dataset').size().to_dict()
            
            # Create a more structured and visually appealing message
            title = f" {self.name} Monitor Alert"
            
            summary = (
                f"*Workflow:* `{self.workflow_name}`\n"
                f"*Failed Files:* {len(failed_files)}\n"
                f"*Status:* Execution Error\n"
                f"*Failed Files CSV:* https://console.cloud.google.com/storage/browser/_details/monitor_errors/{gcs_file_path}"
            )
            
            # Format dataset counts
            dataset_summary = "*Failed Files by Dataset:*\n"
            for dataset, count in dataset_counts.items():
                dataset_summary += f"• `{dataset}`: {count} file{'s' if count != 1 else ''}\n"
            
            # Format failed files in a cleaner way
            file_list = []
            for file_info in failed_files[:5]:  # Show fewer files for better readability
                file_list.append(f"• `{file_info['file_id']}` (dataset: {file_info['dataset']})")
            
            details_section = "*Sample Failed Files:*\n" + "\n".join(file_list)
            if len(failed_files) > 5:
                details_section += f"\n• ... and {len(failed_files) - 5} more files"
            
            # Combine all parts
            full_message = f"{summary}\n\n{dataset_summary}\n{details_section}"
            
            ml_alert.send_alert_to_slack(
                title, 
                details=full_message, 
                urgency='error', 
                webhook_url=self.webhook_url
            )

        return pd.DataFrame(results_list)

    def process_workflow(self, process_result_function: Callable[[Dict[str, Any]], Dict[str, Any]], columns_to_keep=['file_id','song_id'], warn_last_try=True) -> pd.DataFrame:
        """
        Process the entire workflow with retry logic.
        
        Args:
            process_result_function: Function to process job results
            
        Returns:
            DataFrame with all processing results
        """
        # Preprocess the df column
        self.df = self.df[list(set(columns_to_keep + ['path', 'dataset']))]
        
        # Run the processing
        cols_df_save = list(self.df.columns)
        cols_df_save.extend(self.result_columns)
        df_to_save = pd.DataFrame(columns=cols_df_save)

        for i in tqdm(range(0, len(self.df), self.batch_size)):
            upper_range = min(i + self.batch_size, len(self.df))
            df_results = self.process_files_in_parallel(process_result_function, self.df[i:upper_range], warn=False)
            df_to_save = pd.concat([df_to_save, df_results], ignore_index=True)

        count = self.DEFAULT_RETRY_COUNT
        df_to_rerun = self.df[~self.df['file_id'].isin(df_to_save['file_id'])]

        while count and len(df_to_rerun):
            df_results = self.process_files_in_parallel(process_result_function, df_to_rerun, warn=(count == 1) if warn_last_try else False)
            df_to_save = pd.concat([df_to_save, df_results], ignore_index=True)

            count -= 1
            df_to_rerun = self.df[~self.df['file_id'].isin(df_to_save['file_id'])]

        df_to_save = df_to_save[columns_to_keep + self.result_columns]
        
        # Apply JSON serialization to all result columns
        for col in self.result_columns:
            df_to_save[col] = df_to_save[col].apply(lambda x: json.dumps(x) if x is not None else None)

        return df_to_save

    def upload_to_bq_table(self, df: pd.DataFrame, write_type='APPEND') -> None:
        """
        Upload DataFrame to BigQuery table.
        
        Args:
            df: DataFrame to upload
            write_type: Write disposition type ('APPEND' or 'TRUNCATE')
        """
        table_ref = self.client.dataset(self.dataset_id).table(self.table_id)
        
        if not write_type:
            write_type = self.get_write_type()

        job_config = bigquery.LoadJobConfig(
            write_disposition=f"WRITE_{write_type}",
            autodetect=True
        )

        job = self.client.load_table_from_dataframe(
            df,
            table_ref,
            job_config=job_config
        )

        job.result()

        print(f"✅ Table '{self.dataset_id}.{self.table_id}' created with {job.output_rows} rows.")

    def process_workflow_and_upload_to_bq(self, process_result_function: Callable[[Dict[str, Any]], Dict[str, Any]], columns_to_keep=['file_id','song_id'], warn_last_try=True, write_type='APPEND') -> None:
        """
        Process workflow and upload results to BigQuery.
        
        Args:
            process_result_function: Function to process job results
        """
        df_result = self.process_workflow(process_result_function, columns_to_keep, warn_last_try)
        if len(df_result):
            self.upload_to_bq_table(df_result, write_type)