import os
from typing import Optional
import requests
from loguru import logger

def send_to_slack(
    message: str, 
    webhook_url: Optional[str] = None,
    *,
    timeout: int = 10
) -> bool:
    """
    Send a simple text message to Slack.
    
    Args:
        message: Text message to send
        webhook_url: Slack webhook URL (uses SLACK_WEBHOOK_URL env var if not provided)
        timeout: Request timeout in seconds
        
    Returns:
        True if successful, False otherwise
        
    Example:
        >>> send_to_slack("Pipeline completed successfully! 🎉")
        >>> send_to_slack("Error in data processing", webhook_url="https://hooks.slack.com/...")
    """
    url = webhook_url or os.getenv("SLACK_WEBHOOK_URL")
    if not url:
        logger.error("No Slack webhook URL provided. Set SLACK_WEBHOOK_URL env var or pass webhook_url parameter")
        return False
    
    payload = {"text": message}
    
    try:
        response = requests.post(url, json=payload, timeout=timeout)
        response.raise_for_status()
        logger.debug("Slack message sent successfully")
        return True
    except Exception as e:
        logger.error(f"Failed to send Slack message: {e}")
        return False


def send_alert_to_slack(
    title: str,
    details: str = "",
    urgency: str = "info",
    webhook_url: Optional[str] = None
) -> bool:
    """
    Send a formatted alert to Slack.
    
    Args:
        title: Alert title
        details: Additional details (optional)
        urgency: 'info', 'warning', or 'error'
        webhook_url: Slack webhook URL (optional)
    """
    icons = {"info": "ℹ️", "warning": "⚠️", "error": "🚨"}
    icon = icons.get(urgency, "ℹ️")
    
    message = f"{icon} *{title}*"
    if details:
        message += f"\n{details}"
    
    return send_to_slack(message, webhook_url)