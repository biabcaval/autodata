import json
import datetime
import pandas as pd
from typing import Any, Dict, Union
from google.cloud import bigquery, secretmanager, storage
from google.auth import default
from musicai_sdk import MusicAiClient
import uuid

# Constants
DEFAULT_EXPIRATION_MINUTES = 60

def get_bq_client(project_id) -> Any:
    """
    Create and return a BigQuery client.
    
    Returns:
        BigQuery client instance
    """
    credentials, project = default(
        scopes=['https://www.googleapis.com/auth/cloud-platform']
    )
    # Create BigQuery client with the credentials and specify the correct project
    client = bigquery.Client(
        credentials=credentials,
        project=project_id  # Explicitly set the project ID
    )

    return client

def get_music_ai_client(project_id: str, music_ai_secret_id: str, music_ai_url: str) -> Any:
    """
    Create and return a Music AI client.
    
    Args:
        music_ai_secret_id: Secret ID for Music AI API key
        music_ai_url: Music AI API base URL
        
    Returns:
        Music AI client instance
    """
    api_key = get_sa_credentials_from_secret(music_ai_secret_id, project_id)
    music_ai = MusicAiClient(api_key=api_key)
    music_ai.base_url = music_ai_url

    return music_ai

def get_sa_credentials_from_secret(secret_id: str, project_id: str) -> Union[str, Dict[str, Any]]:
    """
    Retrieve credentials from Google Secret Manager.
    
    Args:
        secret_id: Secret identifier
        project_id: Google Cloud project ID
        
    Returns:
        Secret value as string or parsed JSON dict
        
    Raises:
        ValueError: If secret doesn't contain valid JSON when expected
    """
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{project_id}/secrets/{secret_id}/versions/latest"
    response = client.access_secret_version(request={"name": name})
    secret_payload = response.payload.data.decode("UTF-8")

    if secret_id in ('musicai-machine-learning-api-key','stage-musicai-machine-learning-api-key','slack-webhook-url'):
        return secret_payload

    # Find the start of the JSON and remove anything before it
    json_start = secret_payload.find('{')
    if json_start == -1:
        raise ValueError("Secret does not contain valid JSON.")

    clean_payload = secret_payload[json_start:]
    return json.loads(clean_payload)


def generate_signed_url(bucket: Any, object_path: str, expiration_minutes: int = DEFAULT_EXPIRATION_MINUTES) -> str:
    """
    Generate a signed URL for a GCS object.
    
    Args:
        object_path: Path to the object in GCS
        expiration_minutes: URL expiration time in minutes
        
    Returns:
        Signed URL string
    """
    blob = bucket.blob(object_path)

    url = blob.generate_signed_url(
        version="v4",
        expiration=datetime.timedelta(minutes=expiration_minutes),
        method="GET"
    )
    return url  


def upload_dataframe_to_gcs(
    df: pd.DataFrame,
    folder_error_name: str, 
    bucket_name: str, 
    project_id: str,
    file_path: str = None, 
) -> str:
    # Initialize GCS client
    client = storage.Client(project=project_id)
    bucket = client.bucket(bucket_name)
    
    # Generate unique filename if needed
    if not file_path:
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = f"{folder_error_name}/{timestamp}.csv"
    
    # Get blob reference
    blob = bucket.blob(file_path)
    
    csv_data = df.to_csv(index=False)
    blob.upload_from_string(csv_data, content_type='text/csv')

    return file_path

def get_unique_uuid():
    return uuid.uuid4()