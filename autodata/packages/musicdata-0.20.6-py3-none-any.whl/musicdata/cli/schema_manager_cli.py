"""
This script is used to manage the schema files for the data registry.
It uses the generated schema files in the schemas_generated directory.
It gets the revision attribute and the kind from the model_config.kind attribute.

It allows to:
- Upsert a new schema revision for a given schema class (only if the schema has changed).
- Upsert all schema revisions for all schema classes (only if the schema has changed).
"""

import argparse
import difflib
import os
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

import orjson
from dotenv import load_dotenv
from jsonschema import Draft202012Validator
from loguru import logger
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Connectable, Engine

from musicdata.db import CatalogDatabase, execute_statement

load_dotenv()

db = CatalogDatabase()
local_schemas = {}

CATALOG_DB_URL = os.environ["CATALOG_DB_URL"]
SCHEMAS_GENERATED_DIR = Path("src/musicdata/annotations/schema/generated")


def _prepare_schema_params(generated_json: dict[str, Any]) -> dict[str, Any]:
    """Prepare parameters for database operations from a schema."""
    return {
        "kind": generated_json["kind"],
        "revision": generated_json["revision"],
        "json_schema": generated_json["json_schema"],
        "description": generated_json["description"],
        "constraints": generated_json["constraints"],
    }


def get_local_schemas() -> dict[tuple[str, int], dict[str, Any]]:
    """
    Get all schema files from the schemas_generated directory.

    Returns:
        Dict[Tuple[str, int], Dict[str, Any]]: A dictionary mapping (kind, revision) to schema objects
    """
    if local_schemas:
        return local_schemas

    annotation_kinds = {}

    if not SCHEMAS_GENERATED_DIR.exists():
        logger.warning(f"Schemas directory not found: {SCHEMAS_GENERATED_DIR}")
        return annotation_kinds

    for schema_file in SCHEMAS_GENERATED_DIR.glob("*.json"):
        try:
            with open(schema_file, "rb") as f:
                json_data: dict[str, Any] = orjson.loads(f.read())

            kind_type = json_data["kind"]
            annotation_kind = json_data["json_schema"]
            revision = json_data["revision"]

            # Validate the schema
            Draft202012Validator.check_schema(annotation_kind)

            # Create the schema object
            annotation_kind = {
                "kind": kind_type,
                "revision": revision,
                "json_schema": annotation_kind,
                "constraints": json_data.get("constraints"),
                "file_path": schema_file,
                "description": json_data.get("description"),
            }

            annotation_kinds[(kind_type, revision)] = annotation_kind
            logger.debug(f"Loaded schema for kind '{kind_type}' revision {revision} from {schema_file}")

        except (orjson.JSONDecodeError, KeyError, ValueError) as e:
            logger.warning(f"Error loading schema file {schema_file}: {e}")

    local_schemas.update(annotation_kinds)
    return local_schemas


def get_schema_by_kind_and_revision(kind: str, revision: int) -> dict[str, Any]:
    """
    Get a schema by kind and revision from the loaded schemas.

    Args:
        kind: The kind to look for
        revision: The schema revision to look for

    Returns:
        dict: The schema as a dictionary

    Raises:
        FileNotFoundError: If the schema doesn't exist
    """
    schemas = get_local_schemas()
    key = (kind, revision)

    if key not in schemas:
        msg = f"Schema not found for kind '{kind}' revision {revision}"
        raise FileNotFoundError(msg)

    return schemas[key]


def get_existing_schema(conn: Connectable, kind: str, revision: int) -> dict[str, Any] | None:
    """
    Get an existing schema from the database.

    Args:
        conn: Database connection
        kind: The kind to look for
        revision: The schema revision to look for

    Returns:
        Optional[dict]: The schema as a dictionary, or None if not found
    """
    result = execute_statement(
        conn,
        text(
            """
            SELECT *
            FROM annotation_kinds
            WHERE kind = :kind AND revision = :revision
            """
        ),
        {"kind": kind, "revision": revision},
    ).first()

    if result is None:
        return None

    return result._asdict()


def schemas_are_different(schema1: dict, schema2: dict) -> bool:
    """
    Compare two schemas to see if they are different.

    Args:
        schema1: First schema
        schema2: Second schema

    Returns:
        bool: True if schemas are different, False otherwise
    """
    # Convert schemas to strings for comparison
    schema1_str = orjson.dumps(schema1, option=orjson.OPT_SORT_KEYS | orjson.OPT_INDENT_2).decode()
    schema2_str = orjson.dumps(schema2, option=orjson.OPT_SORT_KEYS | orjson.OPT_INDENT_2).decode()

    # Compare the schemas
    diff = list(difflib.unified_diff(schema1_str.splitlines(), schema2_str.splitlines(), n=0))

    return len(diff) > 0


def upsert_schema_from_json(conn: Connectable, kind: str, revision: int) -> None:
    """Insert or update a schema in the database only if it has changed."""
    # Get the local schema
    generated_json = get_schema_by_kind_and_revision(kind=kind, revision=revision)

    # Get the existing schema from the database
    existing_schema = get_existing_schema(conn, kind, revision)

    # If the schema doesn't exist in the database, insert it
    if existing_schema is None:
        params = _prepare_schema_params(generated_json)
        params["id"] = uuid4()
        params["active"] = True
        stmt = db.t.annotation_kinds.insert().values(params)

        execute_statement(conn, stmt)
        logger.info(f"Inserted new schema for kind '{kind}' revision {revision}")
        return

    if should_update_schema(existing_schema, generated_json):
        # Keep the existing ID but update with the new local data
        params = _prepare_schema_params(generated_json)
        params["updated_at"] = datetime.now(UTC)
        stmt = db.t.annotation_kinds.update().values(params).where(db.t.annotation_kinds.c.id == existing_schema["id"])
        execute_statement(conn, stmt)
        logger.info(f"Updated schema for kind '{kind}' revision {revision} (schema has changed)")
    else:
        logger.debug(f"No changes detected for kind '{kind}' revision {revision}")


def should_update_schema(existing_schema: dict[str, Any], generated_json: dict[str, Any]) -> bool:
    """
    Check if the schema should be updated.

    Args:
        existing_schema: The schema currently in the database
        generated_json: The newly generated schema

    Returns:
        bool: True if the schema should be updated, False otherwise
    """
    # Check if the core schema has changed
    if schemas_are_different(existing_schema["json_schema"], generated_json["json_schema"]):
        return True

    # Check if constraints have changed
    # Defaults to empty dict if None
    existing_constraints = existing_schema.get("constraints", {}) or {}
    generated_constraints = generated_json.get("constraints", {}) or {}

    if schemas_are_different(existing_constraints, generated_constraints):
        return True

    # Check if description has changed
    return existing_schema.get("description") != generated_json.get("description")


def get_list_of_local_schemas() -> list[dict[str, Any]]:
    """
    Get all available schemas from the schemas_generated directory.

    Returns:
        list[dict[str, Any]]: A list of dictionaries with kind, revision, description, and file_path
    """
    schemas_dict = get_local_schemas()

    return [schema for (kind, revision), schema in schemas_dict.items()]


def upsert_all_schemas(conn: Connectable) -> None:
    """
    Upsert all schemas from the schemas_generated directory.

    Args:
        conn: Database connection
    """
    schemas = get_list_of_local_schemas()

    if not schemas:
        logger.warning("No schemas found to upsert")
        return

    for schema in schemas:
        try:
            upsert_schema_from_json(conn, schema["kind"], schema["revision"])
        except Exception:
            logger.exception(f"Error upserting schema {schema['kind']} v{schema['revision']}.")


def get_engine() -> Engine:
    """Get a database engine."""
    return create_engine(CATALOG_DB_URL)


def main() -> None:
    """Main entry point for the CLI."""

    logger.remove()
    logger.add(sys.stderr, level="INFO")

    parser = argparse.ArgumentParser(description="Manage annotation schemas")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Upsert a single schema
    upsert_parser = subparsers.add_parser("upsert", help="Upsert a schema")
    upsert_parser.add_argument("kind", help="Kind")
    upsert_parser.add_argument("revision", type=int, help="Schema revision")

    # Upsert all schemas
    subparsers.add_parser("upsert-all", help="Upsert all schemas")

    # List available schemas
    subparsers.add_parser("list", help="List available schemas")

    args = parser.parse_args()

    if args.command == "upsert":
        with db.engine.begin() as conn:
            upsert_schema_from_json(conn, args.kind, args.revision)

    elif args.command == "upsert-all":
        with db.engine.begin() as conn:
            upsert_all_schemas(conn)

    elif args.command == "list":
        schemas = get_list_of_local_schemas()
        if not schemas:
            logger.warning("No schemas found")
            return

        logger.info(f"Found {len(schemas)} schemas:")
        for schema in schemas:
            logger.info(f"  - {schema['kind']} v{schema['revision']}")

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
