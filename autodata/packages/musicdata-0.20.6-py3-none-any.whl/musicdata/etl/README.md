# ETL System for Data Catalog

This ETL system provides a flexible, extensible framework for processing input data and inserting annotations into the data catalog. It supports multiple data sources and annotation kinds with automatic validation and change detection.

## Architecture

The ETL system follows a clean, modular streaming architecture:

```
src/musicdata/etl/
├── sources/           # Data source adapters (streaming)
│   ├── base.py       # Abstract adapter interface
│   ├── bigquery.py   # BigQuery streaming adapter
│   └── csv.py        # CSV streaming adapter
├── stream_buffer.py  # Group-aware buffering for entity boundaries
├── validators/       # Data validation logic
│   ├── base.py       # Base validator interface
│   └── kind_validators.py  # Annotation kind validators
├── unified_processor.py  # Unified chunk processing
├── parallel_processor.py # Parallel execution
├── models/           # Configuration and results models
│   ├── config.py     # ETL configuration
│   └── results.py    # Results aggregation (DuckDB)
├── processor.py      # Main ETL orchestration
└── cli.py           # CLI interface
```

## Processing Flow

1. **Source Streaming**: Data streams directly from source (BigQuery/CSV)
2. **Group-Aware Buffering**: When creating entities (songs/files), buffer ensures
   group boundaries are preserved across chunks
3. **Parallel Processing**: Chunks processed in parallel across worker pool
4. **Results Aggregation**: Workers write to per-worker DuckDB databases, merged at end

## Key Components

### 1. Data Source Adapters (Streaming)

Adapters stream data directly from sources with no intermediate staging:

- **BigQueryAdapter**: Streams data from BigQuery tables using Storage API
- **CSVAdapter**: Streams CSV files from GCS/local using pandas chunking

All adapters implement `load_data_iter()` for memory-efficient streaming.

### 2. Stream Processing

The ETL system uses direct stream processing for optimal performance:

**Annotation-Only Mode** (`load_songs_and_files=False`):

- Data flows directly from source to processors
- No buffering needed (annotations are independent)
- Maximum throughput

**Entity Creation Mode** (`load_songs_and_files=True`):

- Group-aware buffering preserves song/file boundaries
- Ensures all rows for a song are processed together
- Maintains dataset consistency and atomic operations

**Memory Efficiency**:

- Only active chunks are in memory
- No intermediate storage of input data
- Workers maintain small per-worker result databases

### 3. Validators

Validators ensure data quality and transform data to annotation requests:

- **FileDataValidator**: For `file_data` annotation kind
- **StemTypesValidator**: For `stem_types` annotation kind

### 4. ETL Processor

The main orchestrator that:

- Loads and validates configuration
- Creates appropriate adapters and validators
- Orchestrates direct streaming pipeline
- Handles error reporting and result artifacts

## Usage

### Command Line Interface

The ETL system provides a CLI with several commands:

```bash
# Run ETL pipeline
python scripts/run_etl.py run --config my_config.yaml

# Validate configuration and data source
python scripts/run_etl.py validate --config my_config.yaml

# List available annotation kinds
python scripts/run_etl.py list-kinds

# Generate sample configuration
python scripts/run_etl.py generate-config sample_config.yaml
```

### Configuration

ETL operations are configured using YAML files:

```yaml
# Data source - BigQuery table or GCS/Local CSV file
source: bq://project.dataset.table
# source: gs://bucket/path/file.csv

# Batch description for tracking
insert_batch_description: "Uploading data from provider X"

# Annotations to process (multiple kinds supported)
# Each entry sets the kind and its standard/source
annotation_kinds:
  - kind: file_data
    annotation_standard: gold
    annotation_source: extracted_metadata
  - kind: instrument_tagging
    annotation_standard: bronze
    annotation_source: ml_predicted

# Operational settings
allow_unintended_value_change: false
allow_standard_downgrade: false

# Output bucket for processing results
output_location: gs://bucket/etl-results
```

### Programmatic Usage

You can also use the ETL system programmatically:

```python
from musicdata.etl import ETLConfig, ETLProcessor

# Load configuration from any fsspec-supported URI
config = ETLConfig.from_yaml("gs://bucket/config.yaml")   # GCS
# config = ETLConfig.from_yaml("s3://bucket/config.yaml")  # S3
# config = ETLConfig.from_yaml("my_config.yaml")           # Local file

# Create processor
processor = ETLProcessor(config)

# Run ETL pipeline
results = processor.process_data()

print(f"Inserted: {results['annotations_inserted']}")
print(f"Skipped: {results['annotations_skipped']}")
```

## Adding New Annotation Kinds

To add support for a new annotation kind:

1. **Create a validator class** in `validators/kind_validators.py`:

```python
class MyNewKindValidator(DataValidator):
    def __init__(self) -> None:
        super().__init__("my_new_kind")

    def get_required_columns(self) -> list[str]:
        return ["file_id", "my_field"]

    def validate_data(self, df: pd.DataFrame) -> ValidationResult:
        # Implement validation logic
        pass

    def transform_to_annotation_requests(self, df, kind_id, batch_id, standard, source):
        # Implement transformation logic
        pass
```

2. **Register the validator** in the registry:

```python
_VALIDATOR_REGISTRY["my_new_kind"] = MyNewKindValidator
```

## Data Source Requirements

### BigQuery Tables

- Must be accessible with current GCP credentials
- Should contain all required columns for the annotation kind
- Format: `bq://project.dataset.table`

### CSV Files

- Must be stored in Google Cloud Storage
- Must be accessible with current GCP credentials
- Should have headers matching required columns
- Format: `gs://bucket/path/file.csv`

## Error Handling

The ETL system provides comprehensive error handling:

- **Configuration errors**: Invalid YAML, missing required fields
- **Connection errors**: Unable to access data source
- **Validation errors**: Missing columns, invalid data types
- **Processing errors**: Database connection issues, constraint violations

All errors are logged and included in the results artifact.

## Output Artifacts

After processing, the system uploads a JSON artifact to the configured output bucket containing:

```json
{
  "etl_config": { ... },
  "processing_results": {
    "validation_passed": true,
    "data_loaded": true,
    "annotations_processed": 1000,
    "annotations_inserted": 950,
    "annotations_skipped": 50
  },
  "errors": [],
  "batch_id": "uuid-here"
}
```

## Best Practices

1. **Always test with dry-run first** to validate configuration and data
2. **Use descriptive batch descriptions** for tracking and debugging
3. **Monitor output artifacts** for processing results and errors
4. **Validate data sources** before running large ETL jobs
5. **Use appropriate annotation standards** (gold for high-quality, bronze for experimental)

## Extending the System

The ETL system is designed to be extensible:

- **New data sources**: Implement the `DataAdapter` interface
- **New annotation kinds**: Implement the `DataValidator` interface
- **Custom validation logic**: Override validation methods in validators
- **Custom transformation logic**: Override transformation methods in validators

## Dependencies

The ETL system requires:

- `pandas` for data manipulation
- `google-cloud-bigquery` for BigQuery access
- `google-cloud-storage` for GCS access
- `pyyaml` for configuration parsing
- `click` for CLI interface
- `loguru` for logging

## Troubleshooting

Common issues and solutions:

1. **"No validator found for annotation kind"**: Add the kind to the validator registry
2. **"Missing required columns"**: Check data source schema matches validator requirements
3. **"Data source connection validation failed"**: Verify GCP credentials and permissions
4. **"Data validation failed"**: Check data quality and column types
5. **Import errors**: Ensure all dependencies are installed and paths are correct
