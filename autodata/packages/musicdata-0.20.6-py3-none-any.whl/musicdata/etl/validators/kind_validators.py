"""Kind-specific data validators."""

import importlib
import inspect
from collections.abc import Collection
from typing import TYPE_CHECKING, Any
from uuid import UUID

import pandas as pd
from loguru import logger

from musicdata.annotations import (
    FileDataSchema,
    StemTypesSchema,
)
from musicdata.annotations.models.base import AnnotationArrayBase, AnnotationObjectBase
from musicdata.annotations.models.file_data import AudioMetadata
from musicdata.annotations.validators import StemTypeRegistry
from musicdata.db.models import Standard
from musicdata.db.models.requests import AnnotationRequest
from musicdata.etl.validators.base import (
    AnnotationBase,
    DataValidator,
    JsonType,
    ValidationResult,
    is_value_empty_or_none,
)
from musicdata.utils.encryptor import JWEEncryptor
from musicdata.utils.files import is_lossless_extension

if TYPE_CHECKING:
    from musicdata.db.models import AnnotationSource, Standard


def _load_schema_class_for_annotation_kind(kind_name: str) -> type[AnnotationBase]:
    """
    Load the schema class for a given annotation kind.

    Args:
        annotation_kind: The kind of annotation to load the schema for.

    Returns:
        The schema class that inherits from AnnotationObjectBase or AnnotationArrayBase
    """
    # Convert annotation_kind to expected class name (e.g., "beat" -> "BeatSchema")
    expected_class_name = f"{kind_name.replace('_', ' ').title().replace(' ', '')}Schema"

    # Import the module for this annotation kind
    try:
        module = importlib.import_module(f"musicdata.annotations.models.{kind_name}")
    except ImportError as e:
        msg = f"Could not import module for annotation kind '{kind_name}': {e}"
        raise ValueError(msg) from e

    # Look for the Schema class that inherits from our annotation bases
    for name, obj in inspect.getmembers(module, inspect.isclass):
        if (
            name == expected_class_name
            and issubclass(obj, (AnnotationObjectBase, AnnotationArrayBase))
            and obj not in (AnnotationObjectBase, AnnotationArrayBase)
        ):
            return obj

    # If exact name match didn't work, try any class ending with "Schema"
    for name, obj in inspect.getmembers(module, inspect.isclass):
        if (
            name.endswith("Schema")
            and issubclass(obj, (AnnotationObjectBase, AnnotationArrayBase))
            and obj not in (AnnotationObjectBase, AnnotationArrayBase)
        ):
            return obj

    msg = f"Could not find a schema class for annotation kind '{kind_name}'"
    raise ValueError(msg)


class GenericAnnotationValidator(DataValidator):
    """
    Generic validator for annotation kinds that don't have specific validators.

    This validator dynamically loads the appropriate Pydantic schema class
    based on the annotation kind name and validates the JSON data against it.
    """

    def __init__(self, annotation_kind: str, *, encrypt: bool = False) -> None:
        super().__init__()
        self.annotation_kind = annotation_kind
        self._schema_class = _load_schema_class_for_annotation_kind(annotation_kind)
        self._encrypt = encrypt
        self._encryptor: JWEEncryptor | None = None

        if self._encrypt:
            try:
                self._encryptor = JWEEncryptor.from_env()
                logger.info(f"Encryption enabled for '{annotation_kind}'")
            except Exception as e:
                msg = f"Failed to initialize encryptor for '{annotation_kind}': {e}"
                raise ValueError(msg) from e

        logger.info(f"Initialized generic validator for '{annotation_kind}' using {self._schema_class.__name__}")

    def get_required_columns(self) -> list[str]:
        """Required columns for generic annotation validation."""
        return [self.annotation_kind]

    def get_column_data_types(self) -> dict[str, type | Any]:
        """Data types for generic annotation validation."""
        return {
            "song_id": str,  # Optional - either song_id or file_id must be present
            "file_id": str,  # Optional - either song_id or file_id must be present
            self.annotation_kind: JsonType,  # JSON data that will be validated by Pydantic
        }

    def validate_columns_exist(self, df: pd.DataFrame) -> ValidationResult:
        """Validate that required columns and at least one of song_id/file_id exist."""
        # First validate the base required columns (annotation kind)
        result = super().validate_columns_exist(df)

        # Check that at least one of song_id or file_id exists
        has_song_id = "song_id" in df.columns
        has_file_id = "file_id" in df.columns

        if not has_song_id and not has_file_id:
            result.add_error(
                f"At least one of 'song_id' or 'file_id' columns must be present "
                f"for annotation kind '{self.annotation_kind}'"
            )

        return result

    def create_annotation_model(self, row: dict) -> AnnotationBase:
        """Create the annotation schema model from row data."""
        raw_data = row[self.annotation_kind]

        # Encrypt first if needed, then validate
        if self._encrypt and self._encryptor:
            encrypted_jwe_json = self._encryptor.encrypt_dict(raw_data)
            data_to_validate = {"jwe_json": encrypted_jwe_json}
        else:
            data_to_validate = raw_data

        return self._schema_class.model_validate(data_to_validate)

    def transform_row(
        self,
        row: dict,
        kind_id: UUID,
        batch_id: UUID,
        annotation_standard: "Standard",
        annotation_source: "AnnotationSource",
    ) -> AnnotationRequest:
        """Transform a single row into an AnnotationRequest using the dynamic schema."""
        annotation_value = self.create_annotation_model(row)

        # Determine if this is a file or song annotation based on available columns
        if "file_id" in row and row["file_id"] is not None:
            return AnnotationRequest.for_file(
                file_id=UUID(str(row["file_id"])),
                kind_id=kind_id,
                annotation_value=annotation_value.model_dump(),
                standard=annotation_standard,
                annotation_source=annotation_source,
                batch_id=batch_id,
            )
        # Only create a song annotation if file_id is not present
        if "song_id" in row and row["song_id"] is not None:
            return AnnotationRequest.for_song(
                song_id=UUID(str(row["song_id"])),
                kind_id=kind_id,
                annotation_value=annotation_value.model_dump(),
                standard=annotation_standard,
                annotation_source=annotation_source,
                batch_id=batch_id,
            )

        msg = f"Row must contain either 'file_id' or 'song_id' for annotation kind '{self.annotation_kind}'"
        raise ValueError(msg)


class FileDataValidator(DataValidator):
    """Validator for file_data annotation kind."""

    def __init__(self) -> None:
        super().__init__()
        self.annotation_kind = "file_data"

    def get_required_columns(self) -> list[str]:
        """Required columns for file_data annotations."""
        return [
            "file_id",
            "path",  # Needed for the `lossless` field
            "bit_rate",
            "channels",
            "codec",
            "duration_in_secs",
            "format",
            "sample_rate",
            "size_in_bytes",
        ]

    def get_column_data_types(self) -> dict[str, type]:
        """Data types for file_data annotations."""
        return {
            "file_id": str,
            "path": str,
            "bit_rate": float,
            "channels": float,
            "codec": str,
            "duration_in_secs": float,
            "format": str,
            "sample_rate": float,
            "size_in_bytes": float,
        }

    def is_row_payload_missing(self, row: dict) -> bool:
        """Treat missing file_data payload when key fields are absent or empty.

        We consider the payload missing if either 'path' or 'file_id' is None or empty.
        This handles BigQuery's behavior where NULL values can be converted to empty strings/collections.
        """
        return is_value_empty_or_none(row.get("path")) or is_value_empty_or_none(row.get("file_id"))

    def create_annotation_model(self, row: dict) -> FileDataSchema:
        """Create the FileDataSchema model from row data."""
        return FileDataSchema(
            audio_metadata=AudioMetadata(
                lossless=is_lossless_extension(row["path"]),
                duration_in_secs=row["duration_in_secs"],
                size_in_bytes=row["size_in_bytes"],
                format=row["format"],
                codec=row["codec"],
                bit_rate=row["bit_rate"],
                channels=row["channels"],
                channel_layout=row.get("channel_layout"),
                sample_rate=row["sample_rate"],
            ),
        )

    def transform_row(
        self,
        row: dict,
        kind_id: UUID,
        batch_id: UUID,
        annotation_standard: "Standard",
        annotation_source: "AnnotationSource",
    ) -> AnnotationRequest:
        """Transform a single row into an AnnotationRequest."""
        annotation_value = self.create_annotation_model(row)
        return AnnotationRequest.for_file(
            file_id=UUID(str(row["file_id"])),
            kind_id=kind_id,
            annotation_value=annotation_value.model_dump(),
            standard=annotation_standard,
            annotation_source=annotation_source,
            batch_id=batch_id,
        )


class StemTypesValidator(DataValidator):
    """Validator for stem_types annotation kind."""

    def __init__(self) -> None:
        super().__init__()
        self.annotation_kind = "stem_types"

    def get_required_columns(self) -> list[str]:
        """Required columns for stem_types annotations."""
        # Note: Either predicted_tags or stem_names must be present (validated in validate_columns_exist)
        # Optional columns: predicted_leak/has_leaks, mlab_result_ids
        return ["song_id", "file_id"]

    def get_column_data_types(self) -> dict[str, type]:
        """Data types for stem_types annotations."""
        return {
            "song_id": str,
            "file_id": str,
            "predicted_tags": list[str],
            "stem_names": list[str],
            "predicted_leak": bool,
            "has_leaks": bool,
            "mlab_result_ids": list[str],
        }

    def validate_columns_exist(self, df: pd.DataFrame) -> ValidationResult:
        """Validate that required columns and at least one stem name column exist."""
        # First validate the base required columns (song_id, file_id)
        result = super().validate_columns_exist(df)

        # Check that at least one of predicted_tags or stem_names exists
        has_predicted_tags = "predicted_tags" in df.columns
        has_stem_names = "stem_names" in df.columns

        if not has_predicted_tags and not has_stem_names:
            result.add_error(
                "At least one of 'predicted_tags' or 'stem_names' columns must be present for stem_types annotations"
            )

        return result

    def is_row_payload_missing(self, row: dict) -> bool:
        """Payload is the 'predicted_tags' or 'stem_names' column for this validator.

        Treats None, empty lists, empty dicts, and empty strings as missing.
        This handles BigQuery's behavior where NULL values can be converted to empty collections.
        """
        # Check both alternative column names
        predicted_tags = row.get("predicted_tags")
        stem_names = row.get("stem_names")
        return is_value_empty_or_none(predicted_tags) and is_value_empty_or_none(stem_names)

    def create_annotation_model(self, row: dict) -> StemTypesSchema:
        """Create the StemTypesSchema model from row data."""
        # Support both stem_names and predicted_tags (prefer stem_names if both exist)
        stem_names = row.get("stem_names") or row.get("predicted_tags")
        if not stem_names:
            msg = "Either 'stem_names' or 'predicted_tags' column must be present and non-empty"
            raise ValueError(msg)

        # Use StemTypeRegistry directly for stem name mapping
        stem_ids = StemTypeRegistry.map_names_to_ids(stem_names)

        # Support both has_leaks and predicted_leak (prefer has_leaks if both exist)
        has_leaks = row.get("has_leaks")
        if has_leaks is None:
            has_leaks = row.get("predicted_leak")

        return StemTypesSchema(
            stem_types=list(stem_ids),
            has_leaks=has_leaks,
            mlab_result_ids=row.get("mlab_result_ids"),
        )

    def transform_row(
        self,
        row: dict,
        kind_id: UUID,
        batch_id: UUID,
        annotation_standard: "Standard",
        annotation_source: "AnnotationSource",
    ) -> AnnotationRequest:
        """Transform a single row into an AnnotationRequest."""
        annotation_value = self.create_annotation_model(row)
        return AnnotationRequest.for_file(
            file_id=UUID(str(row["file_id"])),
            kind_id=kind_id,
            annotation_value=annotation_value.model_dump(),
            standard=annotation_standard,
            annotation_source=annotation_source,
            batch_id=batch_id,
        )


# Registry of validators
_VALIDATOR_REGISTRY: dict[str, type[DataValidator]] = {
    "file_data": FileDataValidator,
    "stem_types": StemTypesValidator,
}


def get_validator_for_kind(
    annotation_kind: str, *, available_columns: Collection[str] | None = None, encrypt: bool = False
) -> DataValidator:
    """
    Get the appropriate validator for an annotation kind.

    Falls back to GenericAnnotationValidator if no specific validator is registered.
    """
    # Prefer generic validator when a column matching the kind name is present.
    # This enables a direct JSON payload path without special transformations,
    # while keeping backward compatibility with the specific validators otherwise.
    if available_columns is not None and annotation_kind in available_columns:
        logger.info(
            f"Using GenericAnnotationValidator for '{annotation_kind}' due to presence of '{annotation_kind}' column"
        )
        return GenericAnnotationValidator(annotation_kind, encrypt=encrypt)

    if annotation_kind in _VALIDATOR_REGISTRY:
        validator_class = _VALIDATOR_REGISTRY[annotation_kind]
        return validator_class()

    # Fallback to generic validator
    logger.info(f"No specific validator found for '{annotation_kind}', using GenericAnnotationValidator")
    try:
        return GenericAnnotationValidator(annotation_kind, encrypt=encrypt)
    except (ImportError, ValueError) as e:
        available_kinds = list(_VALIDATOR_REGISTRY.keys())
        msg = (
            f"Cannot create validator for annotation kind '{annotation_kind}': {e}. "
            f"Available specific validators: {available_kinds}"
        )
        raise ValueError(msg) from e


def register_validator(annotation_kind: str, validator_class: type[DataValidator]) -> None:
    """Register a new validator for an annotation kind."""
    _VALIDATOR_REGISTRY[annotation_kind] = validator_class
    logger.info(f"Registered validator for annotation kind: {annotation_kind}")


def get_available_kinds() -> list[str]:
    """Get list of annotation kinds that have validators."""
    return list(_VALIDATOR_REGISTRY.keys())
