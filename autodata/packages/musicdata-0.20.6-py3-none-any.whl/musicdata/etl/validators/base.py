"""Base data validator interface."""

import ast
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, get_args, get_origin
from uuid import UUID

import orjson
import pandas as pd
from loguru import logger

from musicdata.annotations.models.base import AnnotationArrayBase, AnnotationObjectBase
from musicdata.db.models.requests import AnnotationRequest

# Type alias to encompass both annotation base types
AnnotationBase = AnnotationObjectBase | AnnotationArrayBase

if TYPE_CHECKING:
    from musicdata.db.models import AnnotationSource, Standard


def is_value_empty_or_none(value: object) -> bool:
    """
    Check if a value is None or an empty collection.

    This is useful for handling BigQuery's behavior where NULL values
    can be converted to empty lists [] or empty dicts {} based on column type.

    Args:
        value: The value to check

    Returns:
        True if value is None, empty list, empty dict, or empty string

    Examples:
        >>> is_value_empty_or_none(None)
        True
        >>> is_value_empty_or_none([])
        True
        >>> is_value_empty_or_none({})
        True
        >>> is_value_empty_or_none("")
        True
        >>> is_value_empty_or_none([1, 2, 3])
        False
        >>> is_value_empty_or_none({"key": "value"})
        False
        >>> is_value_empty_or_none(0)
        False
    """
    if value is None:
        return True
    if isinstance(value, str):
        return len(value) == 0
    if isinstance(value, (list, dict)):
        return len(value) == 0
    return False


# Type alias for JSON columns that can contain any JSON structure
JsonType = dict | list

# Extract the constituent types from JsonType for isinstance() checks
JSON_TYPES = get_args(JsonType)

# Supported simple types for validation and parsing
SUPPORTED_SIMPLE_TYPES = {str, int, float, bool, dict, UUID, JsonType}
SUPPORTED_TYPES_MSG = (
    ", ".join(t.__name__ for t in SUPPORTED_SIMPLE_TYPES if hasattr(t, "__name__")) + ", list[T], JsonType"
)


def _parse_dict_value(value: str) -> dict:
    """Parse a dictionary from JSON string representation."""
    try:
        parsed_value = orjson.loads(value)
        if isinstance(parsed_value, dict):
            return parsed_value
        # Successfully parsed but it's not a dict - this is an error
        msg = f"Expected dict but got {type(parsed_value).__name__}: {value}"
        raise ValueError(msg)  # noqa: TRY301
    except (orjson.JSONDecodeError, ValueError) as e:
        msg = f"Failed to parse dict from JSON: {value}"
        raise ValueError(msg) from e


def _parse_json_value(value: str) -> JsonType:
    """Parse any valid JSON from string representation (dict, list, etc.)."""
    try:
        parsed_value = orjson.loads(value)
        if isinstance(parsed_value, JSON_TYPES):
            return parsed_value
        # Successfully parsed but it's not a supported container type
        msg = f"Expected dict or list but got {type(parsed_value).__name__}: {value}"
        raise ValueError(msg)  # noqa: TRY301
    except (orjson.JSONDecodeError, ValueError) as e:
        msg = f"Failed to parse JSON: {value}"
        raise ValueError(msg) from e


def _parse_list_value(value: str) -> list:
    """Parse a list from string representation."""
    try:
        parsed_value = ast.literal_eval(value)
        if isinstance(parsed_value, list):
            return parsed_value
        # Successfully parsed but it's not a list - this is an error
        msg = f"Expected list but got {type(parsed_value).__name__}: {value}"
        raise ValueError(msg)  # noqa: TRY301
    except (ValueError, SyntaxError) as e:
        msg = f"Failed to parse list from: {value}"
        raise ValueError(msg) from e


def _parse_simple_type(value: str, target_type: type) -> str | int | float | bool | dict | UUID | list:
    """Parse simple types from string."""
    try:
        if issubclass(target_type, str):
            return str(value)
        if issubclass(target_type, (int, float)):
            return target_type(pd.to_numeric(value))
        if issubclass(target_type, bool):
            return bool(value)
        if issubclass(target_type, dict):
            return _parse_dict_value(value)
        if target_type is JsonType:
            return _parse_json_value(value)
        if issubclass(target_type, UUID):
            return UUID(str(value))
        # If we reach here, it's an unsupported simple type
        msg = f"Unsupported simple type: {target_type.__name__}. Supported types: {SUPPORTED_TYPES_MSG}"
        logger.error(msg)
        error_msg = f"Unsupported simple type: {target_type.__name__}"
        raise ValueError(error_msg)  # noqa: TRY301
    except (ValueError, TypeError) as e:
        logger.warning(f"Cannot convert {value} to {target_type.__name__}: {e}")
        raise


def _validate_int_conversion(series: pd.Series, column: str) -> None:
    """Validate that numeric series can be safely converted to int without data loss."""
    has_decimals = series.notna() & (series % 1 != 0)
    if has_decimals.any():
        decimal_count = has_decimals.sum()
        decimal_values = series[has_decimals].iloc[:5]  # Show first 5 examples
        msg = (
            f"Column '{column}' contains {decimal_count} decimal values but target type is int. "
            f"Cannot convert without data loss. Examples: {decimal_values.tolist()}"
        )
        raise ValueError(msg)


def _ensure_no_nan_values(series: pd.Series) -> pd.Series:
    """Ensure all NaN values in series are converted to None."""
    if series.isna().any():
        return series.astype(object).where(series.notna(), None)
    return series


def _parse_string_column(series: pd.Series) -> pd.Series:
    """Parse series to string type."""
    return series.astype(str)


def _parse_numeric_column(series: pd.Series, target_type: type, column: str) -> pd.Series:
    """Parse series to numeric type (int or float)."""
    parsed_series = pd.to_numeric(series, errors="coerce")

    if target_type is int:
        _validate_int_conversion(parsed_series, column)
        # Convert to int, preserving NaN for later conversion
        parsed_series = parsed_series.astype("Int64").astype(object)

    return parsed_series


def _parse_boolean_column(series: pd.Series) -> pd.Series:
    """Parse series to boolean type."""
    # Handle string boolean representations
    if series.dtype == "object":
        # Convert common string representations to boolean
        bool_map = {
            "true": True,
            "false": False,
            "1": True,
            "0": False,
            "yes": True,
            "no": False,
            "y": True,
            "n": False,
        }
        parsed_series = series.astype(str).str.lower().map(bool_map)
        # Fill unmapped values with original logic
        unmapped_mask = parsed_series.isna() & series.notna()
        if unmapped_mask.any():
            parsed_series.loc[unmapped_mask] = series.loc[unmapped_mask].astype(bool)
    else:
        parsed_series = series.astype(bool)

    return parsed_series


def _parse_dict_column(series: pd.Series) -> pd.Series:
    """Parse series to dictionary type."""

    def safe_dict_parse(value: object) -> dict | None:
        if pd.isna(value):
            return None
        if isinstance(value, dict):
            return value
        if isinstance(value, str):
            return _parse_dict_value(value)
        # For non-string, non-dict, non-null values, raise an error
        msg = f"Cannot parse value of type {type(value).__name__} to dict: {value}"
        raise ValueError(msg)

    return series.apply(safe_dict_parse)


def _parse_json_column(series: pd.Series) -> pd.Series:
    """Parse series to JSON type (dict or list)."""

    def safe_json_parse(value: object) -> JsonType | None:
        # Handle numpy arrays first, before pd.isna() which can cause issues with arrays
        if callable(getattr(value, "tolist", None)):
            try:
                return value.tolist()  # pyright: ignore[reportAttributeAccessIssue]
            except Exception:  # noqa: BLE001, S110
                pass  # Fall through to other checks

        # Use try-except for pd.isna to handle numpy arrays that might cause truth value errors
        try:
            if pd.isna(value):
                return None
        except ValueError:
            # pd.isna() failed (likely due to numpy array), assume not null and continue
            pass

        if isinstance(value, JSON_TYPES):
            return value
        if isinstance(value, str):
            return _parse_json_value(value)
        # For non-string, non-dict/list, non-null values, raise an error
        msg = f"Cannot parse value of type {type(value).__name__} to JSON: {value}"
        raise ValueError(msg)

    return series.apply(safe_json_parse)


def _parse_uuid_column(series: pd.Series) -> pd.Series:
    """Parse series to UUID type."""

    def safe_uuid_parse(value: object) -> UUID | None:
        if pd.isna(value):
            return None
        if isinstance(value, UUID):
            return value
        if isinstance(value, str):
            return UUID(value)
        # For non-string, non-UUID, non-null values, raise an error
        msg = f"Cannot parse value of type {type(value).__name__} to UUID: {value}"
        raise ValueError(msg)

    return series.apply(safe_uuid_parse)


def _apply_row_by_row_parsing(series: pd.Series, target_type: type) -> pd.Series:
    """Apply row-by-row parsing for complex types or when vectorized parsing fails."""

    def safe_parse(value) -> str | list | int | float | bool | dict | UUID | None:  # noqa: ANN001, PLR0911
        """Parse individual values safely."""
        # Check if value is already the correct type
        if get_origin(target_type) is list:
            # For list types, check if it's already a list
            if isinstance(value, list):
                return value
            # Handle numpy arrays - convert them to lists
            if hasattr(value, "__array__") and hasattr(value, "tolist"):
                return value.tolist()
        elif target_type is JsonType:
            # For JSON types, check if it's already a dict or list
            if isinstance(value, JSON_TYPES):
                return value
        elif target_type in SUPPORTED_SIMPLE_TYPES and isinstance(value, target_type):
            # For simple types, check directly
            return value

        # Try to parse strings
        if isinstance(value, str):
            # Handle list types
            if get_origin(target_type) is list:
                return _parse_list_value(value)
            # Handle simple types
            if target_type in SUPPORTED_SIMPLE_TYPES:
                return _parse_simple_type(value, target_type)
            # Unsupported target type
            logger.error(f"Unsupported target type: {target_type}. Supported types: {SUPPORTED_TYPES_MSG}")
            return None

        # For non-string values with unsupported types
        if get_origin(target_type) is not list and target_type not in SUPPORTED_SIMPLE_TYPES:
            logger.error(f"Unsupported target type: {target_type}. Supported types: {SUPPORTED_TYPES_MSG}")
        else:
            logger.warning(f"Cannot parse value of type {type(value).__name__} to {target_type}. Value: {value}")

        return None

    return series.apply(safe_parse)


def _column_already_correct_type(series: pd.Series, target_type: type) -> bool:
    """
    Check if a pandas Series already contains values of the target type.

    This is more sophisticated than just checking dtype, since many types
    (dict, list, custom objects) all have dtype 'object' in pandas.
    """
    # For non-object dtypes, we can check directly
    if series.dtype != "object":
        return series.dtype == target_type

    # For object dtype, we need to check actual values
    # Sample a few non-null values to check their types
    non_null_values = series.dropna()
    if len(non_null_values) == 0:
        return True  # Empty series can be considered "correct" for any type

    # Check first few values (up to 5) to determine type
    sample_size = min(5, len(non_null_values))
    sample_values = non_null_values.iloc[:sample_size]

    # Check if all sampled values are of the target type
    if target_type is JsonType:
        # For JSON type, check if values are dict or list
        return all(isinstance(val, JSON_TYPES) for val in sample_values)

    return all(isinstance(val, target_type) for val in sample_values)


def parse_column_to_type(df: pd.DataFrame, column: str, target_type: type, *, inplace: bool = True) -> pd.Series:
    """
    Utility function to parse a DataFrame column to a specific type.

    Args:
        df: DataFrame containing the column
        column: Name of the column to parse
        target_type: Target type (e.g., list[str], int, float)
        inplace: Whether to modify the DataFrame in place

    Returns:
        Parsed Series

    Example:
        # Parse a column containing string representations of lists
        df['tags'] = parse_column_to_type(df, 'tags', list[str])

        # Or without modifying original DataFrame
        parsed_series = parse_column_to_type(df, 'tags', list[str], inplace=False)
    """

    # Capture original nulls to preserve them across parsing for all types
    original_null_mask = df[column].isna()

    # Fast path: Check if column is already the correct type
    if (
        get_origin(target_type) is None
        and target_type in SUPPORTED_SIMPLE_TYPES
        and _column_already_correct_type(df[column], target_type)
    ):
        parsed_series = df[column].copy()  # Always copy to avoid unintended mutations
    else:
        # Vectorized optimizations for simple types
        try:
            if target_type is str:
                parsed_series = _parse_string_column(df[column])
            elif target_type in (int, float):
                parsed_series = _parse_numeric_column(df[column], target_type, column)
            elif target_type is bool:
                parsed_series = _parse_boolean_column(df[column])
            elif target_type is dict:
                parsed_series = _parse_dict_column(df[column])
            elif target_type is JsonType:
                parsed_series = _parse_json_column(df[column])
            elif target_type is UUID:
                parsed_series = _parse_uuid_column(df[column])
            else:
                # For list types and other complex types, fall back to robust apply-based approach
                parsed_series = _apply_row_by_row_parsing(df[column], target_type)

        except Exception as e:  # noqa: BLE001
            # If vectorized approach fails, fall back to robust apply-based approach
            logger.warning(f"Vectorized parsing failed for column '{column}', falling back to row-by-row parsing: {e}")
            parsed_series = _apply_row_by_row_parsing(df[column], target_type)

    # Ensure original nulls stay as None regardless of parsing behavior (e.g., str casting)
    # Use mask to avoid unnecessary dtype changes; downstream _ensure_no_nan_values handles dtype.
    parsed_series = parsed_series.mask(original_null_mask, None)

    parsed_series = _ensure_no_nan_values(parsed_series)

    if inplace:
        df[column] = parsed_series
        return df[column]

    return parsed_series


class ValidationResult:
    """Result of data validation."""

    def __init__(self, *, is_valid: bool, errors: list[str] | None = None, warnings: list[str] | None = None) -> None:
        self.is_valid = is_valid
        self.errors = errors or []
        self.warnings = warnings or []

    def add_error(self, error: str) -> None:
        """Add an error to the result."""
        self.errors.append(error)
        self.is_valid = False

    def add_warning(self, warning: str) -> None:
        """Add a warning to the result."""
        self.warnings.append(warning)

    def log_results(self) -> None:
        """Log validation results."""
        if self.is_valid:
            logger.info("Data validation passed")
        else:
            logger.error("Data validation failed")

        for error in self.errors:
            logger.error(f"Validation error: {error}")

        for warning in self.warnings:
            logger.warning(f"Validation warning: {warning}")


class DataValidator(ABC):
    """Abstract base class for data validators."""

    @abstractmethod
    def get_required_columns(self) -> list[str]:
        """Get list of required column names."""

    @abstractmethod
    def get_column_data_types(self) -> dict[str, type]:
        """Get dictionary of column names and their expected data types."""

    @abstractmethod
    def create_annotation_model(self, row: dict) -> AnnotationBase:
        """
        Create the annotation schema model from row data.

        Extracts relevant fields from a row and constructs the validated
        Pydantic model instance, applying any necessary transformations
        (e.g., column mapping, value conversion, encryption).

        Args:
            row: Dictionary containing row data with required columns.

        Returns:
            Validated Pydantic model instance.

        Raises:
            ValueError: If required fields are missing or invalid.
            ValidationError: If the data fails Pydantic validation.
        """

    @abstractmethod
    def transform_row(
        self,
        row: dict,
        kind_id: UUID,
        batch_id: UUID,
        annotation_standard: "Standard",
        annotation_source: "AnnotationSource",
    ) -> AnnotationRequest:
        """
        Transform a single row into an AnnotationRequest.

        Args:
            row: DataFrame row as dict
            kind_id: Annotation kind ID
            batch_id: Batch ID for tracking
            annotation_standard: Standard level (BRONZE/SILVER/GOLD)
            annotation_source: Source of the annotation

        Returns:
            AnnotationRequest for this row
        """

    def validate_data(self, df: pd.DataFrame) -> ValidationResult:
        """Validate the DataFrame and return validation result."""
        # Start with basic column validation
        result = self.validate_columns_exist(df)

        if not result.is_valid:
            return result

        # Validate data types
        type_check_result = self.validate_data_types(df, self.get_column_data_types())
        result.errors.extend(type_check_result.errors)
        result.warnings.extend(type_check_result.warnings)
        if not type_check_result.is_valid:
            result.is_valid = False

        return result

    def is_row_payload_missing(self, row: dict) -> bool:
        """Return True if this row has no payload for the current validator's kind.

        Default behavior: if a column named after `annotation_kind` exists, treat None,
        empty lists, empty dicts, and empty strings as missing. This handles BigQuery's
        behavior where NULL values can be converted to empty collections.

        Validators with different payload columns should override this.
        """
        payload_column = getattr(self, "annotation_kind", None)
        if not payload_column or payload_column not in row:
            return False
        return is_value_empty_or_none(row[payload_column])

    def transform_to_annotation_requests(
        self,
        df: pd.DataFrame,
        kind_id: UUID,
        batch_id: UUID,
        annotation_standard: "Standard",
        annotation_source: "AnnotationSource",
    ) -> tuple[list[AnnotationRequest], list[tuple[dict, str, dict]]]:
        """
        Transform DataFrame to AnnotationRequest instances with error recovery.

        This method is only available for annotation validators that implement transform_row.

        Returns:
            Tuple of (successful_requests, failed_rows)
            - successful_requests: List of successfully created AnnotationRequest objects
            - failed_rows: List of (row_dict, error_message) tuples for rows that failed transformation
        """
        # Get annotation kind from the validator if it has one
        annotation_kind = getattr(self, "annotation_kind", self.__class__.__name__)
        logger.info(f"Starting transformation of {len(df)} rows for kind '{annotation_kind}'...")

        rows = df.to_dict("records")
        successful_requests = []
        failed_rows = []

        for row in rows:
            # Gracefully skip rows where the current kind payload is missing/None.
            if self.is_row_payload_missing(row):
                continue
            try:
                request = self.transform_row(
                    row=row,
                    kind_id=kind_id,
                    batch_id=batch_id,
                    annotation_standard=annotation_standard,
                    annotation_source=annotation_source,
                )
                successful_requests.append(request)
            except Exception as e:  # noqa: BLE001
                identifier = self._extract_display_identifier(row)
                error_msg = f"{annotation_kind} transformation failed for {identifier}: {e}"
                logger.warning(f"{error_msg}. Row data: {row}")
                failed_rows.append((row, error_msg, {}))

        logger.info(
            f"Transformation complete: {len(successful_requests)} successful, "
            f"{len(failed_rows)} failed for kind '{annotation_kind}'"
        )

        return successful_requests, failed_rows

    def validate_columns_exist(self, df: pd.DataFrame) -> ValidationResult:
        """Base validation to check required columns exist."""
        result = ValidationResult(is_valid=True)
        required_columns = self.get_required_columns()
        missing_columns = [col for col in required_columns if col not in df.columns]

        if missing_columns:
            result.add_error(f"Missing required columns: {missing_columns}")

        # Check for extra columns that might indicate data issues
        extra_columns = [col for col in df.columns if col not in required_columns]
        if extra_columns:
            logger.debug(f"Extra columns found (will be ignored): {extra_columns}")

        return result

    def validate_data_types(self, df: pd.DataFrame, type_mapping: dict[str, type]) -> ValidationResult:
        """
        Validate that columns have expected data types and transform them.

        This method uses parse_column_to_type internally to ensure consistent
        parsing behavior across the validation framework.

        Args:
            df: DataFrame to validate and transform
            type_mapping: Dictionary mapping column names to expected types

        Returns:
            ValidationResult indicating success/failure with any errors
        """
        result = ValidationResult(is_valid=True)

        # Pre-validate supported types
        for col, expected_type in type_mapping.items():
            if get_origin(expected_type) is not list and expected_type not in SUPPORTED_SIMPLE_TYPES:
                result.add_error(
                    f"Unsupported type '{expected_type}' for column '{col}'. Supported types: {SUPPORTED_TYPES_MSG}"
                )

        for col, expected_type in type_mapping.items():
            if col not in df.columns:
                continue  # Missing column error is already logged in validate_columns_exist

            try:
                parse_column_to_type(df, col, expected_type, inplace=True)
                logger.debug(f"Successfully parsed column '{col}' as {expected_type}")

            except (ValueError, TypeError) as e:
                result.add_error(f"Column '{col}' cannot be converted to {expected_type.__name__}: {e}")

        return result

    def _extract_display_identifier(self, row_data: dict) -> str:
        """
        Extract a display identifier from row data for logging purposes.

        Args:
            row_data: Dictionary containing row data

        Returns:
            String identifier in format "key=value" for logging
        """
        # Priority order for identifier extraction
        if "file_id" in row_data and row_data["file_id"] is not None:
            return f"file_id={row_data['file_id']}"
        if "song_id" in row_data and row_data["song_id"] is not None:
            return f"song_id={row_data['song_id']}"
        return "entity_id=unknown"
