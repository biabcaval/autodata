"""Group-aware streaming buffer for preserving entity boundaries."""

from collections.abc import Generator
from typing import Any

from loguru import logger


class DictGroupAwareStreamBuffer:
    """
    Dict-based buffer that ensures entity groups (songs/files) are not split across chunks.

    Assumes source data is pre-sorted by group columns (enforced via ORDER BY in queries).
    This design choice simplifies the buffer logic and improves performance by:
    - Eliminating in-memory sorting operations
    - Minimizing carry-over between chunks (groups are naturally together)
    - Leveraging database-level sorting optimization

    This is critical for maintaining data integrity when load_songs_and_files=True,
    as all rows for a song must be processed together for dataset validation and
    atomic insertion.

    For annotation-only mode (load_songs_and_files=False), no buffering is needed
    as annotations are independent entities.
    """

    def __init__(self, group_by_cols: list[str]) -> None:
        """
        Initialize buffer.

        Args:
            group_by_cols: Columns defining groups (e.g., ["song_id"] or ["song_id", "file_id"])
        """
        self.group_by_cols = group_by_cols
        self.carry_buffer: list[dict[str, Any]] = []
        logger.info(f"Initialized dict group-aware buffer (grouping by: {group_by_cols}, expects pre-sorted data)")

    def process_stream(
        self,
        source_chunks: Generator[list[dict[str, Any]], None, None],
    ) -> Generator[list[dict[str, Any]], None, None]:
        """
        Process incoming stream and yield chunks with complete groups only.

        Assumes source data is pre-sorted by group columns (from ORDER BY in query).
        This eliminates the need for in-memory sorting and significantly improves
        performance for large datasets.

        Algorithm:
        1. Receive chunk from source (already sorted)
        2. Extend with any carried-over rows from previous chunk
        3. Identify last incomplete group (group that might continue in next chunk)
        4. Yield all complete groups
        5. Carry over last group to next iteration
        6. After stream ends, yield final carried group

        Args:
            source_chunks: Generator of dict lists from source adapter (pre-sorted)

        Yields:
            Lists of dicts containing only complete groups
        """
        for incoming_chunk in source_chunks:
            if not incoming_chunk:
                continue

            # Combine with carried buffer
            current = self.carry_buffer + incoming_chunk if self.carry_buffer else incoming_chunk

            # Source data is already sorted by group columns, no need to sort again
            # This is enforced by ORDER BY in BigQuery/CSV source queries

            # Find last group boundary
            if not current:
                continue

            last_row = current[-1]
            last_group_values = tuple(last_row.get(col) for col in self.group_by_cols)

            # Find where the last group starts
            last_group_start_idx = None
            for i in range(len(current) - 1, -1, -1):
                row_group_values = tuple(current[i].get(col) for col in self.group_by_cols)
                if row_group_values != last_group_values:
                    last_group_start_idx = i + 1
                    break

            if last_group_start_idx is None:
                # Entire chunk is a single group - carry forward
                self.carry_buffer = current
            elif last_group_start_idx == 0:
                # Last group starts at the beginning - carry forward entire chunk
                self.carry_buffer = current
            else:
                # Split: yield complete groups, carry last group
                complete_groups = current[:last_group_start_idx]
                self.carry_buffer = current[last_group_start_idx:]

                if complete_groups:
                    yield complete_groups

        # Yield final carried data
        if self.carry_buffer:
            yield self.carry_buffer
            self.carry_buffer = []


def create_dict_stream_buffer(
    source_stream: Generator[list[dict[str, Any]], None, None],
    *,
    enable_group_buffering: bool,
    group_by_cols: list[str] | None = None,
) -> Generator[list[dict[str, Any]], None, None]:
    """
    Create appropriate dict stream buffer based on processing mode.

    Args:
        source_stream: Raw dict stream from source adapter
        enable_group_buffering: Whether to buffer for group boundaries (required for
            entity creation or file updates where all rows for a song must be together)
        group_by_cols: Columns to group by (required if enable_group_buffering=True)

    Returns:
        Generator that yields properly buffered dict chunks

    Raises:
        ValueError: If enable_group_buffering=True but group_by_cols not provided
    """
    if not enable_group_buffering:
        # Annotation-only mode - pass through directly
        logger.info("Using pass-through buffering (annotation-only mode)")
        yield from source_stream
        return

    # Group-aware buffering for entity creation or file updates
    if not group_by_cols:
        msg = "group_by_cols required when enable_group_buffering=True"
        raise ValueError(msg)

    buffer = DictGroupAwareStreamBuffer(group_by_cols)
    yield from buffer.process_stream(source_stream)
