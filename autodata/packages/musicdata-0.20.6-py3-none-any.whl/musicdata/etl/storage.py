"""
Storage backend for ETL results using DuckDB.

This module provides a DuckDBStore class that encapsulates all interactions with the
DuckDB database, including connection management, data insertion, querying, and
robust resource cleanup.
"""

import atexit
import contextlib
import tempfile
import uuid
from collections.abc import Generator
from pathlib import Path
from types import TracebackType
from typing import Any

import duckdb
import pandas as pd
import stamina
from loguru import logger

# Global registry to track all DuckDBStore instances for cleanup
_store_registry: dict[int, "DuckDBStore"] = {}


def _cleanup_all_stores() -> None:
    """Cleanup function called at exit to ensure all stores are closed."""
    for store in list(_store_registry.values()):
        with contextlib.suppress(Exception):
            store.close()
    _store_registry.clear()


# Register cleanup functions
atexit.register(_cleanup_all_stores)


class DuckDBStore:
    """
    Manages a DuckDB database for storing ETL processing results.

    This class handles connection management, temporary file creation, and ensures
    robust cleanup of database resources.

    Note: This is used ONLY for results aggregation from parallel workers,
    not for staging input data.
    """

    def __init__(self, db_path: str | None = None) -> None:
        """
        Initialize the DuckDB store.

        If `db_path` is not provided, a temporary database file will be created.

        Args:
            db_path: Optional path to a DuckDB database file.
        """
        self.db_path: str
        self.temp_file_created: bool
        self.is_closed: bool = False
        self.pending_inserts: int = 0
        self.batch_size: int = 1000

        if db_path:
            self.db_path = db_path
            # If the path is provided by the caller, we didn't create it here,
            # so we should not delete it automatically on close.
            # Ensure the parent directory exists so DuckDB can create the file.
            parent_dir = Path(self.db_path).parent
            parent_dir.mkdir(parents=True, exist_ok=True)
            self.temp_file_created = False
        else:
            temp_dir = Path(tempfile.gettempdir()) / "etl_results"
            temp_dir.mkdir(exist_ok=True)
            unique_suffix = uuid.uuid4().hex
            self.db_path = str(temp_dir / f"etl_results_{unique_suffix}.db")
            self.temp_file_created = True

        self.conn: duckdb.DuckDBPyConnection | None = duckdb.connect(self.db_path)
        # Set memory limit to avoid OOM errors during multiple workers processing chunks in parallel
        self.conn.execute("SET memory_limit = '1GB'")
        # DuckDB defaults to using all available CPU cores, which is optimal for our use case
        self._create_tables()

        # Start explicit transaction for results table batching
        self.conn.execute("BEGIN TRANSACTION")

        # Register instance for cleanup
        _store_registry[id(self)] = self

    def __del__(self) -> None:
        """Ensure cleanup happens during garbage collection."""
        if _store_registry is not None:
            _store_registry.pop(id(self), None)
        self.close()

    def __enter__(self) -> "DuckDBStore":
        """Context manager entry."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Context manager exit with cleanup."""
        self.close()

    def _create_tables(self) -> None:
        """Create DuckDB tables for storing results if they don't exist."""
        if self.conn is None:
            return

        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS results (
                id INTEGER,
                entity_data TEXT,
                raw_data TEXT,
                entity_type VARCHAR,
                status VARCHAR,
                reason VARCHAR,
                error VARCHAR,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self.conn.execute("CREATE INDEX IF NOT EXISTS idx_results_entity_type ON results(entity_type)")
        self.conn.execute("CREATE INDEX IF NOT EXISTS idx_results_status ON results(status)")
        self.conn.execute("CREATE INDEX IF NOT EXISTS idx_results_entity_type_status ON results(entity_type, status)")

    def _ensure_connection(self) -> None:
        """
        Ensure database connection is available.

        Raises:
            RuntimeError: If database connection is not available
        """
        if self.conn is None:
            msg = "Database connection is not available"
            raise RuntimeError(msg)

    def add_result(self, params: list[Any]) -> None:
        """
        Add a processing result to the database.

        Args:
            params: A list of parameters to insert into the results table.
        """
        if self.conn is None:
            return

        self.conn.execute(
            """
            INSERT INTO results (entity_data, raw_data, entity_type, status, reason, error)
            VALUES (?, ?, ?, ?, ?, ?)
        """,
            params,
        )
        self.pending_inserts += 1
        if self.pending_inserts >= self.batch_size:
            self._commit_batch()

    def add_results_from_df(self, df: pd.DataFrame) -> None:
        """Bulk insert results from a Pandas DataFrame."""
        if self.conn is None or df.empty:
            return

        try:
            # Register DataFrame as a temporary table
            self.conn.register("results_df", df)
            # Use highly optimized INSERT INTO ... SELECT FROM
            insert_sql = (
                "INSERT INTO results (entity_data, raw_data, entity_type, status, reason, error) "
                "SELECT entity_data, raw_data, entity_type, status, reason, error FROM results_df"
            )
            self.conn.execute(insert_sql)
            # Unregister the temporary table
            self.conn.unregister("results_df")
            # Explicitly commit the transaction to ensure data is written to disk
            self.conn.commit()
        except duckdb.Error as e:
            logger.exception(f"Error bulk inserting from DataFrame: {e}")
            raise

    def stream_results(
        self,
        entity_type: str | list[str] | None = None,
        status: str | None = None,
        chunk_size: int = 50000,
    ) -> Generator[list[dict[str, Any]], None, None]:
        """
        Stream results as batches of dicts using DuckDB's native Arrow format.

        Uses DuckDB → Arrow RecordBatchReader → Python dicts which is highly optimized
        (C++ conversion) and skips DataFrame overhead entirely.

        Args:
            entity_type: Filter by entity type(s)
            status: Filter by status
            chunk_size: Number of rows per batch (passed as rows_per_batch to fetch_record_batch)

        Yields:
            Batches (lists) of dicts with keys: entity_data, raw_data, reason, error

        Raises:
            RuntimeError: If database connection is not available
        """
        self._ensure_connection()
        assert self.conn is not None  # Type narrowing after _ensure_connection

        try:
            # Build query with filters
            query_parts = ["SELECT entity_data, raw_data, reason, error FROM results"]
            conditions = []
            params: list[Any] = []

            if entity_type:
                if isinstance(entity_type, list):
                    placeholders = ",".join("?" for _ in entity_type)
                    conditions.append(f"entity_type IN ({placeholders})")
                    params.extend(entity_type)
                else:
                    conditions.append("entity_type = ?")
                    params.append(entity_type)

            if status:
                conditions.append("status = ?")
                params.append(status)

            if conditions:
                query_parts.append("WHERE " + " AND ".join(conditions))

            query = " ".join(query_parts)
            result = self.conn.execute(query, params)

            # Use fetch_record_batch to get a RecordBatchReader
            # This streams Arrow batches efficiently without loading all data at once
            record_batch_reader = result.fetch_record_batch(rows_per_batch=chunk_size)

            # Iterate through the Arrow record batches
            # This is faster than DataFrame → tuple conversion and matches BigQuery pattern
            for arrow_batch in record_batch_reader:
                # Arrow's to_pylist() is highly optimized (C++ implementation)
                batch_dicts = arrow_batch.to_pylist()
                if batch_dicts:
                    yield batch_dicts

        except duckdb.Error as e:
            logger.exception(f"Error streaming results chunks: {e}")
            raise

    def _commit_batch(self) -> None:
        """
        Commit pending inserts and reset counter.

        This is for the results table batching system (add_result()).
        BEGIN TRANSACTION is needed to start a new transaction for the next batch.
        """
        if self.conn is None:
            return
        try:
            self.conn.execute("COMMIT")
            self.conn.execute("BEGIN TRANSACTION")  # Start new transaction for next batch
            self.pending_inserts = 0
        except duckdb.Error:
            self.pending_inserts = 0
            raise

    def flush(self) -> None:
        """Flush any pending inserts to the database."""
        self._commit_batch()

    def merge_from_db_file(self, other_db_path: str) -> None:
        """Merge data from another DuckDB database file into this one with optimizations."""
        if not self.conn:
            logger.error("Cannot merge into a closed store.")
            return

        if not Path(other_db_path).exists():
            logger.warning(f"Other DB path does not exist: {other_db_path}")
            return

        @stamina.retry(on=duckdb.IOException, attempts=5)
        def _do_merge() -> None:
            assert self.conn is not None

            attached = False
            try:
                # Commit any pending transaction before changing settings
                # DuckDB requires no active transaction to change WAL settings
                with contextlib.suppress(duckdb.Error):
                    self.conn.commit()

                # Optimize DuckDB for bulk merge operations
                # Delay WAL checkpoints until we're done
                self.conn.execute("SET wal_autocheckpoint='1TB'")
                self.conn.execute("SET checkpoint_threshold='1TB'")

                # Begin a new transaction for the merge
                self.conn.execute("BEGIN TRANSACTION")

                self.conn.execute(f"ATTACH '{other_db_path}' AS other_db (READ_ONLY)")
                attached = True

                # Use INSERT BY POSITION for faster inserts (bypasses column name matching)
                self.conn.execute("INSERT INTO main.results BY POSITION SELECT * FROM other_db.results")

                # Commit the merge transaction
                self.conn.commit()

            finally:
                if attached:
                    with contextlib.suppress(duckdb.Error):
                        self.conn.execute("DETACH other_db")

                # Reset WAL settings to defaults
                with contextlib.suppress(duckdb.Error):
                    self.conn.execute("SET wal_autocheckpoint='16MB'")
                    self.conn.execute("SET checkpoint_threshold='16MB'")

                # Restart transaction for subsequent operations
                with contextlib.suppress(duckdb.Error):
                    self.conn.execute("BEGIN TRANSACTION")

        try:
            _do_merge()
        except duckdb.Error as e:
            logger.exception(f"Error merging databases: {e}")
            # Ensure we rollback any failed transaction to restore connection state
            if self.conn:
                with contextlib.suppress(duckdb.Error):
                    self.conn.execute("ROLLBACK")
                # Restart transaction for subsequent operations
                with contextlib.suppress(duckdb.Error):
                    self.conn.execute("BEGIN TRANSACTION")
            raise

    def close(self, *, should_delete: bool = True) -> None:
        """
        Close the DuckDB connection and optionally clean up the database file.

        Args:
            should_delete: If False, the database file will not be deleted even if it was
                           created temporarily. This is useful for worker processes.
        """
        if self.is_closed:
            return

        if self.conn:
            # Commit any pending transactions (safety net for edge cases)
            with contextlib.suppress(duckdb.Error):
                self.conn.commit()
            with contextlib.suppress(duckdb.Error):
                self.conn.close()
            self.conn = None

        if should_delete and self.temp_file_created and Path(self.db_path).exists():
            with contextlib.suppress(OSError):
                Path(self.db_path).unlink()

        self.is_closed = True
        if _store_registry is not None:
            _store_registry.pop(id(self), None)
