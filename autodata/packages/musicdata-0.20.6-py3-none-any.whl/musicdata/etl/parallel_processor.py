"""Parallel chunk processing for high-performance ETL operations."""

import os
import sys
from collections.abc import Iterable, Iterator
from typing import cast

import duckdb
import pandas as pd
from joblib import Parallel, delayed
from loguru import logger

from musicdata.catalog import CatalogService
from musicdata.db.models.models import AnnotationBatch
from musicdata.etl.models.config import ETLConfig
from musicdata.etl.models.results import ETLResults, ProcessingStatus
from musicdata.etl.unified_processor import UnifiedGroupProcessor

# Global, process-local cache for worker-level singletons.
# Each worker process will have its own instance of these variables.
_worker_catalog_instance: CatalogService | None = None
_worker_results_instance: ETLResults | None = None
_worker_processor_instance: dict[str, UnifiedGroupProcessor] | None = None  # Keyed by config hash
_worker_log_configured: bool = False


def _get_worker_catalog() -> CatalogService:
    """
    Get or create the per-worker CatalogService singleton.

    This function ensures that each worker process initializes the service only once.
    """
    global _worker_catalog_instance  # noqa: PLW0603
    if _worker_catalog_instance is None:
        pid = os.getpid()
        logger.info(f"Worker (PID: {pid}): Initializing new CatalogService instance.")
        _worker_catalog_instance = CatalogService.create()
    return _worker_catalog_instance


def _get_worker_results() -> ETLResults:
    """
    Get or create the per-worker ETLResults singleton.

    Each worker process maintains a single DuckDB database throughout its lifetime,
    dramatically reducing the number of merge operations needed (from chunks to workers).

    The connection is closed after each chunk to release locks, but we reopen it
    to the same file when processing the next chunk.

    Returns:
        ETLResults instance for this worker process
    """
    global _worker_results_instance  # noqa: PLW0603
    if _worker_results_instance is None:
        pid = os.getpid()
        logger.info(f"Worker (PID: {pid}): Initializing new ETLResults database.")
        _worker_results_instance = ETLResults()
    elif _worker_results_instance.store.is_closed:
        # Reopen connection to the same DB file for next chunk
        db_path = _worker_results_instance.store.db_path
        _worker_results_instance = ETLResults(db_path=db_path)
        pid = os.getpid()
        logger.debug(f"Worker (PID: {pid}): Reopened connection to existing database.")
    return _worker_results_instance


def _get_worker_processor(config: ETLConfig, catalog: CatalogService) -> UnifiedGroupProcessor:
    """
    Get or create the per-worker UnifiedGroupProcessor singleton.

    Reusing the processor across chunks means validators are only initialized once
    per worker instead of once per chunk, reducing initialization overhead and log spam.

    Args:
        config: ETL configuration
        catalog: Catalog service

    Returns:
        UnifiedGroupProcessor instance for this worker process
    """
    global _worker_processor_instance  # noqa: PLW0603

    # Use a stable hash based on config content, not object identity
    # id(config) changes when config is pickled/unpickled across process boundaries
    config_key = config.model_dump_json()

    if _worker_processor_instance is None:
        _worker_processor_instance = {}

    if config_key not in _worker_processor_instance:
        pid = os.getpid()
        logger.info(f"Worker (PID: {pid}): Creating new UnifiedGroupProcessor instance.")
        _worker_processor_instance[config_key] = UnifiedGroupProcessor(config, catalog)

    return _worker_processor_instance[config_key]


def _configure_worker_logging(log_level: str, log_file_path: str) -> None:
    """Configure logging for the worker process, only once."""
    global _worker_log_configured  # noqa: PLW0603
    if not _worker_log_configured:
        logger.remove()
        logger.add(sys.stderr, level=log_level)
        logger.add(log_file_path, enqueue=True, level=log_level)
        _worker_log_configured = True


def _process_single_chunk_worker(
    chunk_num: int,
    chunk_df: pd.DataFrame,
    batch: AnnotationBatch,
    config: ETLConfig,
    *,
    log_level: str,
) -> str | Exception:
    """
    Process one chunk using unified logic and return the worker's persistent DB path.

    Each worker maintains a single DuckDB database throughout its lifetime, appending
    results from all chunks it processes. This reduces merge operations from O(chunks)
    to O(workers), typically 16 workers vs 1,236 chunks = 77x fewer merges!
    """
    worker_results = None
    try:
        _configure_worker_logging(log_level, config.log_file_path)

        # Get the persistent worker instances (one per worker process)
        # This includes catalog, results, and processor - all cached per worker
        worker_results = _get_worker_results()
        catalog = _get_worker_catalog()
        unified_processor = _get_worker_processor(config, catalog)

        # Process chunk using cached unified processor
        # Processing mode is determined by config flags in the processor
        chunk_result = unified_processor.process_chunk(
            chunk_df=chunk_df,
            chunk_num=chunk_num,
            batch=batch,
        )

        # Add results using ETLResults interface (automatic batching) regardless of success
        if chunk_result.processing_results:
            for res in chunk_result.processing_results:
                if res.status == ProcessingStatus.SUCCESS:
                    worker_results.add_success(res.entity, res.entity_type)
                elif res.status == ProcessingStatus.SKIPPED:
                    worker_results.add_skip(res.entity, res.entity_type, res.reason or "unknown")
                elif res.status == ProcessingStatus.FAILED:
                    worker_results.add_failure(res.raw_data or {}, res.entity_type, res.error or "unknown error")

        if not chunk_result.success:
            # Record chunk-level failure so it can surface in alerts
            worker_results.add_chunk_error(chunk_result.error_message or f"Chunk {chunk_num} processing failed")

        # Flush batched results to database
        worker_results.flush()

        # Close the connection to release the lock, but preserve the file
        # The worker maintains the same DB file path across chunks, but we close/reopen
        # the connection to avoid lock conflicts during merge
        db_path = worker_results.store.db_path
        worker_results.store.close(should_delete=False)

    except (ValueError, TypeError, KeyError) as e:
        logger.exception(f"Error processing chunk {chunk_num} in worker: {e}")
        # Ensure cleanup even on error
        if worker_results:
            worker_results.store.close(should_delete=True)
        return e
    else:
        # Return the worker's persistent DB path (will be the same for all chunks from this worker)
        return db_path


class ParallelChunkProcessor:
    """Handles parallel processing of data chunks using worker pool."""

    def __init__(
        self,
        config: ETLConfig,
        *,
        log_level: str = "INFO",
    ) -> None:
        """
        Initialize parallel chunk processor.

        Args:
            config: ETL configuration
            log_level: Logging level for workers
        """
        self.config = config
        self.log_level = log_level

    def iter_coalesced_chunks_dicts(
        self,
        dict_chunks: Iterable[list[dict]],
        target_rows: int,
        group_by_cols: list[str] | None = None,
    ) -> Iterator[pd.DataFrame]:
        """
        Coalesce incoming dict lists into near-uniform sub-chunks, converting to DataFrame before yielding.

        Assumes incoming dict_chunks contain complete groups (guaranteed by DictGroupAwareStreamBuffer).
        In group-aware mode, we simply find group boundaries near target_rows without worrying about
        incomplete groups from source pagination.

        Args:
            dict_chunks: Incoming stream of dict lists (groups already complete)
            target_rows: Target number of rows per sub-chunk
            group_by_cols: Columns defining groups (e.g., ["song_id"]); None for annotation-only mode

        Yields:
            DataFrames with approximately target_rows, respecting group boundaries
        """
        carry_rows: list[dict] = []

        for incoming_rows in dict_chunks:
            if not incoming_rows:
                continue

            # Combine with carried buffer
            current = carry_rows + incoming_rows if carry_rows else incoming_rows

            # Yield sub-chunks until remaining data is below target
            while len(current) >= target_rows:
                if group_by_cols:
                    # Group-aware mode: find nearest group boundary to target_rows
                    # We trust the buffer has ensured groups are complete
                    split_idx = self._find_group_boundary_near_target(current, target_rows, group_by_cols)
                    yield pd.DataFrame(current[:split_idx])
                    current = current[split_idx:]
                else:
                    # Annotation-only mode: simple split at target_rows
                    yield pd.DataFrame(current[:target_rows])
                    current = current[target_rows:]

            # Carry remaining data
            carry_rows = current if current else []

        # Yield final carried data
        if carry_rows:
            yield pd.DataFrame(carry_rows)

    def _find_group_boundary_near_target(self, rows: list[dict], target_rows: int, group_by_cols: list[str]) -> int:
        """
        Find the nearest group boundary to target_rows.

        Since DictGroupAwareStreamBuffer guarantees complete groups, we just need to find
        where one group ends and another begins, closest to target_rows.

        Strategy:
        - If row at target_rows is start of new group: split there (perfect!)
        - Otherwise: scan backwards to find where current group starts

        Args:
            rows: List of dicts (groups guaranteed complete)
            target_rows: Target number of rows
            group_by_cols: Columns defining groups

        Returns:
            Split index (always > 0 since groups are complete)
        """
        if len(rows) <= target_rows:
            return len(rows)

        # Check if target_rows is exactly at a group boundary
        if target_rows < len(rows):
            prev_group = tuple(rows[target_rows - 1].get(col) for col in group_by_cols)
            curr_group = tuple(rows[target_rows].get(col) for col in group_by_cols)

            if prev_group != curr_group:
                # Perfect! target_rows is exactly at a group boundary
                return target_rows

        # Not at boundary, scan backwards to find where current group starts
        target_group = tuple(rows[target_rows].get(col) for col in group_by_cols)

        for i in range(target_rows - 1, -1, -1):
            row_group = tuple(rows[i].get(col) for col in group_by_cols)
            if row_group != target_group:
                # Found different group, split after it
                return i + 1

        # Entire buffer is one group - emit it all
        return len(rows)

    def process_stream(
        self,
        dfs: Iterable[pd.DataFrame],
        *,
        workers: int,
        batch: AnnotationBatch,
        etl_results: ETLResults,
    ) -> int:
        """
        Process a stream of DataFrame chunks with a single, reused pool.

        DataFrames are already coalesced and sized appropriately before being passed here.
        This method:
        - Streams DataFrame tasks to the Parallel pool via a generator
        - Merges per-worker DuckDB result files into the main ETLResults store

        Processing mode (entity creation, file updates, or annotation-only) is determined
        by the config passed during initialization.

        Args:
            dfs: Stream of DataFrames (already coalesced and sized)
            workers: Number of workers for parallel processing
            batch: Annotation batch
            etl_results: Results accumulator

        Returns:
            The number of chunks processed.
        """
        total_chunks_dispatched = 0
        total_chunks_completed = 0
        total_rows_processed = 0

        # DataFrames are already coalesced by iter_coalesced_chunks_dicts before being passed here
        # Build a streaming task generator to keep the pool busy, dispatching one job per chunk

        with Parallel(
            n_jobs=workers,
            backend="loky",
            return_as="generator_unordered",
            batch_size="auto",
            pre_dispatch="2*n_jobs",
        ) as parallel:
            cumulative_chunk_num = 0

            def _tasks_stream() -> Iterator:
                nonlocal cumulative_chunk_num
                nonlocal total_rows_processed, total_chunks_dispatched
                for next_df in dfs:
                    if next_df is None or next_df.empty:
                        continue
                    rows = len(next_df)
                    total_rows_processed += rows
                    total_chunks_dispatched += 1
                    cumulative_chunk_num += 1
                    yield delayed(_process_single_chunk_worker)(
                        cumulative_chunk_num,
                        next_df.copy(),
                        batch,
                        self.config,
                        log_level=self.log_level,
                    )

            # Accumulate worker result DB paths instead of merging serially
            # Note: Multiple chunks from the same worker will return the same DB path,
            # so we use a set to deduplicate and only merge each worker DB once
            worker_db_paths_set: set[str] = set()

            for result in parallel(_tasks_stream()):
                total_chunks_completed += 1
                if isinstance(result, Exception):
                    logger.error(f"Chunk failed with an exception: {result}")
                    etl_results.add_chunk_error(f"Chunk failed: {result}")
                    continue

                worker_db_path = cast("str", result)
                if worker_db_path and os.path.exists(worker_db_path):
                    worker_db_paths_set.add(worker_db_path)

                logger.info(
                    f"Progress: {total_chunks_completed} chunks completed, {total_rows_processed:,} rows processed"
                )

            # After all workers complete, batch merge the unique worker DB files
            if worker_db_paths_set:
                unique_worker_dbs = list(worker_db_paths_set)
                logger.info(
                    f"All workers complete. Processed {total_chunks_completed} chunks using "
                    f"{len(unique_worker_dbs)} worker databases."
                )
                self._batch_merge_worker_results(unique_worker_dbs, etl_results)

        logger.info(
            "Streamed processing complete: "
            f"chunks_dispatched={total_chunks_dispatched}, "
            f"chunks_completed={total_chunks_completed}, "
            f"rows_processed={total_rows_processed}"
        )
        return total_chunks_completed

    def _batch_merge_worker_results(
        self,
        worker_db_paths: list[str],
        etl_results: ETLResults,
    ) -> None:
        """
        Merge worker DuckDB files for optimal performance.

        Each worker process maintains a single persistent database throughout its lifetime,
        so we only need to merge once per worker (typically 16-20 DBs) instead of once per
        chunk (potentially thousands).

        Note: Workers close their connections after each chunk, so the DB files should be
        unlocked and safe to merge by the time we reach here.

        Args:
            worker_db_paths: List of unique worker DuckDB file paths to merge
            etl_results: Main ETL results object to merge into
        """
        total_workers = len(worker_db_paths)
        total_merged = 0
        failed_merges = []

        logger.info(f"Starting merge of {total_workers} worker databases...")

        for worker_db_path in worker_db_paths:
            try:
                etl_results.store.merge_from_db_file(worker_db_path)
                os.remove(worker_db_path)
                total_merged += 1

                # Log progress for each worker DB (since there are relatively few)
                logger.info(f"Merged worker database {total_merged}/{total_workers}")

            except (duckdb.Error, OSError) as e:
                logger.error(f"Failed to merge worker DB {worker_db_path}: {e}")
                failed_merges.append((worker_db_path, str(e)))

        logger.info(f"Merge complete: {total_merged}/{total_workers} worker databases merged successfully")

        # Report any failed merges
        if failed_merges:
            logger.warning(f"{len(failed_merges)} worker databases failed to merge")
            for path, error in failed_merges:
                etl_results.add_chunk_error(f"Failed to merge worker DB {path}: {error}")
