"""ETL package.

Keep this file lightweight to avoid circular imports. Import classes directly
from their modules, e.g.:
    from musicdata.etl.processor import ETLProcessor
    from musicdata.etl.models.config import ETLConfig
"""

__all__: list[str] = []
