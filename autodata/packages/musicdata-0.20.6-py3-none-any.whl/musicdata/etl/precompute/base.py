from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from musicdata.db.models.models import AnnotationSource, Standard
    from musicdata.utils.encryptor import JWEEncryptor
    from musicdata.utils.files import MediaFile


class PrecomputeError(Exception):
    pass


@dataclass(frozen=True)
class StepResult:
    kind: str
    annotation_value: dict[str, Any]
    standard: Standard
    annotation_source: AnnotationSource


class PrecomputeStep(Protocol):
    """Protocol for precompute steps."""

    # Static capabilities
    requires_original: bool
    requires_cleaned: bool
    requires_encryptor: bool

    def run(
        self,
        *,
        original: MediaFile | None,
        cleaned: MediaFile | None,
        encryptor: JWEEncryptor | None,
    ) -> StepResult | None: ...


_STEP_REGISTRY: dict[str, PrecomputeStep] = {}


def register_precompute_step(kind_name: str, step: PrecomputeStep) -> None:
    """Register a precompute step by annotation kind name."""

    _STEP_REGISTRY[kind_name] = step


def get_precompute_step(kind_name: str) -> PrecomputeStep | None:
    return _STEP_REGISTRY.get(kind_name)
