from __future__ import annotations

from typing import TYPE_CHECKING

from musicdata.annotations import FileDataSchema, MediaMetadataSchema
from musicdata.annotations.models.file_data import AudioMetadata
from musicdata.db.models.models import AnnotationSource, Standard
from musicdata.utils.files import MediaFile  # noqa: TC001

if TYPE_CHECKING:
    from musicdata.utils.encryptor import JWEEncryptor

from .base import PrecomputeError, StepResult, register_precompute_step


def _extract_format_tags(media: MediaFile) -> dict[str, object]:
    return media.media_info.get("format", {}).get("tags", {}) or {}


def _extract_stream_tags(media: MediaFile) -> list[dict[str, object]]:
    return [s["tags"] for s in media.media_info.get("streams", []) if s.get("tags")]


class FileDataStep:
    requires_original = False
    requires_cleaned = True
    requires_encryptor = False

    def run(
        self,
        *,
        original: MediaFile | None,  # noqa: ARG002
        cleaned: MediaFile | None,
        encryptor: JWEEncryptor | None,  # noqa: ARG002
    ) -> StepResult | None:
        if cleaned is None:
            msg = "file_data requires cleaned media"
            raise PrecomputeError(msg)

        audio_stream = cleaned.media_info.get("streams", [])[0]
        audio_format = cleaned.media_info.get("format", {})
        size_in_bytes = int(audio_format.get("size"))
        duration = cleaned.duration
        fmt_name = audio_format.get("format_name")
        sample_rate = audio_stream.get("sample_rate")
        sample_rate = int(sample_rate) if sample_rate else None

        file_data = FileDataSchema(
            audio_metadata=AudioMetadata(
                lossless=cleaned.is_lossless_audio(),
                duration_in_secs=float(round(duration, ndigits=4)) if duration is not None else None,
                size_in_bytes=size_in_bytes,
                format=fmt_name,
                codec=audio_stream.get("codec_name"),
                bit_rate=audio_stream.get("bit_rate"),
                channels=audio_stream.get("channels"),
                channel_layout=audio_stream.get("channel_layout"),
                sample_rate=sample_rate,
            )
        )
        return StepResult(
            kind="file_data",
            annotation_value=file_data.model_dump(),
            standard=Standard.GOLD,
            annotation_source=AnnotationSource.EXTRACTED_METADATA,
        )


class MediaMetadataStep:
    requires_original = True
    requires_cleaned = False
    requires_encryptor = True

    def run(
        self,
        *,
        original: MediaFile | None,
        cleaned: MediaFile | None,  # noqa: ARG002
        encryptor: JWEEncryptor | None,
    ) -> StepResult | None:
        if original is None:
            msg = "media_metadata requires original media"
            raise PrecomputeError(msg)
        if encryptor is None:
            msg = "encryptor required for media_metadata"
            raise PrecomputeError(msg)

        format_tags = _extract_format_tags(original)
        stream_tags = _extract_stream_tags(original)

        # Skip creating annotation if no metadata found
        if not format_tags and not stream_tags:
            return None  # Will be filtered out by runner

        payload = {"format_tags": format_tags, "stream_tags": stream_tags}
        jwe_json = encryptor.encrypt_dict(payload)
        media_metadata = MediaMetadataSchema(jwe_json=jwe_json)
        return StepResult(
            kind="media_metadata",
            annotation_value=media_metadata.model_dump(),
            standard=Standard.GOLD,
            annotation_source=AnnotationSource.EXTRACTED_METADATA,
        )


# Register built-ins
register_precompute_step("file_data", FileDataStep())
register_precompute_step("media_metadata", MediaMetadataStep())
