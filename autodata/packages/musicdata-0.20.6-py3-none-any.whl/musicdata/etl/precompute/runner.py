from __future__ import annotations

import tempfile
from pathlib import Path

from loguru import logger

from musicdata.utils.encryptor import JWEEncryptor
from musicdata.utils.files import MediaFile
from musicdata.utils.gcp import BlobExt, TransactionalBlobTracker

from .base import _STEP_REGISTRY, PrecomputeError, PrecomputeStep, StepResult, get_precompute_step


def run_precompute_pipeline(
    source_blob_uri: str,
    *,
    dest_bucket: str,
    dest_blob_name: str,
    blob_tracker: TransactionalBlobTracker,
    selected_kinds: list[str],
) -> tuple[BlobExt | None, list[StepResult]]:
    if not selected_kinds:
        return None, []

    # Capability planning
    steps: list[PrecomputeStep] = []
    needs_original = False
    needs_cleaned = False
    needs_encryptor = False

    for kind in selected_kinds:
        step = get_precompute_step(kind)
        if not step:
            msg = f"No precompute step registered for kind '{kind}'. Available kinds: {list(_STEP_REGISTRY.keys())}"
            raise PrecomputeError(msg)
        steps.append(step)
        needs_original = needs_original or step.requires_original
        needs_cleaned = needs_cleaned or step.requires_cleaned
        needs_encryptor = needs_encryptor or step.requires_encryptor

    if not steps:
        return None, []

    # Create encryptor if needed
    encryptor: JWEEncryptor | None = None
    if needs_encryptor:
        try:
            encryptor = JWEEncryptor.from_env()
            # Test if the encryptor is functional by attempting to encrypt empty dict
            encryptor.encrypt_dict({})
        except ValueError as e:
            msg = (
                f"Encryption public key is required for selected precompute kinds but not available in environment: {e}"
            )
            raise PrecomputeError(msg) from e

    with tempfile.TemporaryDirectory(prefix="precompute_") as tmp_dir:
        original_media: MediaFile | None = None
        cleaned_media: MediaFile | None = None
        cleaned_blob: BlobExt | None = None

        if needs_original or needs_cleaned:
            original_blob = BlobExt.from_uri(source_blob_uri)
            name_str = str(original_blob.name)
            src_ext = Path(name_str).suffix
            local_in = Path(tmp_dir) / f"input{src_ext}"
            original_blob.download_to_filename(local_in)
            original_media = MediaFile(local_in)

        if needs_cleaned:
            if original_media is None:
                msg = "Internal error: cleaned requested without original available"
                raise PrecomputeError(msg)

            # Detect correct extension from actual file content
            detected_ext = original_media.guessed_extension
            dest_path = Path(dest_blob_name)
            original_ext = dest_path.suffix.lstrip(".")

            # Update dest_blob_name with correct extension if different
            if detected_ext and detected_ext != original_ext:
                corrected_dest_blob_name = str(dest_path.with_suffix(f".{detected_ext}"))
                logger.info(f"Corrected extension from .{original_ext} to .{detected_ext} for {dest_blob_name}")
                dest_blob_name = corrected_dest_blob_name

            cleaned_media = original_media.strip_metadata(replace_original=False)
            cleaned_blob = BlobExt(dest_bucket, dest_blob_name)

            # Track the blob for rollback (auto-detects new vs replacement).
            # After tracking, md5_hash is populated only if the blob already exists on GCS.
            blob_tracker.track(cleaned_blob)

            local_md5 = cleaned_media.get_md5_hash()
            blob_already_exists = cleaned_blob.md5_hash is not None

            # Skip upload only if blob exists and content is unchanged
            if blob_already_exists and cleaned_blob.md5_hash_decoded == local_md5:
                should_upload = False
                logger.info(f"Skipping upload for {cleaned_blob.name}: MD5 matches ({local_md5})")
            else:
                should_upload = True

            if should_upload:
                cleaned_blob.upload_from_filename(cleaned_media.file)

                logger.debug(
                    "Uploaded cleaned file to gs://{bucket}/{blob} (md5={md5})",
                    bucket=cleaned_blob.bucket.name,
                    blob=cleaned_blob.name,
                    md5=cleaned_blob.md5_hash_decoded,
                )

        results: list[StepResult] = []
        for step in steps:
            result = step.run(original=original_media, cleaned=cleaned_media, encryptor=encryptor)
            # Filter out None results (e.g., when MediaMetadataStep finds no metadata)
            if result is not None:
                results.append(result)

        return cleaned_blob, results
