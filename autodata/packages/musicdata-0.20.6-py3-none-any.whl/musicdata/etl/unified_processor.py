"""Unified processor for handling songs, files, and annotations in a single pass."""

from typing import Any
from uuid import UUID

import pandas as pd
from loguru import logger
from pydantic import BaseModel, Field
from sqlalchemy.engine import Connection

from musicdata.annotations import KindRegistry
from musicdata.catalog import AnnotationProcessingMode, CatalogService, ProcessingOptions
from musicdata.db.models.models import AnnotationBatch, FileCreationMethod, Visibility
from musicdata.db.models.requests import (
    AnnotationRequest,
    BulkSongCreationRequest,
    BulkSongUpdateRequest,
    FileRequest,
    SongRequest,
    SongUpdateRequest,
)
from musicdata.etl.models.config import ETLConfig
from musicdata.etl.models.results import ProcessingResult
from musicdata.etl.models.status import ProcessingStatus, SkipReason
from musicdata.etl.validators import DataValidator, get_validator_for_kind


class ChunkResult(BaseModel):
    """Result of processing a single chunk - unified processing results."""

    chunk_num: int
    success: bool
    processing_results: list[ProcessingResult] = Field(default_factory=list)
    error_message: str | None = None


class UnifiedGroupProcessor:
    """
    Unified processor that handles songs, files, and annotations in a single pass.

    This processor implements the unified ETL architecture with:
    - Group-aware transformation (preserves song/file boundaries)
    - Dataset validation for song-only path
    - Routing based on load_songs_and_files flag
    - Support for annotation-only, song-only, and mixed workloads
    """

    def __init__(self, config: ETLConfig, catalog: CatalogService) -> None:
        """
        Initialize unified group processor.

        Args:
            config: ETL configuration
            catalog: Catalog service for database operations
        """
        self.config = config
        self.catalog = catalog

        # Validators will be initialized per chunk based on available columns
        self.validators: dict[str, DataValidator] = {}

    def _initialize_validators(self, available_columns: pd.Index) -> None:
        """
        Initialize validators based on available columns in the current chunk.

        Validators are cached per kind to avoid recreating them for every chunk.

        Args:
            available_columns: Column names available in the chunk DataFrame
        """
        if not self.config.annotation_kinds:
            return

        for kind_cfg in self.config.annotation_kinds:
            # Only create validator if it doesn't already exist
            if kind_cfg.kind not in self.validators:
                self.validators[kind_cfg.kind] = get_validator_for_kind(
                    kind_cfg.kind,
                    available_columns=set(available_columns),
                    encrypt=kind_cfg.encrypt,
                )

    def _validate_and_parse_chunk(self, chunk_df: pd.DataFrame) -> None:
        """
        Validate and parse DataFrame columns using validators.

        This ensures all columns are properly typed before row-by-row processing.
        Modifies the DataFrame in-place.

        Args:
            chunk_df: DataFrame chunk to validate and parse

        Raises:
            ValueError: If validation fails for any configured annotation kind
        """
        if not self.config.annotation_kinds:
            return

        for kind_cfg in self.config.annotation_kinds:
            validator = self.validators.get(kind_cfg.kind)
            if validator is None:
                continue  # Will be caught later when processing rows

            # Validate and parse columns for this annotation kind
            # This modifies chunk_df in-place, converting string columns to proper types
            validation_result = validator.validate_data(chunk_df)

            if not validation_result.is_valid:
                errors_str = "; ".join(validation_result.errors)
                msg = f"Validation failed for annotation kind '{kind_cfg.kind}': {errors_str}"
                logger.error(msg)
                raise ValueError(msg)

    def process_chunk(
        self,
        chunk_df: pd.DataFrame,
        chunk_num: int,
        batch: AnnotationBatch,
    ) -> ChunkResult:
        """
        Main entry point - routes to appropriate processing path.

        Processing mode is determined by config flags:
        - config.update_files=True → File updates path (update existing files with new blobs)
        - config.load_songs_and_files=True + both file_id and path columns → Blob path (file loading)
        - config.load_songs_and_files=True + file_id XOR path → ERROR (both required for file loading)
        - config.load_songs_and_files=True + no file columns → Fast path with entity creation (song-only)
        - Neither flag set → Fast path without entity creation (annotation-only)

        Args:
            chunk_df: DataFrame chunk to process
            chunk_num: Chunk number for logging
            batch: Annotation batch

        Returns:
            ChunkResult with processing results

        Raises:
            ValueError: If load_songs_and_files=True but column configuration is inconsistent
                       (e.g., file_id exists but path is missing)
        """
        update_files = self.config.update_files
        load_songs_and_files = self.config.load_songs_and_files

        mode_desc = "update_files" if update_files else f"load_songs_and_files={load_songs_and_files}"
        logger.info(f"Processing chunk {chunk_num} with {len(chunk_df)} rows ({mode_desc})")

        # Initialize validators based on available columns in this chunk
        self._initialize_validators(chunk_df.columns)

        # Validate and parse DataFrame columns to proper types
        # This modifies chunk_df in-place before we convert to dicts
        self._validate_and_parse_chunk(chunk_df)

        try:
            # Route to file updates path if enabled
            if update_files:
                return self._process_file_updates_chunk(chunk_df, chunk_num, batch)

            # Determine path based on flag and column presence
            if load_songs_and_files:
                has_file_id = "file_id" in chunk_df.columns
                has_path = "path" in chunk_df.columns

                # Validate column consistency when load_songs_and_files=True
                if has_file_id and not has_path:
                    msg = (
                        f"Chunk {chunk_num}: load_songs_and_files=True and 'file_id' column exists, "
                        "but 'path' column is missing. When loading files, both 'file_id' and 'path' "
                        "columns are required for blob processing."
                    )
                    raise ValueError(msg)  # noqa: TRY301

                if has_path and not has_file_id:
                    msg = (
                        f"Chunk {chunk_num}: load_songs_and_files=True and 'path' column exists, "
                        "but 'file_id' column is missing. When loading files, both 'file_id' and 'path' "
                        "columns are required."
                    )
                    raise ValueError(msg)  # noqa: TRY301

                # Route to appropriate path
                if has_file_id and has_path:
                    # Both file columns present - use blob path
                    return self._process_song_file_chunk(chunk_df, chunk_num, batch)
                # No file columns - use fast path with entity creation allowed (song-only data)
                return self._process_fast_path_chunk(chunk_df, chunk_num, batch, allow_entity_creation=True)

            # Annotation-only mode - no entity creation
            return self._process_fast_path_chunk(chunk_df, chunk_num, batch, allow_entity_creation=False)

        except Exception as e:  # noqa: BLE001
            logger.exception(f"Error processing chunk {chunk_num}: {e}")
            return ChunkResult(
                chunk_num=chunk_num,
                success=False,
                error_message=f"Chunk {chunk_num} processing failed: {e}",
            )

    def _process_song_file_chunk(
        self,
        chunk_df: pd.DataFrame,
        chunk_num: int,
        batch: AnnotationBatch,
    ) -> ChunkResult:
        """
        Process chunk with songs, files, and annotations (blob path).

        This path includes:
        - Blob copying/precompute
        - Per-song atomic operations
        - File and annotation creation

        Args:
            chunk_df: DataFrame chunk (already grouped by song_id)
            chunk_num: Chunk number for logging
            batch: Annotation batch

        Returns:
            ChunkResult with processing results
        """
        logger.debug(f"Chunk {chunk_num}: Processing with blob handling")

        processing_results: list[ProcessingResult] = []

        try:
            # Transform DataFrame to requests
            bulk_request, transformation_failures = self._transform_to_song_file_requests(chunk_df, batch)

            # Add transformation failures to results
            for row_dict, error, _context in transformation_failures:
                processing_results.append(
                    ProcessingResult(
                        entity=None,
                        raw_data=row_dict,
                        entity_type=self._infer_entity_type_from_dict(row_dict),
                        status=ProcessingStatus.FAILED,
                        reason=None,
                        error=error,
                    )
                )

            # Validate no orphan songs before processing
            # In blob path, every song should have at least one file (by design)
            # But check anyway for safety
            valid_songs = []
            for song_req in bulk_request.songs:
                has_files = len(song_req.files) > 0
                has_annotations = len(song_req.annotations) > 0

                if not has_files and not has_annotations:
                    # This shouldn't happen in blob path, but guard against it
                    error_msg = f"Song {song_req.id} has no files or annotations in blob path (unexpected)"
                    processing_results.append(
                        ProcessingResult(
                            entity=None,
                            raw_data={"song_id": str(song_req.id), "dataset": song_req.dataset},
                            entity_type="song",
                            status=ProcessingStatus.FAILED,
                            reason=None,
                            error=error_msg,
                        )
                    )
                    logger.error(error_msg)
                else:
                    valid_songs.append(song_req)

            # Update bulk request with only valid songs
            bulk_request.songs = valid_songs

            # Build precompute kinds: always include file_data and media_metadata for catalog consistency
            # Merge with user-configured kinds, ensuring uniqueness while preserving order
            baseline_kinds = ["file_data", "media_metadata"]
            precompute_kinds = list(dict.fromkeys([*baseline_kinds, *self.config.precompute_kinds]))

            # Process with catalog service (sets max_workers_override to limit nested parallelism)
            if bulk_request.songs:
                # Use 1 worker in debug mode for easier debugging, otherwise 2 to limit nested parallelism
                max_workers_override = 1 if self.config.debug else 2
                raw_results = self.catalog.create_songs_bulk(
                    bulk_request,
                    options=ProcessingOptions(
                        annotation_mode=AnnotationProcessingMode.PER_SONG_ATOMIC,
                        allow_unintended_value_change=self.config.allow_unintended_value_change,
                        allow_standard_downgrade=self.config.allow_standard_downgrade,
                        skip_missing=True,
                        precompute_kinds=precompute_kinds,
                        max_workers_override=max_workers_override,
                    ),
                )

                # Convert catalog results to processing results
                processing_results.extend(self._convert_catalog_results(raw_results))

            return ChunkResult(
                chunk_num=chunk_num,
                success=True,
                processing_results=processing_results,
            )

        except Exception as e:  # noqa: BLE001
            logger.exception(f"Error processing song/file chunk {chunk_num}: {e}")
            return ChunkResult(
                chunk_num=chunk_num,
                success=False,
                processing_results=processing_results,
                error_message=str(e),
            )

    def _process_file_updates_chunk(
        self,
        chunk_df: pd.DataFrame,
        chunk_num: int,
        batch: AnnotationBatch,
    ) -> ChunkResult:
        """
        Process chunk with file updates (update existing files with new blobs).

        This path:
        - Validates required columns (song_id, file_id, path)
        - Transforms DataFrame to BulkSongUpdateRequest
        - Calls catalog.update_songs_bulk() which handles:
          - File existence validation
          - Blocking annotation checks
          - Blob processing and file_data precompute
          - Atomic file + annotation updates

        Args:
            chunk_df: DataFrame chunk (grouped by song_id)
            chunk_num: Chunk number for logging
            batch: Annotation batch

        Returns:
            ChunkResult with processing results
        """
        logger.debug(f"Chunk {chunk_num}: Processing file updates")

        processing_results: list[ProcessingResult] = []

        try:
            # Transform DataFrame to update requests
            bulk_request, transformation_failures = self._transform_to_file_update_requests(chunk_df, batch)

            # Add transformation failures to results
            for row_dict, error, _context in transformation_failures:
                processing_results.append(
                    ProcessingResult(
                        entity=None,
                        raw_data=row_dict,
                        entity_type="file",
                        status=ProcessingStatus.FAILED,
                        reason=None,
                        error=error,
                    )
                )

            # Process with catalog service
            if bulk_request.songs:
                # Use 1 worker in debug mode, otherwise 2 to limit nested parallelism
                max_workers_override = 1 if self.config.debug else 2

                # Build precompute kinds for updates
                # file_data is always included by update_songs_bulk, but we can add more
                precompute_kinds = list(dict.fromkeys(["file_data", *self.config.precompute_kinds]))

                raw_results = self.catalog.update_songs_bulk(
                    bulk_request,
                    options=ProcessingOptions(
                        annotation_mode=AnnotationProcessingMode.PER_SONG_ATOMIC,
                        allow_unintended_value_change=True,  # Required for file updates
                        allow_standard_downgrade=self.config.allow_standard_downgrade,
                        precompute_kinds=precompute_kinds,
                        max_workers_override=max_workers_override,
                    ),
                )

                # Convert catalog results to processing results
                processing_results.extend(self._convert_catalog_results(raw_results))

            return ChunkResult(
                chunk_num=chunk_num,
                success=True,
                processing_results=processing_results,
            )

        except Exception as e:  # noqa: BLE001
            logger.exception(f"Error processing file updates chunk {chunk_num}: {e}")
            return ChunkResult(
                chunk_num=chunk_num,
                success=False,
                processing_results=processing_results,
                error_message=str(e),
            )

    def _transform_to_file_update_requests(  # noqa: C901, PLR0912, PLR0915
        self,
        chunk_df: pd.DataFrame,
        batch: AnnotationBatch,
    ) -> tuple[BulkSongUpdateRequest, list[tuple[dict[str, Any], str, dict[str, Any]]]]:
        """
        Transform DataFrame to file update requests.

        Args:
            chunk_df: DataFrame chunk
            batch: Annotation batch

        Returns:
            Tuple of (BulkSongUpdateRequest, transformation_failures)
        """
        logger.debug("Transforming DataFrame to file update requests")

        valid_song_requests: list[SongUpdateRequest] = []
        failed_rows: list[tuple[dict[str, Any], str, dict[str, Any]]] = []

        # Required columns for file updates
        required_cols = {"song_id", "file_id", "path"}
        if not required_cols.issubset(chunk_df.columns):
            missing = required_cols - set(chunk_df.columns)
            error_msg = f"Missing required columns for file updates: {missing}"
            logger.error(error_msg)
            return BulkSongUpdateRequest(songs=[], batch=batch), [({"error": error_msg}, error_msg, {})]

        # Group by song_id for atomic song-level updates
        song_groups = chunk_df.groupby("song_id", dropna=True)

        for song_id_val, group_df in song_groups:
            # Validate song_id format
            try:
                song_id = UUID(str(song_id_val))
            except (ValueError, TypeError) as e:
                error_msg = f"Invalid song_id format: {e}"
                failed_rows.extend((row, error_msg, {}) for row in group_df.to_dict("records"))
                logger.warning(f"{error_msg} for song_id: {song_id_val}")
                continue

            # Process all files for this song update
            song_has_errors = False
            song_error_rows: list[tuple[dict[str, Any], str, dict[str, Any]]] = []
            song_update_request = SongUpdateRequest(
                id=song_id,
                files=[],
            )

            for row in group_df.to_dict("records"):
                try:
                    # Validate required fields
                    file_id_value = row.get("file_id")
                    path_value = row.get("path")

                    # Check file_id
                    if file_id_value is None:
                        error_msg = "Missing required field: file_id"
                        song_error_rows.append((row, error_msg, {}))
                        song_has_errors = True
                        logger.warning(f"{error_msg} in row for song {song_id}")
                        continue

                    # Check path
                    if (
                        path_value is None
                        or (isinstance(path_value, float) and pd.isna(path_value))
                        or str(path_value).strip() == ""
                    ):
                        error_msg = "Missing or empty required field: path"
                        song_error_rows.append((row, error_msg, {}))
                        song_has_errors = True
                        logger.warning(f"{error_msg} in row for song {song_id}")
                        continue

                    # Convert to proper types
                    file_id = UUID(str(file_id_value))
                    source_blob_uri = str(path_value)

                    # Create file request for update
                    # Note: md5_hash will be computed after blob processing by update_songs_bulk
                    file_request = FileRequest(
                        id=file_id,
                        song_id=song_id,
                        path=source_blob_uri,
                        md5_hash="",  # Will be set after blob processing
                        annotations=[],
                    )

                    # Process annotation columns if configured
                    if self.config.annotation_kinds:
                        file_annotations, song_annotations, kind_failures = self._extract_annotations_from_row(
                            row, batch.id
                        )
                        # For file updates, we only attach file-level annotations
                        file_request.annotations.extend(file_annotations)

                        # Song-level annotations are not supported in file update mode
                        if song_annotations:
                            logger.warning(f"Song-level annotations ignored in file update mode for song {song_id}")

                        # Track individual annotation kind failures
                        if kind_failures:
                            song_has_errors = True
                            for kind_name, error_msg in kind_failures:
                                song_error_rows.append((row, f"[{kind_name}] {error_msg}", {}))

                    # Add file to song update
                    song_update_request.files.append(file_request)

                except Exception as e:  # noqa: BLE001
                    error_msg = f"Failed to transform row: {e}"
                    song_error_rows.append((row, error_msg, {}))
                    song_has_errors = True
                    logger.warning(f"{error_msg} for song {song_id}")

            # After processing all rows in this song group
            if song_has_errors:
                # Add specific errors
                failed_rows.extend(song_error_rows)

                # Add generic error message for rows that didn't have specific errors
                already_failed_row_keys = {str(sorted(r.items())) for r, _, _ in song_error_rows}
                for row in group_df.to_dict("records"):
                    row_key = str(sorted(row.items()))
                    if row_key not in already_failed_row_keys:
                        failed_rows.append(
                            (
                                row,
                                f"Song {song_id} has validation errors in one or more files",
                                {},
                            )
                        )
                logger.info(f"Rejected song update {song_id} due to validation errors")
            elif song_update_request.files:
                # Song update is valid and has files - add to valid requests
                valid_song_requests.append(song_update_request)

        total_files = sum(len(s.files) for s in valid_song_requests)
        num_rejected = len(song_groups) - len(valid_song_requests)
        logger.info(
            f"Transformed {len(valid_song_requests)} valid song updates with {total_files} files "
            f"(rejected {num_rejected} songs with errors)"
        )

        return BulkSongUpdateRequest(songs=valid_song_requests, batch=batch), failed_rows

    def _process_fast_path_chunk(
        self,
        chunk_df: pd.DataFrame,
        chunk_num: int,
        batch: AnnotationBatch,
        *,
        allow_entity_creation: bool,
    ) -> ChunkResult:
        """
        Process chunk with songs-only or annotations-only (no blobs).

        This path:
        - Validates dataset consistency
        - Bulk creates new songs (only if allow_entity_creation=True)
        - Bulk creates annotations with skip_missing=True

        Args:
            chunk_df: DataFrame chunk
            chunk_num: Chunk number for logging
            batch: Annotation batch
            allow_entity_creation: Whether to allow creating new songs

        Returns:
            ChunkResult with processing results
        """
        logger.debug(
            f"Chunk {chunk_num}: Processing fast path (no blobs, allow_entity_creation={allow_entity_creation})"
        )

        processing_results: list[ProcessingResult] = []

        try:
            # Transform DataFrame to requests
            song_requests, annotation_requests, transformation_failures = self._transform_to_fast_path_requests(
                chunk_df, batch, allow_entity_creation=allow_entity_creation
            )

            # Add transformation failures to results
            for row_dict, error, _context in transformation_failures:
                processing_results.append(
                    ProcessingResult(
                        entity=None,
                        raw_data=row_dict,
                        entity_type=self._infer_entity_type_from_dict(row_dict),
                        status=ProcessingStatus.FAILED,
                        reason=None,
                        error=error,
                    )
                )

            # Process songs and annotations in a single transaction for atomicity
            # This ensures songs are not persisted without their annotations
            if song_requests or annotation_requests:
                with self.catalog.transaction() as conn:
                    # Process songs if any
                    if song_requests:
                        song_results = self._process_songs_fast_path(song_requests, conn)
                        processing_results.extend(song_results)

                    # Process annotations if any
                    if annotation_requests:
                        annotation_results = self.catalog.create_annotations_bulk(
                            annotation_requests,
                            batch,
                            conn,
                            options=ProcessingOptions(
                                annotation_mode=AnnotationProcessingMode.BULK_AFTER,
                                allow_unintended_value_change=self.config.allow_unintended_value_change,
                                allow_standard_downgrade=self.config.allow_standard_downgrade,
                                skip_missing=True,
                            ),
                        )
                        processing_results.extend(self._convert_catalog_results(annotation_results))

            return ChunkResult(
                chunk_num=chunk_num,
                success=True,
                processing_results=processing_results,
            )

        except Exception as e:  # noqa: BLE001
            logger.exception(f"Error processing fast path chunk {chunk_num}: {e}")
            return ChunkResult(
                chunk_num=chunk_num,
                success=False,
                processing_results=processing_results,
                error_message=str(e),
            )

    def _transform_to_song_file_requests(  # noqa: C901, PLR0912, PLR0915
        self,
        chunk_df: pd.DataFrame,
        batch: AnnotationBatch,
    ) -> tuple[BulkSongCreationRequest, list[tuple[dict[str, Any], str, dict[str, Any]]]]:
        """
        Transform DataFrame to SongRequest with files and annotations.

        For song/file path (load_songs_and_files=True):
        - Groups by song_id
        - Creates SongRequest with nested FileRequest
        - Attaches annotations to appropriate level (song vs file)
        - Validates dataset consistency

        Args:
            chunk_df: DataFrame chunk
            batch: Annotation batch

        Returns:
            Tuple of (BulkSongCreationRequest, transformation_failures)
        """
        logger.debug("Transforming DataFrame to song/file requests")

        valid_song_requests: list[SongRequest] = []
        failed_rows: list[tuple[dict[str, Any], str, dict[str, Any]]] = []

        # Expected columns: dataset, song_id, file_id, path, [annotation columns...]
        required_cols = {"dataset", "song_id", "file_id", "path"}
        if not required_cols.issubset(chunk_df.columns):
            missing = required_cols - set(chunk_df.columns)
            error_msg = f"Missing required columns: {missing}"
            logger.error(error_msg)
            return BulkSongCreationRequest(songs=[], batch=batch), [({"error": error_msg}, error_msg, {})]

        # Group by song_id for atomic song-level validation
        song_groups = chunk_df.groupby("song_id", dropna=True)

        for song_id_val, group_df in song_groups:
            # Validate song_id format
            try:
                song_id = UUID(str(song_id_val))
            except (ValueError, TypeError) as e:
                error_msg = f"Invalid song_id format: {e}"
                failed_rows.extend((row, error_msg, {}) for row in group_df.to_dict("records"))
                logger.warning(f"{error_msg} for song_id: {song_id_val}")
                continue

            # Validate dataset consistency for this song
            dataset, dataset_error = self._validate_song_dataset(group_df)
            if dataset_error:
                # Dataset validation failed - fail all rows in this song group
                failed_rows.extend((row, dataset_error, {}) for row in group_df.to_dict("records"))
                logger.warning(f"Skipping song {song_id}: {dataset_error}")
                continue
            assert dataset is not None

            # Process all files for this song
            song_has_errors = False
            song_error_rows: list[tuple[dict[str, Any], str, dict[str, Any]]] = []
            song_request = SongRequest(
                id=song_id,
                dataset=dataset,
                visibility=Visibility.PRIVATE,
                files=[],
                annotations=[],
            )

            for row in group_df.to_dict("records"):
                try:
                    # Validate required fields are not None or empty
                    # Note: After _validate_and_parse_chunk, song_id and file_id have NaN → None conversion
                    # but dataset and path are not validated by annotation validators, so may still have NaN
                    file_id_value = row.get("file_id")
                    path_value = row.get("path")

                    # Check file_id (already parsed, NaN → None)
                    if file_id_value is None:
                        error_msg = "Missing required field: file_id"
                        song_error_rows.append((row, error_msg, {}))
                        song_has_errors = True
                        logger.warning(f"{error_msg} in row for song {song_id}")
                        continue

                    # Check path (not parsed, may still have NaN)
                    if (
                        path_value is None
                        or (isinstance(path_value, float) and pd.isna(path_value))
                        or str(path_value).strip() == ""
                    ):
                        error_msg = "Missing or empty required field: path"
                        song_error_rows.append((row, error_msg, {}))
                        song_has_errors = True
                        logger.warning(f"{error_msg} in row for song {song_id}")
                        continue

                    # Now safely convert to proper types
                    file_id = UUID(str(file_id_value))
                    source_blob_uri = str(path_value)

                    # Extract optional creation_method if present
                    creation_method_value = row.get("creation_method")
                    creation_method = None
                    if creation_method_value is not None and not (
                        isinstance(creation_method_value, float) and pd.isna(creation_method_value)
                    ):
                        try:
                            creation_method = FileCreationMethod(str(creation_method_value))
                        except (ValueError, KeyError):
                            # Invalid enum value - fail the row
                            error_msg = (
                                f"Invalid creation_method value '{creation_method_value}' for file {file_id}, "
                                f"expected one of: {[e.value for e in FileCreationMethod]}"
                            )
                            song_error_rows.append((row, error_msg, {}))
                            song_has_errors = True
                            logger.warning(error_msg)
                            continue

                    # Create file request
                    file_request = FileRequest(
                        id=file_id,
                        song_id=song_id,
                        path=source_blob_uri,
                        md5_hash="",  # Will be set after blob copying
                        creation_method=creation_method,
                        annotations=[],
                    )

                    # Process annotation columns if configured
                    if self.config.annotation_kinds:
                        file_annotations, song_annotations, kind_failures = self._extract_annotations_from_row(
                            row, batch.id
                        )
                        file_request.annotations.extend(file_annotations)
                        song_request.annotations.extend(song_annotations)

                        # Track individual annotation kind failures
                        if kind_failures:
                            song_has_errors = True
                            for kind_name, error_msg in kind_failures:
                                song_error_rows.append((row, f"[{kind_name}] {error_msg}", {}))

                    # Add file to song
                    song_request.files.append(file_request)

                except Exception as e:  # noqa: BLE001
                    error_msg = f"Failed to transform row: {e}"
                    song_error_rows.append((row, error_msg, {}))
                    song_has_errors = True
                    logger.warning(f"{error_msg} for song {song_id}")

            # After processing all rows in this song group
            if song_has_errors:
                # Add specific errors
                failed_rows.extend(song_error_rows)

                # Add generic error message for rows that didn't have specific errors
                already_failed_row_keys = {str(sorted(r.items())) for r, _, _ in song_error_rows}
                for row in group_df.to_dict("records"):
                    row_key = str(sorted(row.items()))
                    if row_key not in already_failed_row_keys:
                        failed_rows.append(
                            (
                                row,
                                f"Song {song_id} has validation errors in one or more files/annotations",
                                {},
                            )
                        )
                logger.info(f"Rejected song {song_id} due to validation errors")
            else:
                # Song is valid - add to valid requests
                valid_song_requests.append(song_request)

        total_files = sum(len(s.files) for s in valid_song_requests)
        num_rejected = len(song_groups) - len(valid_song_requests)
        logger.info(
            f"Transformed {len(valid_song_requests)} valid songs with {total_files} files "
            f"(rejected {num_rejected} songs with errors)"
        )

        return BulkSongCreationRequest(songs=valid_song_requests, batch=batch), failed_rows

    def _transform_to_fast_path_requests(  # noqa: C901, PLR0912
        self,
        chunk_df: pd.DataFrame,
        batch: AnnotationBatch,
        *,
        allow_entity_creation: bool,
    ) -> tuple[list[SongRequest], list[AnnotationRequest], list[tuple[dict[str, Any], str, dict[str, Any]]]]:
        """
        Transform DataFrame to song and annotation requests (fast path).

        This method separates two concerns:
        1. Song entity creation (if allow_entity_creation=True and dataset column present)
        2. Annotation extraction (validators determine file vs song based on row content)

        Business Rule: Orphan Song Prevention
            Songs must have at least ONE of the following to be created:
            - At least one file (files list not empty)
            - At least one song-level annotation

            Songs with neither files nor annotations are rejected and added to failed_rows.
            This prevents orphan songs in the database that serve no purpose.

        Args:
            chunk_df: DataFrame chunk
            batch: Annotation batch
            allow_entity_creation: Whether to allow creating new songs

        Returns:
            Tuple of (song_requests, annotation_requests, transformation_failures)
            - song_requests: Only songs with files or annotations (no orphans)
            - annotation_requests: All valid annotations
            - transformation_failures: Includes rejected orphan songs
        """
        logger.debug("Transforming DataFrame to fast path requests")

        songs_data: dict[UUID, SongRequest] = {}
        annotation_requests: list[AnnotationRequest] = []
        failed_rows: list[tuple[dict[str, Any], str, dict[str, Any]]] = []

        # Part 1: Create song entities if allowed (requires song_id and dataset columns)
        if allow_entity_creation and "song_id" in chunk_df.columns and "dataset" in chunk_df.columns:
            # Group by song_id for dataset validation
            song_groups = chunk_df.groupby("song_id", dropna=True)  # dropna=True: skip rows without song_id

            for song_id_val, group_df in song_groups:
                try:
                    song_id = UUID(str(song_id_val))

                    # Validate dataset consistency for this song
                    dataset, dataset_error = self._validate_song_dataset(group_df)
                    if dataset_error:
                        # Dataset validation failed - record all rows in this song group as failed
                        failed_rows.extend((row, dataset_error, {}) for row in group_df.to_dict("records"))
                        logger.warning(f"Skipping song {song_id}: {dataset_error}")
                        continue

                    # Create song request if not already created
                    if song_id not in songs_data and dataset:
                        songs_data[song_id] = SongRequest(
                            id=song_id,
                            dataset=dataset,
                            visibility=Visibility.PRIVATE,
                            files=[],
                            annotations=[],
                        )

                except Exception as e:  # noqa: BLE001
                    # Song creation failed - record all rows in this song group as failed
                    error_msg = f"Failed to create song request: {e}"
                    failed_rows.extend((row, error_msg, {}) for row in group_df.to_dict("records"))
                    logger.warning(f"Failed to create song request for {song_id_val}: {e}")
                    continue

        # Part 2: Extract annotations from all rows
        # Validators determine file vs song annotation based on row content (file_id vs song_id)
        # Track which songs have annotations
        songs_with_annotations: set[UUID] = set()

        for row in chunk_df.to_dict("records"):
            try:
                file_annotations, song_annotations, kind_failures = self._extract_annotations_from_row(row, batch.id)
                annotation_requests.extend(file_annotations)
                annotation_requests.extend(song_annotations)

                # Track songs that have annotations
                for ann in song_annotations:
                    if ann.song_id:
                        songs_with_annotations.add(ann.song_id)

                # Track individual annotation kind failures
                if kind_failures:
                    for kind_name, error_msg in kind_failures:
                        failed_rows.append((row, f"[{kind_name}] {error_msg}", {}))
            except Exception as e:  # noqa: BLE001
                error_msg = f"Failed to extract annotations: {e}"
                failed_rows.append((row, error_msg, {}))
                logger.warning(f"{error_msg} in row")

        # Part 3: Validate no orphan songs (songs without files or annotations)
        # Filter out songs that have neither files nor annotations
        valid_song_requests = []
        for song_request in songs_data.values():
            has_files = len(song_request.files) > 0
            has_annotations = song_request.id in songs_with_annotations

            if not has_files and not has_annotations:
                # Orphan song - reject it
                error_msg = (
                    f"Song {song_request.id} has no files or annotations. "
                    "Songs must have at least one file or one annotation to be created."
                )
                # Add all rows for this song to failed_rows
                filtered_df = chunk_df[chunk_df["song_id"] == str(song_request.id)]
                song_rows = filtered_df.to_dict("records")  # type: ignore[call-overload]
                failed_rows.extend((row, error_msg, {}) for row in song_rows)
                logger.warning(f"Rejecting orphan song: {error_msg}")
            else:
                valid_song_requests.append(song_request)

        logger.info(
            f"Transformed {len(valid_song_requests)} valid songs (rejected {len(songs_data) - len(valid_song_requests)}"
            f" orphans) and {len(annotation_requests)} annotations (fast path)"
        )

        return valid_song_requests, annotation_requests, failed_rows

    def _process_songs_fast_path(
        self,
        song_requests: list[SongRequest],
        conn: Connection,
    ) -> list[ProcessingResult]:
        """
        Process songs in fast path (bulk insert without blobs).

        Args:
            song_requests: List of song requests
            conn: Database connection

        Returns:
            List of processing results
        """
        processing_results: list[ProcessingResult] = []

        try:
            # Extract song IDs for existence check
            song_ids = [req.id for req in song_requests]
            existing_songs = self.catalog.repos.song.do_songs_exist_bulk(song_ids, conn)

            # Separate new songs
            new_songs = [req.to_song() for req in song_requests if not existing_songs.get(req.id, False)]

            # Bulk insert new songs
            if new_songs:
                results = self.catalog.create_songs_only_bulk(new_songs, conn)
                processing_results.extend(self._convert_catalog_results(results))

            # Add skipped results for existing songs
            for req in song_requests:
                if existing_songs.get(req.id, False):
                    processing_results.append(  # noqa: PERF401
                        ProcessingResult(
                            entity=req,
                            raw_data=None,
                            entity_type="song",
                            status=ProcessingStatus.SKIPPED,
                            reason=SkipReason.SONG_EXISTS.value,
                            error=None,
                        )
                    )

        except Exception as e:  # noqa: BLE001
            logger.error(f"Error processing songs in fast path: {e}")
            for req in song_requests:
                processing_results.append(  # noqa: PERF401
                    ProcessingResult(
                        entity=None,
                        raw_data=req.model_dump() if hasattr(req, "model_dump") else {},
                        entity_type="song",
                        status=ProcessingStatus.FAILED,
                        reason=None,
                        error=str(e),
                    )
                )

        return processing_results

    def _convert_catalog_results(self, catalog_results: dict[str, Any]) -> list[ProcessingResult]:
        """
        Convert catalog service results to ProcessingResults.

        Args:
            catalog_results: Results from catalog service methods

        Returns:
            List of ProcessingResult objects
        """
        processing_results: list[ProcessingResult] = []

        # Add successful insertions
        processing_results.extend(
            [
                ProcessingResult(
                    entity=entity,
                    raw_data=None,
                    entity_type=self._infer_entity_type(entity),
                    status=ProcessingStatus.SUCCESS,
                    reason=None,
                    error=None,
                )
                for entity in catalog_results.get("inserted", [])
            ]
        )

        # Add skipped items
        processing_results.extend(
            [
                ProcessingResult(
                    entity=entity,
                    raw_data=None,
                    entity_type=self._infer_entity_type(entity),
                    status=ProcessingStatus.SKIPPED,
                    reason=reason,
                    error=None,
                )
                for (entity, reason, _context) in catalog_results.get("skipped", [])
            ]
        )

        # Add failed items
        for entity, reason, context in catalog_results.get("failed", []):
            # Prepend failure type to error message for better observability
            failure_type = context.get("failure_type")
            error_msg = f"[{failure_type}] {reason}" if failure_type else reason

            processing_results.append(
                ProcessingResult(
                    entity=None,
                    raw_data=entity.model_dump() if hasattr(entity, "model_dump") else {},
                    entity_type=self._infer_entity_type(entity) if hasattr(entity, "__class__") else "unknown",
                    status=ProcessingStatus.FAILED,
                    reason=None,
                    error=error_msg,
                )
            )

        return processing_results

    def _infer_entity_type(self, entity: Any) -> str:  # noqa: ANN401
        """Infer entity type from entity object."""
        if hasattr(entity, "__class__"):
            class_name = entity.__class__.__name__.lower()
            if "annotation" in class_name:
                return "annotation"
            if "song" in class_name:
                return "song"
            if "file" in class_name:
                return "file"
        return "unknown"

    def _infer_entity_type_from_dict(self, entity_dict: dict[str, Any]) -> str:
        """Infer entity type from dictionary data."""
        if "file_id" in entity_dict and "song_id" not in entity_dict:
            return "file"
        if "song_id" in entity_dict and "file_id" not in entity_dict:
            return "song"
        if "kind_id" in entity_dict or ("file_id" in entity_dict and "song_id" in entity_dict):
            return "annotation"
        return "unknown"

    def _validate_song_dataset(self, song_group: pd.DataFrame) -> tuple[str | None, str | None]:
        """
        Validate dataset consistency for a song group.

        Args:
            song_group: DataFrame containing rows for a single song

        Returns:
            Tuple of (dataset, error_reason)
            - dataset is None if validation fails
            - error_reason is None if validation succeeds
        """
        if "dataset" not in song_group.columns:
            return None, SkipReason.MISSING_DATASET.value

        datasets = song_group["dataset"].dropna().unique()

        if len(datasets) > 1:
            return None, SkipReason.INCONSISTENT_DATASET.value
        if len(datasets) == 0:
            return None, SkipReason.MISSING_DATASET.value
        return str(datasets[0]), None

    def _extract_annotations_from_row(
        self,
        row: dict,
        batch_id: UUID,
    ) -> tuple[list[AnnotationRequest], list[AnnotationRequest], list[tuple[str, str]]]:
        """
        Extract annotations from a row using configured validators.

        The validator's transform_row() method determines whether annotations
        are file-level or song-level based on the row contents (checking for
        'file_id' and 'song_id' keys in the row dict).

        Args:
            row: DataFrame row as dict (must contain 'song_id' and/or 'file_id')
            batch_id: Batch ID

        Returns:
            Tuple of (file_annotations, song_annotations, kind_failures)
            where kind_failures is a list of (kind_name, error_message) tuples
        """
        file_annotations: list[AnnotationRequest] = []
        song_annotations: list[AnnotationRequest] = []
        kind_failures: list[tuple[str, str]] = []

        if not self.config.annotation_kinds:
            return file_annotations, song_annotations, kind_failures

        # Process each configured annotation kind
        for kind_cfg in self.config.annotation_kinds:
            # Get the validator for this kind
            validator = self.validators.get(kind_cfg.kind)
            if validator is None:
                msg = f"No validator found for kind {kind_cfg.kind} - this should have been initialized"
                raise RuntimeError(msg)

            # Use validator to check if payload is missing for this row
            if validator.is_row_payload_missing(row):
                continue

            # Get kind_id (uses O(1) name-based cache in KindRegistry)
            try:
                kind_id = KindRegistry.get_kind_by_name(kind_cfg.kind).id
            except Exception as e:  # noqa: BLE001
                error_msg = f"Kind {kind_cfg.kind} not found: {e}"
                kind_failures.append((kind_cfg.kind, error_msg))
                logger.warning(error_msg)
                continue

            # Use the validator to transform the row into an AnnotationRequest
            # The validator handles all the logic for extracting and validating data
            try:
                annotation_request = validator.transform_row(
                    row=row,
                    kind_id=kind_id,
                    batch_id=batch_id,
                    annotation_standard=kind_cfg.annotation_standard,
                    annotation_source=kind_cfg.annotation_source,
                )

                # Categorize by entity type (file vs song)
                if annotation_request.file_id is not None:
                    file_annotations.append(annotation_request)
                else:
                    song_annotations.append(annotation_request)

            except Exception as e:  # noqa: BLE001
                # Extract identifier for better error messages
                identifier = None
                if "file_id" in row and row.get("file_id"):
                    identifier = f"file_id={row['file_id']}"
                elif "song_id" in row and row.get("song_id"):
                    identifier = f"song_id={row['song_id']}"

                # Build concise error message with identifier context
                error_msg = f"{identifier}: {e}" if identifier else str(e)

                kind_failures.append((kind_cfg.kind, error_msg))
                logger.warning(f"Annotation kind '{kind_cfg.kind}' failed: {error_msg}")
                continue

        return file_annotations, song_annotations, kind_failures
