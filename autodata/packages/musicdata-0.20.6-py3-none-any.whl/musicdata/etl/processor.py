"""Main ETL processor that orchestrates the data pipeline."""

import math
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import orjson
from loguru import logger

from musicdata.catalog import CatalogService
from musicdata.db.models.models import AnnotationBatch
from musicdata.etl.models.config import ETLConfig
from musicdata.etl.models.results import ETLAnalyzer, ETLResults
from musicdata.etl.outputs import create_output_adapter
from musicdata.etl.parallel_processor import ParallelChunkProcessor
from musicdata.etl.sources import create_source_adapter
from musicdata.etl.stream_buffer import create_dict_stream_buffer
from musicdata.utils.concurrency import ParallelOperationType, get_max_workers


class ETLProcessor:
    """Main ETL processor that orchestrates the data pipeline."""

    def __init__(self, config: ETLConfig, catalog: CatalogService | None = None, *, log_level: str = "INFO") -> None:
        """Initialize ETL processor with configuration."""
        self.config = config
        self.catalog = catalog or CatalogService.create()
        self.log_level = log_level

        # Create source adapter based on source type
        if self.config.source_type is None:
            msg = "Source type not set - configuration validation failed"
            raise ValueError(msg)
        self.source_adapter = create_source_adapter(self.config.source_type, self.config.source_details)

        # Create output adapter with dynamic timestamped folder
        self.output_location = self._create_timestamped_output_location(config.output_location)
        self.output_adapter = create_output_adapter(self.output_location)

        # Get validator for annotation kind (only if annotation processing is enabled)
        self.validator = None
        self.processing_modes = config.get_processing_modes()

        if not self.processing_modes:
            logger.warning("No processing modes configured - ETL processor will do nothing")
        else:
            logger.info(f"Initialized ETL processor with modes: {', '.join(self.processing_modes)}")

    def validate_connection(self) -> bool:
        """Validate that we can connect to the data source."""
        logger.info("Validating data source connection...")
        try:
            is_valid = self.source_adapter.validate_connection()
            if is_valid:
                logger.info("Data source connection validated successfully")
            else:
                logger.error("Data source connection validation failed")
        except Exception:  # noqa: BLE001
            logger.exception("Error validating data source connection")
            return False

        return is_valid

    def process_data(self) -> ETLResults:
        """
        Process ETL pipeline with direct stream processing.

        Architecture:
        1. Stream chunks directly from source adapter
        2. Buffer chunks for group boundaries (if needed)
        3. Process in parallel with unified processor
        4. Aggregate results

        Returns:
            ETLResults with processing statistics
        """
        logger.info(
            f"Starting direct stream ETL processing "
            f"(load_songs_and_files={self.config.load_songs_and_files}, "
            f"update_files={self.config.update_files}, "
            f"debug={self.config.debug})"
        )
        self.config.log_config()

        # Validate connection
        if not self.validate_connection():
            msg = "Data source connection validation failed"
            raise ValueError(msg)

        # Get estimated row count and check if data source is empty
        estimated_total_rows = self.source_adapter.estimated_total_rows()
        if estimated_total_rows is not None and estimated_total_rows == 0:
            logger.info("Input table is empty (0 rows). Finishing cleanly with no data to process.")
            return ETLResults()

        # Determine group columns once if needed for entity creation or update mode
        group_by_cols = None
        if self.config.load_songs_and_files or self.config.update_files:
            group_by_cols = self._determine_group_columns()
            if not group_by_cols:
                mode_name = "update_files" if self.config.update_files else "load_songs_and_files"
                msg = f"{mode_name}=True requires 'song_id' column for grouping, but it was not found in the data"
                raise ValueError(msg)

        # Create shared batch
        enhanced_description = self._create_enhanced_batch_description()
        shared_batch = AnnotationBatch(
            id=self.config.batch_id,
            description=enhanced_description,
        )

        # Process using dict streaming (all adapters support this)
        logger.info("Using dict-based streaming")
        results = self._process_stream_dicts(
            batch=shared_batch,
            group_by_cols=group_by_cols,
            estimated_total_rows=estimated_total_rows,
        )

        # Upload log artifact
        self._upload_log_artifact()

        return results

    def _determine_group_columns(self) -> list[str]:
        """
        Peek at data source to determine which columns to group by.

        Group-aware processing ensures all rows for a song are processed together.
        This is critical for:
        - Dataset validation (all files for a song must be present)
        - Atomic insertion (song + all its files in one transaction)

        Note: We only group by song_id, not file_id. While file_id may be present
        in the data, it's unique per file and shouldn't be used for grouping.
        Multiple files can belong to the same song, and we need to keep them together.

        Returns:
            ["song_id"] if song_id exists in data, [] otherwise
        """
        # Load a small sample to inspect columns
        sample = self.source_adapter.load_sample(limit=1)

        if sample.empty:
            return []

        columns = set(sample.columns)

        # Only group by song_id - this keeps all rows (including multiple files) for a song together
        if "song_id" in columns:
            return ["song_id"]

        return []

    def _process_stream_dicts(
        self,
        batch: AnnotationBatch,
        group_by_cols: list[str] | None,
        estimated_total_rows: int | None,
    ) -> ETLResults:
        """
        Process dict stream with parallel processor.

        Args:
            batch: Annotation batch for tracking
            max_workers: Maximum workers for parallel processing
            group_by_cols: Group columns (None for annotation-only mode)
            estimated_total_rows: Estimated total rows from adapter (None if unavailable)

        Returns:
            ETLResults with all processing results
        """
        etl_results = ETLResults()

        # Determine actual worker count upfront
        workers = (
            1
            if self.config.debug
            else get_max_workers(
                ParallelOperationType.CPU_BOUND,
                item_count=100,
                db_pool_size=getattr(self.catalog.repos.db.engine.pool, "size", lambda: 50)(),
            )
        )

        # Compute target_rows for worker-aware sizing
        target_rows = self._compute_target_rows(workers, estimated_total_rows)

        # Log processing plan
        logger.info(
            f"Starting parallel processing: {workers} workers, target_rows={target_rows}, "
            f"group_aware={group_by_cols is not None}"
        )

        # Get raw dict stream from source
        # Pass a chunk size as hint for source pagination to feed all workers
        raw_dict_stream = self.source_adapter.load_data_iter_dicts(chunk_size=20_000)

        # Apply group-aware buffering if needed (for entity creation or file updates)
        if group_by_cols:
            mode_name = "file updates" if self.config.update_files else "entity creation"
            logger.info(f"Using dict group-aware buffering for {mode_name} (grouping by: {group_by_cols})")
            buffered_dict_stream = create_dict_stream_buffer(
                raw_dict_stream,
                enable_group_buffering=True,
                group_by_cols=group_by_cols,
            )
        else:
            # Annotation-only mode - pass through directly
            logger.info("Using dict pass-through (annotation-only mode)")
            buffered_dict_stream = raw_dict_stream

        # Process with parallel chunk processor using dict coalescing
        parallel_processor = ParallelChunkProcessor(
            config=self.config,
            log_level=self.log_level,
        )

        # Use dict-based coalescing which converts to DataFrame before yielding to workers
        coalesced_dfs = parallel_processor.iter_coalesced_chunks_dicts(
            dict_chunks=buffered_dict_stream,
            target_rows=target_rows,
            group_by_cols=group_by_cols,
        )

        # Process the coalesced DataFrames with the standard stream processor
        parallel_processor.process_stream(
            dfs=coalesced_dfs,
            workers=workers,
            batch=batch,
            etl_results=etl_results,
        )

        etl_results.flush()

        # Generate CSV reports
        csv_files = etl_results.generate_csv_from_results(self.output_adapter, self.catalog)
        logger.info(f"Generated {len(csv_files)} CSV result files")

        # Upload results artifact
        analyzer = ETLAnalyzer(etl_results)
        summary_stats = analyzer.get_summary_stats()
        self._upload_results_artifact(summary_stats)

        return etl_results

    def _compute_target_rows(
        self,
        workers: int,
        estimated_total_rows: int | None,
    ) -> int:
        """
        Compute target rows per task for worker-aware sizing.

        Uses the formula: target_rows = clamp(
            ceil(total_rows / (workers * tasks_per_worker)),
            min_worker_chunk_rows,
            max_worker_chunk_rows
        )

        Args:
            workers: Number of workers for parallel processing
            estimated_total_rows: Estimated total rows from adapter (None if unavailable)

        Returns:
            Target rows per task
        """

        # Compute target_rows
        if self.config.tasks_per_worker == 0:
            # Worker-aware sizing disabled; use max_worker_chunk_rows directly
            target_rows = self.config.max_worker_chunk_rows
            logger.info(
                f"Worker-aware sizing disabled (tasks_per_worker=0). "
                f"Using max_worker_chunk_rows={target_rows} directly."
            )
        elif estimated_total_rows is not None:
            # Use estimate to compute worker-aware target
            raw_target = math.ceil(estimated_total_rows / (workers * self.config.tasks_per_worker))
            target_rows = max(
                self.config.min_worker_chunk_rows,
                min(raw_target, self.config.max_worker_chunk_rows),
            )
            logger.info(
                f"Worker-aware sizing: estimated_rows={estimated_total_rows}, workers={workers}, "
                f"tasks_per_worker={self.config.tasks_per_worker}, raw_target={raw_target}, "
                f"target_rows={target_rows} "
                f"(clamped to [{self.config.min_worker_chunk_rows}, {self.config.max_worker_chunk_rows}])"
            )
        else:
            # No estimate; fall back to max_worker_chunk_rows
            target_rows = self.config.max_worker_chunk_rows
            logger.info(
                f"No row estimate available from adapter. Using max_worker_chunk_rows={target_rows} as target_rows."
            )

        return target_rows

    def _create_timestamped_output_location(self, base_output_location: str) -> str:
        """Create a timestamped output location using UTC datetime and batch ID."""
        # Generate UTC timestamp in format: yyyy-MM-dd HH-mm-ss.fff
        utc_now = datetime.now(UTC)
        timestamp = utc_now.strftime("%Y-%m-%d_%H-%M-%S.%f")[:-3]  # Remove last 3 digits for .xxx format

        # Create the folder name with timestamp and batch_id
        folder_name = f"{timestamp}_{self.config.batch_id}"

        # Combine base path with timestamped folder
        if base_output_location.startswith("gs://"):
            # For GCS: gs://bucket/path -> gs://bucket/path/timestamp
            output_location = f"{base_output_location.rstrip('/')}/{folder_name}"
        else:
            # For local paths: ./path -> ./path/timestamp
            base_path = Path(base_output_location)
            output_location = str(base_path / folder_name)

        logger.info(f"Output location: {base_output_location} -> {output_location}")
        return output_location

    def _create_enhanced_batch_description(self) -> str:
        """Create an enhanced batch description with key config information."""
        base_description = self.config.insert_batch_description
        config_info = []

        # Operation mode information (mutually exclusive)
        if self.config.update_files:
            config_info.append("mode:file_update")
        elif self.config.load_songs_and_files:
            config_info.append("mode:entity_creation")

        # Core annotation fields (only if annotation processing is enabled)
        if self.config.annotation_kinds is not None:
            kinds_summary = ";".join(
                f"{k.kind}:{k.annotation_standard.value}:{k.annotation_source.value}"
                for k in self.config.annotation_kinds
            )
            config_info.append(f"kinds:[{kinds_summary}]")

        # Precompute kinds configured for song/file processing
        if getattr(self.config, "precompute_kinds", None):
            precompute_summary = ",".join(self.config.precompute_kinds)
            config_info.append(f"precompute_kinds:[{precompute_summary}]")

        # Data source information
        source_info = str(self.config.source_details.get("source", ""))
        if source_info:
            config_info.append(f"data:{source_info}")

        # Processing options
        config_info.append(f"allow_value_change:{self.config.allow_unintended_value_change}")
        config_info.append(f"allow_standard_downgrade:{self.config.allow_standard_downgrade}")

        # Combine base description with config info
        return f"{base_description} [{', '.join(config_info)}]"

    def _upload_results_artifact(self, results: dict[str, Any]) -> None:
        """Upload processing results using the configured output adapter."""
        try:
            artifact = {
                "batch_id": str(self.config.batch_id),
                "etl_results": results,
                "config": self.config.to_dict() if hasattr(self.config, "to_dict") else {},
            }

            # Generate filename
            filename = "etl_results.json"

            # Write using adapter
            output_path = self.output_adapter.write_artifact(
                content=orjson.dumps(artifact, option=orjson.OPT_INDENT_2, default=str).decode(), filename=filename
            )

            logger.info(f"Uploaded results artifact to {output_path}")

        except Exception:  # noqa: BLE001
            logger.exception("Failed to upload results artifact.")

    def _upload_log_artifact(self) -> None:
        """Upload log file artifact if it exists."""
        try:
            # Use the log file path from configuration
            log_file_path = Path(self.config.log_file_path)

            if not log_file_path.exists():
                logger.info("Log file not found - skipping upload")
                return

            # Generate filename
            filename = "etl_run.log"

            # Stream log file directly without loading into memory
            with log_file_path.open("rb") as log_file:
                output_path = self.output_adapter.write_artifact(content=log_file, filename=filename)

            logger.info(f"Uploaded log file to {output_path}")

        except Exception:  # noqa: BLE001
            logger.exception("Failed to upload log file.")
