"""BigQuery data adapter."""

from collections.abc import Generator
from typing import Any

import pandas as pd
from loguru import logger

from musicdata.db.repositories import BigQueryRepository
from musicdata.etl.sources.base import DataAdapter


class BigQueryAdapter(DataAdapter):
    """Adapter for loading data from BigQuery tables using BigQueryRepository."""

    def __init__(self, connection_params: dict[str, Any]) -> None:
        """
        Initialize BigQuery adapter.

        Args:
            connection_params: Dictionary containing 'project', 'dataset', 'table'
        """
        super().__init__(connection_params)

        self.project = connection_params["project"]
        self.dataset = connection_params["dataset"]
        self.table = connection_params["table"]

        # Validate components for security (defense in depth)
        BigQueryRepository.validate_bigquery_table_components(self.project, self.dataset, self.table)

        # Initialize BigQuery repository
        self.repository = BigQueryRepository()
        self.table_id = f"{self.project}.{self.dataset}.{self.table}"

        # Cache the ORDER BY clause for consistent ordering
        self._order_by_clause: str | None = None

        logger.info(f"Initialized BigQuery adapter for {self.table_id}")

    def estimated_total_rows(self) -> int | None:
        """
        Get estimated row count from BigQuery table/view.

        For tables: Uses fast metadata lookup (no query execution).
        For views: Executes COUNT(*) query since views don't store row counts.

        Returns:
            Estimated row count, or None if unavailable
        """
        try:
            table = self.repository.client.get_table(self.table_id)

            # For views, num_rows is typically None or 0, so we need to query
            if table.table_type == "VIEW" or not table.num_rows:
                logger.info(f"Querying row count for BigQuery view {self.table_id}")
                # table_id is already validated by BigQuery client, safe to use in query
                count_query = f"SELECT COUNT(*) as count FROM `{self.table_id}`"  # noqa: S608
                result = self.repository.client.query(count_query).result()
                row_count = next(result).count
                logger.info(f"BigQuery view {self.table_id} has {row_count:,} rows (from query)")
            else:
                # For tables, use fast metadata
                row_count = table.num_rows
                logger.info(f"BigQuery table {self.table_id} has ~{row_count:,} rows (from metadata)")
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to get row count for {self.table_id}: {e}")
            return None
        else:
            return row_count

    def load_data(self) -> pd.DataFrame:
        """Load all data from the BigQuery table."""
        logger.info(f"Loading data from BigQuery table: {self.table_id}")
        try:
            return self.repository.get_table_data(self.table_id)
        except Exception as e:
            msg = f"Failed to load data from BigQuery table {self.table_id}: {e}"
            logger.error(msg)
            raise RuntimeError(msg) from e

    def _get_order_by_clause(self) -> str:
        """Get the ORDER BY clause based on available columns in the table.

        Returns:
            SQL ORDER BY clause (including 'ORDER BY' keyword) or empty string
        """
        if self._order_by_clause is not None:
            return self._order_by_clause

        try:
            # Get table schema to check which columns exist
            table = self.repository.client.get_table(self.table_id)
            column_names = {field.name for field in table.schema}

            # Build ORDER BY clause based on available columns
            order_cols = []

            # Prefer ordering by song_id and file_id for entity grouping
            if "song_id" in column_names:
                order_cols.append("IFNULL(song_id, '') ASC")
            if "file_id" in column_names:
                order_cols.append("IFNULL(file_id, '') ASC")

            if order_cols:
                self._order_by_clause = f"ORDER BY {', '.join(order_cols)}"
                logger.info(f"Using ORDER BY clause: {self._order_by_clause}")
            else:
                # No entity columns found - no ordering
                self._order_by_clause = ""
                logger.info("No song_id or file_id columns found - data will not be ordered")

        except (RuntimeError, ValueError) as e:
            logger.warning(f"Failed to get table schema for ordering: {e}. Will not order data.")
            self._order_by_clause = ""

        return self._order_by_clause

    def load_sample(self, limit: int = 100) -> pd.DataFrame:
        """Load a sample of data for testing/validation."""
        logger.info(f"Loading sample data from BigQuery table: {self.table_id}")
        try:
            # Use execute_query for the LIMIT functionality
            # Note: table_id is already validated in __init__ so this is safe
            query = f"SELECT * FROM `{self.table_id}` LIMIT {limit}"  # noqa: S608
            return self.repository.execute_query(query)
        except Exception as e:
            msg = f"Failed to load sample data from BigQuery table {self.table_id}: {e}"
            logger.error(msg)
            raise RuntimeError(msg) from e

    def load_data_iter(self, chunk_size: int = 20000) -> Generator[pd.DataFrame, None, None]:
        """
        Stream data in chunks from BigQuery using Storage API.

        Data is always ordered by song_id and/or file_id (if these columns exist) to
        optimize group-aware buffering and minimize cross-chunk group splits.
        This ensures consistency across all ETL runs.

        Args:
            chunk_size: Number of rows per chunk (used as page_size hint)

        Yields:
            DataFrame chunks from the BigQuery table, ordered by available entity columns
        """
        logger.info(f"Streaming data from BigQuery table: {self.table_id} (chunk_size={chunk_size})")
        try:
            # Always order data for consistency - dynamically checks which columns exist
            order_clause = self._get_order_by_clause()
            query = f"SELECT * FROM `{self.table_id}` {order_clause}"  # noqa: S608
            yield from self.repository.execute_query_iter(query=query, yield_as="dataframe", page_size=chunk_size)
        except Exception as e:
            msg = f"Failed to stream data from BigQuery table {self.table_id}: {e}"
            logger.error(msg)
            raise RuntimeError(msg) from e

    def load_data_iter_dicts(self, chunk_size: int = 20000) -> Generator[list[dict], None, None]:
        """
        Stream data as lists of dicts from BigQuery using Storage API.

        This method uses Arrow streaming under the hood (to_arrow_iterable + to_pylist),
        which is memory-efficient as it processes one Arrow batch at a time.

        Data is always ordered by song_id and/or file_id (if these columns exist) to
        optimize group-aware buffering and minimize cross-chunk group splits.

        Args:
            chunk_size: Number of rows per chunk (used as page_size hint)

        Yields:
            Lists of dicts representing rows, ordered by available entity columns
        """
        logger.info(f"Streaming data as dicts from BigQuery table: {self.table_id} (chunk_size={chunk_size})")
        try:
            # Always order data for consistency - dynamically checks which columns exist
            order_clause = self._get_order_by_clause()
            query = f"SELECT * FROM `{self.table_id}` {order_clause}"  # noqa: S608
            yield from self.repository.execute_query_iter(query=query, yield_as="dict", page_size=chunk_size)
        except Exception as e:
            msg = f"Failed to stream data from BigQuery table {self.table_id}: {e}"
            logger.error(msg)
            raise RuntimeError(msg) from e
