"""CSV data adapter with true streaming support."""

from collections.abc import Generator
from typing import Any

import pandas as pd
from loguru import logger

from musicdata.etl.sources.base import DataAdapter


class CSVAdapter(DataAdapter):
    """Adapter for loading CSV data with streaming support."""

    def __init__(self, connection_params: dict[str, Any]) -> None:
        """
        Initialize CSV adapter.

        Args:
            connection_params: Dictionary containing 'source_uri'
        """
        super().__init__(connection_params)
        self.source_uri = connection_params["source_uri"]
        logger.info(f"Initialized CSV adapter for {self.source_uri}")

    def estimated_total_rows(self) -> int | None:
        """
        Get estimated row count by reading up to 100k rows.

        This provides a good balance:
        - Small files (<100k): Returns exact count
        - Large files (>100k): Returns 100k, sufficient for worker-aware sizing
        - With 16 workers and 1k max rows per task, 100k provides proper chunking
        - Fast for remote files (only reads first 100k, not entire file)

        Returns:
            Estimated row count (up to 100k), or None if unavailable
        """
        try:
            # Read up to 100k rows (first column only) to get estimate
            max_sample_rows = 100_000
            sample = pd.read_csv(self.source_uri, nrows=max_sample_rows, usecols=[0])
            row_count = len(sample)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to estimate row count for {self.source_uri}: {e}")
            return None
        else:
            if row_count == 0:
                logger.info(f"CSV {self.source_uri} is empty")
                return 0

            if row_count < max_sample_rows:
                # File has fewer than 100k rows - we have exact count
                logger.info(f"CSV {self.source_uri} has {row_count:,} rows (exact)")
            else:
                # File has at least 100k rows - use 100k as estimate
                logger.info(f"CSV {self.source_uri} has ≥{row_count:,} rows (sampled)")

            return row_count

    def load_data(self) -> pd.DataFrame:
        """Load entire CSV into memory (for small files or validation)."""
        logger.info(f"Loading CSV data from {self.source_uri}")
        try:
            data = pd.read_csv(self.source_uri)
            logger.info(f"Loaded {len(data)} rows and {len(data.columns)} columns")
        except Exception as e:
            msg = f"Failed to load CSV from {self.source_uri}: {e}"
            logger.error(msg)
            raise RuntimeError(msg) from e
        return data

    def load_sample(self, limit: int = 100) -> pd.DataFrame:
        """Load a sample for testing/validation."""
        logger.info(f"Loading sample from {self.source_uri} (limit: {limit})")
        try:
            data = pd.read_csv(self.source_uri, nrows=limit)
            logger.info(f"Loaded sample: {len(data)} rows")
        except Exception as e:
            msg = f"Failed to load sample from {self.source_uri}: {e}"
            logger.error(msg)
            raise RuntimeError(msg) from e
        return data

    def load_data_iter(self, chunk_size: int = 10000) -> Generator[pd.DataFrame, None, None]:
        """
        Stream CSV data in chunks using pandas native chunking.

        Note: CSV files should be pre-sorted by song_id, file_id for optimal performance
        with group-aware buffering. If not sorted, the buffer will still work but may
        have higher memory usage due to more carry-over between chunks.

        Args:
            chunk_size: Number of rows per chunk

        Yields:
            DataFrame chunks (in CSV file order)
        """
        logger.info(f"Streaming CSV from {self.source_uri} (chunk_size={chunk_size})")
        try:
            # Use pandas built-in chunking for CSV files
            # Pandas preserves the file order, so if CSV is pre-sorted, chunks will be sorted
            chunk_count = 0
            for chunk in pd.read_csv(self.source_uri, chunksize=chunk_size):
                chunk_count += 1
                if chunk_count % 10 == 0:
                    logger.debug(f"Streamed {chunk_count} chunks from CSV")
                yield chunk

            logger.info(f"Completed streaming {chunk_count} chunks from CSV")

        except Exception as e:
            msg = f"Failed to stream CSV from {self.source_uri}: {e}"
            logger.error(msg)
            raise RuntimeError(msg) from e

    def load_data_iter_dicts(self, chunk_size: int = 10000) -> Generator[list[dict], None, None]:
        """
        Stream CSV data as lists of dicts using pandas native chunking.

        Note: CSV files should be pre-sorted by song_id, file_id for optimal performance
        with group-aware buffering. If not sorted, the buffer will still work but may
        have higher memory usage due to more carry-over between chunks.

        Args:
            chunk_size: Number of rows per chunk

        Yields:
            Lists of dicts representing rows (in CSV file order)
        """
        logger.info(f"Streaming CSV as dicts from {self.source_uri} (chunk_size={chunk_size})")
        try:
            # Use pandas built-in chunking, then convert to dicts
            chunk_count = 0
            for chunk in pd.read_csv(self.source_uri, chunksize=chunk_size):
                chunk_count += 1
                if chunk_count % 10 == 0:
                    logger.debug(f"Streamed {chunk_count} chunks from CSV")
                # Convert DataFrame to list of dicts
                yield chunk.to_dict("records")  # type: ignore[call-overload]

            logger.info(f"Completed streaming {chunk_count} chunks from CSV")

        except Exception as e:
            msg = f"Failed to stream CSV from {self.source_uri}: {e}"
            logger.error(msg)
            raise RuntimeError(msg) from e
