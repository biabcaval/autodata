"""Base data adapter interface."""

from abc import ABC, abstractmethod
from collections.abc import Generator
from typing import Any

import pandas as pd
from loguru import logger


class DataAdapter(ABC):
    """Abstract base class for data source adapters."""

    def __init__(self, connection_params: dict[str, Any]) -> None:
        """Initialize adapter with connection parameters."""
        self.connection_params = connection_params

    @abstractmethod
    def load_data(self) -> pd.DataFrame:
        """Load data from the source and return as DataFrame."""

    @abstractmethod
    def load_sample(self, limit: int = 100) -> pd.DataFrame:
        """
        Load a sample of data for testing/validation.

        Args:
            limit: Maximum number of rows to load for the sample

        Returns:
            DataFrame with at most `limit` rows
        """

    def validate_connection(self) -> bool:
        """Validate that connection to data source is working."""
        try:
            # Use load_sample instead of load_data to avoid downloading entire dataset
            data = self.load_sample(limit=1)  # Just load 1 row for connection test

            # Check if table has structure (columns)
            if len(data.columns) == 0:
                return False

            # Check if table is empty (no rows)
            if len(data) == 0:
                logger.warning("Data source is empty (no rows). Connection is valid but no data to process.")

        except Exception as e:  # noqa: BLE001
            logger.error(f"Error validating data source connection: {e}")
            return False

        return True

    def is_empty(self) -> bool:
        """
        Check if the data source is empty (has no rows).

        Returns:
            True if the data source has no rows, False otherwise
        """
        try:
            data = self.load_sample(limit=1)
            return len(data) == 0
        except Exception as e:  # noqa: BLE001
            logger.error(f"Error checking if data source is empty: {e}")
            return False

    def estimated_total_rows(self) -> int | None:
        """
        Return an estimate of the total number of rows in the data source.

        This is used for worker-aware chunk sizing to distribute work evenly.
        Subclasses should override this if they can provide an efficient estimate
        (e.g., via COUNT(*) for databases, file size heuristics for CSVs).

        Returns:
            Estimated row count, or None if not available/too expensive to compute
        """
        return None

    def load_data_iter(self, chunk_size: int = 10000) -> Generator[pd.DataFrame, None, None]:
        """
        Stream data in chunks. Default implementation for sources without native streaming.

        Args:
            chunk_size: Number of rows per chunk

        Yields:
            DataFrame chunks

        Note:
            This default implementation loads the full dataset and then chunks it.
            Subclasses with native streaming support (e.g., BigQueryAdapter) should
            override this method for better memory efficiency.
        """
        logger.info("Using fallback chunking (loading full dataset first)")
        df = self.load_data()
        total_rows = len(df)
        logger.info(f"Chunking {total_rows} rows into chunks of {chunk_size}")

        for i in range(0, total_rows, chunk_size):
            yield df.iloc[i : i + chunk_size].copy()

    @abstractmethod
    def load_data_iter_dicts(self, chunk_size: int = 10000) -> Generator[list[dict], None, None]:
        """
        Stream data as lists of dicts.

        Args:
            chunk_size: Hint for number of rows per chunk (implementation-specific)

        Yields:
            Lists of dicts representing rows

        Note:
            All adapters must implement dict streaming. This is the primary
            streaming interface used by the ETL processor.
        """
