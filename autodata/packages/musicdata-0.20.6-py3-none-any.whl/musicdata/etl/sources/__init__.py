"""Data source adapters for ETL operations."""

from typing import TYPE_CHECKING

from musicdata.etl.sources.base import DataAdapter
from musicdata.etl.sources.bigquery import BigQueryAdapter
from musicdata.etl.sources.csv import CSVAdapter

if TYPE_CHECKING:
    from musicdata.etl.models.config import SourceType


def create_source_adapter(source_type: "SourceType", source_details: dict) -> DataAdapter:
    """Create the appropriate data adapter based on source type."""
    # Import here to avoid circular imports with SourceType enum
    from musicdata.etl.models.config import SourceType

    if source_type == SourceType.BIGQUERY:
        return BigQueryAdapter(source_details)
    if source_type == SourceType.CSV:
        return CSVAdapter(source_details)
    msg = f"Unsupported source type: {source_type}"
    raise ValueError(msg)


__all__ = ["BigQueryAdapter", "CSVAdapter", "DataAdapter", "create_source_adapter"]
