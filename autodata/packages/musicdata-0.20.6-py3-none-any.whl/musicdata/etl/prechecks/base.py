"""Plugin-based song precheck layer for generic validations.

This module defines the base interfaces, result models, a simple registry,
and a runner to execute all registered prechecks against a SongRequest.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Protocol, runtime_checkable
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class ValidationSeverity(str, Enum):
    """Severity levels for song prechecks."""

    WARNING = "warning"  # Non-blocking; mark new files as is_problematic=True
    ERROR = "error"  # Blocking; fail the song processing


class PrecheckIssue(BaseModel):
    """A single issue discovered by a precheck plugin."""

    model_config = ConfigDict(frozen=True)

    plugin: str = Field(description="Plugin name that produced this issue")
    code: str = Field(description="Short machine-readable code for the issue")
    message: str = Field(description="Human-readable description of the issue")
    severity: ValidationSeverity = Field(description="Severity of the issue")
    context: dict = Field(default_factory=dict, description="Optional structured context for debugging")


class SongPrecheckContext(BaseModel):
    """Context passed to precheck plugins with available annotation data for validation.

    Contains annotation data for all files in a song, including:
    - New files being added (with precomputed annotations if available)
    - Existing files in the database (with their latest annotations)

    This allows prechecks to validate consistency across both new and existing files
    without making additional database queries.

    Attributes:
        annotations_by_file: Maps file_id -> {kind_name -> annotation_value}.
            For example: {file_uuid: {"file_data": {...}, "media_metadata": {...}}}
    """

    model_config = ConfigDict(frozen=True)

    annotations_by_file: dict[UUID, dict[str, Any]] = Field(
        default_factory=dict, description="Annotation data grouped by file ID and kind name"
    )


@runtime_checkable
class SongPrecheck(Protocol):
    """Protocol for song precheck plugins."""

    name: str
    required_precompute_kinds: set[str]

    def run(self, song: object, context: SongPrecheckContext) -> list[PrecheckIssue]: ...


_REGISTRY: dict[str, SongPrecheck] = {}


def register_precheck(impl: SongPrecheck) -> None:
    """Register a precheck plugin using its declared name."""

    if not isinstance(impl, SongPrecheck):  # runtime structural check (names only)
        msg = "Invalid precheck implementation: missing required attributes/methods"
        raise TypeError(msg)

    _REGISTRY[impl.name] = impl


def get_precheck(name: str) -> SongPrecheck | None:
    return _REGISTRY.get(name)


def run_all_song_prechecks(song: object, context: SongPrecheckContext) -> list[PrecheckIssue]:
    """Run all registered prechecks and aggregate issues.

    Plugins that declare required_precompute_kinds will be skipped if the
    corresponding kinds are not present in the context for any file.
    """

    issues: list[PrecheckIssue] = []
    for plugin in _REGISTRY.values():  # Preserve insertion order
        if plugin.required_precompute_kinds and not _has_all_required_kinds(context, plugin.required_precompute_kinds):
            # Skip plugins whose dependencies are not satisfied
            continue
        try:
            result = plugin.run(song, context)
            issues.extend(result)
        except Exception as e:  # noqa: BLE001
            # Convert plugin crash into a blocking issue to avoid silent failures
            issues.append(
                PrecheckIssue(
                    plugin=getattr(plugin, "name", "unknown"),
                    code="plugin_error",
                    message=f"Precheck plugin error: {e}",
                    severity=ValidationSeverity.ERROR,
                    context={},
                )
            )

    return issues


def _has_all_required_kinds(context: SongPrecheckContext, required: set[str]) -> bool:
    """Return True if every required kind is present for at least one file."""

    if not required:
        return True
    available: set[str] = set()
    for kinds in context.annotations_by_file.values():
        available.update(kinds.keys())
    return required.issubset(available)
