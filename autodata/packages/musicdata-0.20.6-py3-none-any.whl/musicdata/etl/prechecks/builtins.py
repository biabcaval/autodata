"""Built-in precheck plugins."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .base import PrecheckIssue, SongPrecheckContext, ValidationSeverity, register_precheck

if TYPE_CHECKING:
    from uuid import UUID


class FileDataConsistencyPrecheck:
    """Ensure all files in the song have consistent audio tech metadata.

    Fields checked (from file_data.audio_metadata):
        - bit_rate
        - channels
        - codec
        - duration_in_secs
        - format
        - sample_rate
    """

    def __init__(self) -> None:
        self.name = "file_data_consistency"
        self.required_precompute_kinds = {"file_data"}

    # Bit rate is not consistent across files, especially for lossy or compressed files.
    _FIELDS = (
        "channels",
        "codec",
        "duration_in_secs",
        "format",
        "sample_rate",
    )

    def _values_differ(self, field: str, value1: str | float | None, value2: str | float | None) -> bool:
        """Check if two values differ, with special handling for duration_in_secs.

        For duration_in_secs, compare truncated to 3 decimal places to avoid
        false positives from floating-point precision issues.
        """
        if field == "duration_in_secs":
            # Handle None values
            if value1 is None or value2 is None:
                return value1 != value2
            # Compare truncated to 3 decimal places
            try:
                return int(float(value1) * 1000) / 1000 != int(float(value2) * 1000) / 1000
            except (ValueError, TypeError):
                return value1 != value2
        return value1 != value2

    def run(self, song: object, context: SongPrecheckContext) -> list[PrecheckIssue]:  # noqa: ARG002
        # Collect audio metadata for ALL files (both new and existing)
        # Iterate over the context which contains both new files and existing files from the database
        file_to_metadata: dict[UUID, dict[str, Any]] = {}
        for file_id, kinds in context.annotations_by_file.items():
            file_data = kinds.get("file_data")
            if not file_data:
                continue
            audio = file_data.get("audio_metadata") or {}
            file_to_metadata[file_id] = {k: audio.get(k) for k in self._FIELDS}

        if not file_to_metadata:
            return []

        # Compare all files against the first one (exemplar) and create issues directly
        exemplar_id, exemplar = next(iter(file_to_metadata.items()))
        issues = []

        for file_id, metadata in file_to_metadata.items():
            if file_id == exemplar_id:
                continue  # Skip comparing exemplar with itself

            # Find fields that differ between this file and the exemplar
            mismatches = {}
            field_descriptions = []

            for field in self._FIELDS:
                exemplar_val = exemplar.get(field)
                file_val = metadata.get(field)

                if self._values_differ(field, file_val, exemplar_val):
                    mismatches[field] = [exemplar_val, file_val]
                    field_descriptions.append(f"{field}: {exemplar_val} vs {file_val}")

            if mismatches:
                # Simplify message when only one field mismatches to avoid repetition
                if len(mismatches) == 1:
                    message = f"File {file_id} has inconsistent audio metadata: {field_descriptions[0]}"
                else:
                    message = (
                        f"File {file_id} has inconsistent audio metadata in "
                        f"{len(mismatches)} fields [{', '.join(mismatches.keys())}]: {'; '.join(field_descriptions)}"
                    )

                issues.append(
                    PrecheckIssue(
                        plugin=self.name,
                        code="file_data_mismatch",
                        message=message,
                        severity=ValidationSeverity.ERROR,
                        context={},
                    )
                )

        return issues


# Register built-ins
register_precheck(FileDataConsistencyPrecheck())
