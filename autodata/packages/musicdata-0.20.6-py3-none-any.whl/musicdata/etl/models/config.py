"""ETL configuration models."""

import re
from enum import Enum
from pathlib import Path
from typing import Self
from uuid import UUID, uuid4

import yaml
from loguru import logger
from pydantic import BaseModel, Field, model_validator

from musicdata.db.models import AnnotationSource, Standard
from musicdata.db.repositories.bigquery_repository import BigQueryRepository
from musicdata.utils.uri_handler import read_text_from_uri


class SourceType(Enum):
    """Supported data source types."""

    BIGQUERY = "bigquery"
    CSV = "csv"  # Any CSV file via fsspec (supports gs://, s3://, local, http://, etc.)


class AnnotationKindConfig(BaseModel):
    """Configuration for a single annotation kind processing entry."""

    kind: str
    annotation_standard: Standard
    annotation_source: AnnotationSource
    encrypt: bool = False


class ETLConfig(BaseModel):
    """Configuration for ETL operations."""

    source: str
    insert_batch_description: str

    # Entity creation gate - controls whether ETL can create new songs/files
    load_songs_and_files: bool = Field(
        default=False,
        description=(
            "Controls entity creation behavior:\n"
            "- True: Allow creating new songs/files (auto-detects blob path vs fast path by column presence)\n"
            "- False: Annotation-only mode (blocks all song/file creation, only adds annotations to existing entities)"
        ),
    )

    # File update mode - update existing files with new blob paths
    update_files: bool = Field(
        default=False,
        description=(
            "Update existing files with new blob paths. Mutually exclusive with load_songs_and_files.\n"
            "- True: Update mode - replaces file blobs for existing files, recomputes file_data\n"
            "- False: Default behavior (insert or annotation-only based on load_songs_and_files)"
        ),
    )

    # Optional list of additional precompute kinds to run per file (e.g., "shift", "instrument_tagging")
    precompute_kinds: list[str] = Field(default_factory=list)

    # Annotation parameters - list of annotation kinds with per-kind configs
    annotation_kinds: list[AnnotationKindConfig] | None = None

    # Operational parameters
    allow_unintended_value_change: bool = False
    allow_standard_downgrade: bool = False
    debug: bool = Field(
        default=False,
        description=(
            "Debug mode - limits concurrency to make debugging easier:\n"
            "- Sets max_workers to 1 for main processing\n"
            "- Sets max_workers_override to 1 for nested parallelism"
        ),
    )
    output_location: str
    log_file_path: str = "etl.log"
    batch_id: UUID = Field(default_factory=uuid4)

    # Worker-aware chunk sizing parameters
    tasks_per_worker: int = Field(
        default=1,
        ge=0,
        description=(
            "Target number of tasks per worker for even distribution. "
            "Set to 0 to disable worker-aware sizing and use max_worker_chunk_rows directly."
        ),
    )
    min_worker_chunk_rows: int = Field(
        default=1,
        gt=0,
        description="Minimum rows per worker chunk (lower bound for computed target_rows)",
    )
    max_worker_chunk_rows: int = Field(
        default=10000,
        gt=0,
        description="Maximum rows per worker chunk (upper bound for computed target_rows)",
    )

    # Deprecated: kept for backward compatibility, silently ignored
    chunk_size: int | None = Field(
        default=None,
        gt=0,
        exclude=True,
        description="Deprecated: Ignored if set. Use max_worker_chunk_rows instead.",
    )

    # Computed fields (will be set by model_validator)
    source_type: SourceType | None = Field(default=None, exclude=True)
    source_details: dict[str, str] = Field(default_factory=dict, exclude=True)

    @model_validator(mode="after")
    def validate_and_parse_source(self) -> Self:
        """Parse source URI and validate format."""
        self.source_type, self.source_details = self._parse_source_uri(self.source)
        return self

    @model_validator(mode="after")
    def validate_mutually_exclusive_modes(self) -> Self:
        """Ensure update_files and load_songs_and_files are mutually exclusive."""
        if self.update_files and self.load_songs_and_files:
            msg = "update_files and load_songs_and_files are mutually exclusive. Set only one to True."
            raise ValueError(msg)
        return self

    def _parse_source_uri(self, source: str) -> tuple[SourceType, dict[str, str]]:
        """Parse source URI and extract connection details."""
        if source.startswith("bq://"):
            # Format: bq://project.dataset.table
            match = re.match(r"bq://([^.]+)\.([^.]+)\.(.+)", source)
            if not match:
                msg = f"Invalid BigQuery URI format. Expected: bq://project.dataset.table, got: {source}"
                raise ValueError(msg)

            project, dataset, table = match.groups()

            # Validate components to prevent SQL injection
            BigQueryRepository.validate_bigquery_table_components(project, dataset, table)

            return SourceType.BIGQUERY, {
                "project": project,
                "dataset": dataset,
                "table": table,
            }

        # For any other URI, check if it's a CSV file
        # fsspec will handle the protocol automatically (gs://, s3://, local, http://, etc.)
        if source.endswith(".csv"):
            return SourceType.CSV, {
                "source_uri": source,
            }

        # If not BigQuery and not CSV, it's an error
        msg = f"Unsupported source format. Expected BigQuery (bq://...) or CSV file (*.csv), got: {source}"
        raise ValueError(msg)

    @classmethod
    def from_yaml(cls, config_source: str | Path, **kwargs) -> "ETLConfig":
        """Load configuration from YAML file or URI.

        Supports any fsspec-compatible source:
        - Local files: /path/to/file, ./relative/path, Path objects
        - GCS: gs://bucket/path/to/file
        - S3: s3://bucket/path/to/file
        - HTTP/HTTPS: https://example.com/file
        - Azure: az://container/path/to/file
        - And many more via fsspec

        Args:
            config_source: Path or URI to YAML configuration file
            **kwargs: Additional arguments passed to fsspec.open()

        Returns:
            ETLConfig instance

        Raises:
            ImportError: If fsspec is not available (for remote URIs)
            ValueError: If YAML is invalid or configuration is malformed
            FileNotFoundError: If the file/URI doesn't exist
            PermissionError: If access is denied
        """
        # Convert Path objects to string for fsspec
        if isinstance(config_source, Path):
            config_source = str(config_source)

        logger.info(f"Loading configuration from: {config_source}")
        yaml_content = read_text_from_uri(config_source, **kwargs)
        return cls.from_yaml_content(yaml_content)

    @classmethod
    def from_yaml_content(cls, yaml_content: str) -> "ETLConfig":
        """Load configuration from YAML content string.

        Args:
            yaml_content: YAML configuration as string

        Returns:
            ETLConfig instance

        Raises:
            ValueError: If YAML is invalid or configuration is malformed
        """
        try:
            config_data = yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            msg = f"Failed to parse YAML configuration: {e}"
            raise ValueError(msg) from e

        if not isinstance(config_data, dict):
            msg = "Configuration content must be a YAML dictionary"
            raise ValueError(msg)  # noqa: TRY004

        # Pydantic will handle validation and enum conversion automatically
        try:
            return cls.model_validate(config_data)
        except Exception as e:
            msg = f"Invalid configuration: {e}"
            raise ValueError(msg) from e

    def to_dict(self) -> dict:
        """Convert configuration to dictionary."""
        return self.model_dump(mode="json")

    def log_config(self) -> None:
        """Log configuration details dynamically."""
        logger.info("ETL Configuration:")

        # Get all fields from the model class
        for field_name, field_info in self.__class__.model_fields.items():
            # Skip computed fields that are excluded from serialization
            if field_info.exclude:
                continue

            value = getattr(self, field_name)

            # Format special cases
            if field_name == "source":
                source_type = self.source_type.value if self.source_type else "unknown"
                logger.info(f"  Source: {value} ({source_type})")
            elif hasattr(value, "value"):  # Handle enums
                logger.info(f"  {field_name.replace('_', ' ').title()}: {value.value}")
            else:
                logger.info(f"  {field_name.replace('_', ' ').title()}: {value}")

    def get_processing_modes(self) -> list[str]:
        """Get list of processing modes that will be executed."""
        modes = []

        # File update mode
        if self.update_files:
            modes.append("file_update")

        # Song/file loading mode
        if self.load_songs_and_files:
            modes.append("song_file_loading")

        # Annotation processing mode - enabled when annotation_kinds has entries
        if self.annotation_kinds:
            modes.append("annotation_processing")

        return modes
