"""Data enrichment service for ETL results streaming."""

from collections import OrderedDict
from collections.abc import Callable, Generator
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from musicdata.catalog.services import CatalogService


class DataEnrichmentService:
    """Service for enriching data streams with additional metadata like song_ids.

    This implementation is memory-bounded. It avoids a full pre-scan of the stream
    and instead enriches rows in small windows with a capped LRU cache for mappings.
    """

    # Tunables to cap memory usage; chosen to stay small while keeping good throughput
    _LOOKUP_BATCH_SIZE = 10_000
    _MAX_CACHE_ENTRIES = 200_000

    def __init__(self, catalog_service: "CatalogService") -> None:
        """Initialize enrichment service with catalog service."""
        self.catalog_service = catalog_service

    def create_enriched_stream(
        self,
        stream_factory: Callable[[], Generator[dict[str, Any], None, None]],
        entity_type: str,
    ) -> tuple[Generator[dict[str, Any], None, None], list[str]]:
        """
        Create an enriched data stream with song_ids added where missing, without preloading
        the entire dataset into memory. This function computes headers by peeking the first
        row, then performs windowed enrichment with a bounded LRU cache.
        """
        should_enrich = entity_type in ["file", "annotation"]

        # Peek one row to determine headers
        preview_stream = stream_factory()
        try:
            first = next(preview_stream)
        except StopIteration:

            def _empty() -> Generator[dict[str, Any], None, None]:
                if False:
                    yield {}

            return _empty(), []

        headers = list(first.keys())
        enriched_headers = headers + (["song_id"] if should_enrich and "song_id" not in headers else [])

        def enriched_stream() -> Generator[dict[str, Any], None, None]:
            # Local LRU cache (file_id -> song_id) with manual eviction
            mapping_cache: OrderedDict[str, str] = OrderedDict()

            def cache_put(fid: str, song_id: str | None) -> None:
                if not song_id:
                    return
                mapping_cache[fid] = song_id
                mapping_cache.move_to_end(fid)
                if len(mapping_cache) > self._MAX_CACHE_ENTRIES:
                    mapping_cache.popitem(last=False)

            def cache_get(fid: str) -> str | None:
                val = mapping_cache.get(fid)
                if val is not None:
                    mapping_cache.move_to_end(fid)
                return val

            buffer: list[dict[str, Any]] = []
            missing_fids: set[str] = set()

            def flush() -> Generator[dict[str, Any], None, None]:
                nonlocal buffer, missing_fids
                if not buffer:
                    return
                lookup: dict[str, str] = {}
                if should_enrich and missing_fids:
                    try:
                        with self.catalog_service.connection() as conn:
                            raw_map = self.catalog_service.repos.file.get_songs_by_file_ids_bulk(
                                list(missing_fids), conn
                            )
                        lookup = {str(k): str(v) for k, v in raw_map.items() if v}
                    except Exception as e:  # noqa: BLE001
                        logger.warning(f"Song-id lookup failed for batch of {len(missing_fids)} file_ids: {e}")
                        lookup = {}

                for row in buffer:
                    if should_enrich:
                        current_song_id = row.get("song_id")
                        if not current_song_id:
                            fid_val = row.get("file_id")
                            if fid_val is not None:
                                fid = str(fid_val)
                                song_id = cache_get(fid)
                                if song_id is None:
                                    song_id = lookup.get(fid)
                                    if song_id is not None:
                                        cache_put(fid, song_id)
                                if song_id is not None:
                                    row["song_id"] = song_id
                                elif "song_id" not in row:
                                    row["song_id"] = ""
                            elif "song_id" not in row:
                                row["song_id"] = ""
                    yield row

                buffer = []
                missing_fids.clear()

            # Seed buffer with the previewed first row
            buffer.append(first)
            if should_enrich and not first.get("song_id"):
                fid_first = first.get("file_id")
                if fid_first is not None:
                    missing_fids.add(str(fid_first))

            # Continue with the rest of the preview stream
            for row in preview_stream:
                buffer.append(row)
                if should_enrich and not row.get("song_id"):
                    fid_val = row.get("file_id")
                    if fid_val is not None:
                        missing_fids.add(str(fid_val))
                if len(buffer) >= self._LOOKUP_BATCH_SIZE:
                    yield from flush()

            # Flush remainder
            yield from flush()

        return enriched_stream(), enriched_headers

    # The previous metadata pre-scan is intentionally removed to prevent memory spikes.
