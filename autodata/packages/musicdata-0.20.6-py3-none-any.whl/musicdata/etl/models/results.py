"""Data models for representing ETL processing results."""
# ruff: noqa: BLE001, SIM105

from collections.abc import Generator
from itertools import product
from typing import TYPE_CHECKING, Any, Self
from uuid import UUID

import orjson
import pandas as pd
from loguru import logger
from pydantic import BaseModel, Field

from musicdata.annotations import KindRegistry
from musicdata.etl.models.enrichment import DataEnrichmentService
from musicdata.etl.models.status import ProcessingStatus, SkipReason
from musicdata.etl.outputs import OutputAdapter
from musicdata.etl.storage import DuckDBStore

if TYPE_CHECKING:
    from musicdata.catalog.services import CatalogService

# Define the union of all possible entity types that can be processed
# Use Any to avoid forward reference issues with Pydantic
ProcessableEntity = Any

# Canonical sets for entity types and statuses to avoid magic strings throughout
ENTITY_TYPES: tuple[str, ...] = ("annotation", "song", "file", "chunk")
STATUSES: tuple[str, ...] = ("success", "failed", "skipped")


class ProcessingResult(BaseModel):
    """Memory-efficient wrapper for any processed entity."""

    entity: ProcessableEntity | None = Field(None, description="The actual processed object (None for failures)")
    raw_data: dict[str, Any] | None = Field(None, description="Raw data stored only for failed items")
    entity_type: str = Field(description="The type of entity this result represents")
    status: ProcessingStatus = Field(description="Processing status")
    reason: str | None = Field(None, description="Reason for failure/skip")
    error: str | None = Field(None, description="Error message if failed")

    def get_raw_data(self) -> dict[str, Any]:
        """Get raw data - from storage for failures or model_dump() for successes."""
        if self.raw_data is not None:
            return self.raw_data
        if self.entity is not None:
            return self.entity.model_dump(mode="json")
        return {}


class ETLResults:
    """
    A data container for ETL results, backed by a DuckDBStore for storage.

    This class holds configuration and high-level results, while delegating all
    database operations to an encapsulated DuckDBStore instance.
    """

    def __init__(self, db_path: str | None = None) -> None:
        """
        Initialize ETLResults.

        Args:
            db_path: Optional DuckDB file path for the store
        """
        self._store: DuckDBStore = DuckDBStore(db_path=db_path)
        self._pending_results: list[list[Any]] = []

    @property
    def store(self) -> DuckDBStore:
        """Return the backing DuckDBStore instance."""
        return self._store

    def add_result(self, params: list[Any]) -> None:
        """Add a processing result to the pending batch."""
        # The params array format is: [entity, raw_data, entity_type, status, reason, error]
        entity = params[0]
        raw_data = params[1]

        entity_data = entity.model_dump_json() if entity is not None else None
        raw_data_json = orjson.dumps(raw_data, default=str).decode() if raw_data is not None else None

        # Store serialized data in pending batch
        final_params = [entity_data, raw_data_json, *params[2:]]
        self._pending_results.append(final_params)

    def add_success(self, entity: ProcessableEntity, entity_type: str) -> None:
        """Add a successful result."""
        # The params array format is: [entity, raw_data, entity_type, status, reason, error]
        self.add_result([entity, None, entity_type, ProcessingStatus.SUCCESS.value, None, None])

    def add_failure(self, raw_data: dict[str, Any], entity_type: str, error: str) -> None:
        """Add a failed result."""
        self.add_result([None, raw_data, entity_type, ProcessingStatus.FAILED.value, None, error])

    def add_skip(self, entity: ProcessableEntity, entity_type: str, reason: str) -> None:
        """Add a skipped result."""
        self.add_result([entity, None, entity_type, ProcessingStatus.SKIPPED.value, reason, None])

    def add_chunk_error(self, error: str) -> None:
        """Add a chunk-level global error."""
        # Persist as a failed result so it survives worker process boundaries
        # Use a dict for raw_data to be consistent with add_failure
        self.add_result([None, {"error": error}, "chunk", ProcessingStatus.FAILED.value, None, error])

    def flush(self) -> None:
        """Flush all pending results to the database using DataFrame bulk insert."""
        if not self._pending_results:
            return

        # Create DataFrame from pending results
        df = pd.DataFrame(
            self._pending_results,
            columns=pd.Index(["entity_data", "raw_data", "entity_type", "status", "reason", "error"]),
        )

        # Bulk insert using DataFrame
        self.store.add_results_from_df(df)

        # Clear pending results
        self._pending_results.clear()

    def _parse_result_row(
        self, entity_data: str | None, raw_data: str | None, reason: str | None, error: str | None, status: str | None
    ) -> dict[str, Any]:
        """Parse a single result row from the database."""
        data = {}
        if entity_data:
            try:
                data = orjson.loads(entity_data)
            except (orjson.JSONDecodeError, TypeError):
                pass

        if not data and raw_data:
            try:
                data = orjson.loads(raw_data)
            except (orjson.JSONDecodeError, TypeError):
                pass

        if status == "failed" and error:
            data["error_message"] = error
            data["status"] = "failed"
        elif status == "skipped" and reason:
            data["error_message"] = reason
            data["status"] = "skipped"

        return data

    def stream_results_data(
        self, entity_type: str | list[str] | None = None, status: str | None = None
    ) -> Generator[dict[str, Any], None, None]:
        """Stream parsed data from DuckDB results using optimized Arrow-based processing."""
        for batch in self.store.stream_results(entity_type=entity_type, status=status, chunk_size=50000):
            # Process each row in the batch (already as dicts from Arrow)
            for row_dict in batch:
                try:
                    data = self._parse_result_row(
                        row_dict["entity_data"],
                        row_dict["raw_data"],
                        row_dict["reason"],
                        row_dict["error"],
                        status,
                    )
                    if data:
                        yield data
                except Exception:
                    logger.exception("Error processing row in stream_results_data.")
                    continue

    def __iadd__(self, other: "ETLResults") -> Self:
        """Merge another ETLResults into this one."""
        if not isinstance(other, ETLResults):
            msg = f"Cannot merge ETLResults with {type(other).__name__}"
            raise TypeError(msg)

        self.flush()
        other.flush()

        # We need the other store's path, so direct access is pragmatic here.
        self.store.merge_from_db_file(other._store.db_path)

        return self

    def close(self, *, should_delete: bool = True) -> None:
        """Close the underlying storage connection and clean up resources."""
        self.store.close(should_delete=should_delete)

    def generate_csv_from_results(self, output_adapter: OutputAdapter, catalog_service: "CatalogService") -> list[str]:
        """Generate CSV files from results using true streaming architecture with data enrichment."""
        if self.store.conn is None:
            return []

        try:
            result_count_query = self.store.conn.execute("SELECT COUNT(*) FROM results")
            result_count = result_count_query.fetchone() if result_count_query else None
            if not result_count or result_count[0] == 0:
                return []

            uploaded_files = []

            # Initialize enrichment service
            enrichment_service = DataEnrichmentService(catalog_service)

            # Generate CSV files for each entity type and status combination
            entity_types = ("annotation", "song", "file")
            statuses = ("success", "failed", "skipped")

            for entity_type, status in product(entity_types, statuses):
                uploaded_file = self._generate_csv_with_streaming_architecture(
                    entity_type, status, enrichment_service, output_adapter
                )
                if uploaded_file:
                    uploaded_files.append(uploaded_file)
                    logger.info(f"Uploaded '{status}' CSV for {entity_type}s: {uploaded_file}")

        except Exception as e:
            logger.exception(f"Error generating CSV from DuckDB results: {e}")
            return []

        return uploaded_files

    def _generate_csv_with_streaming_architecture(
        self,
        entity_type: str,
        status: str,
        enrichment_service: DataEnrichmentService,
        output_adapter: OutputAdapter,
    ) -> str | None:
        """
        Generate CSV using clean streaming architecture with enrichment service.

        This method implements true streaming:
        1. Creates raw data stream from DuckDB
        2. Uses enrichment service for song_id enrichment
        3. Streams enriched data directly to output destination
        4. No memory accumulation at any stage

        Args:
            entity_type: Type of entity (annotation, song, file)
            status: Status filter (success, failed, skipped)
            enrichment_service: Service for data enrichment
            output_adapter: Adapter for streaming output

        Returns:
            Path to uploaded file, or None if no data
        """
        try:
            # Create raw data stream factory
            def raw_stream_factory() -> Generator[dict[str, Any], None, None]:
                if status == "skipped":
                    # For skipped status, filter out expected skip reasons
                    return self._stream_unexpected_skipped_data(entity_type)
                return self.stream_results_data(entity_type=entity_type, status=status)

            # Check if there's any data to process
            has_data = False
            for _ in raw_stream_factory():
                has_data = True
                break

            if not has_data:
                return None

            # Use enrichment service to create enriched stream with proper headers
            enriched_stream, enriched_headers = enrichment_service.create_enriched_stream(
                raw_stream_factory, entity_type
            )

            # Generate filename
            filename = f"etl_results_{status}_{entity_type}s.csv"

            # Stream directly to destination using OutputAdapter
            return output_adapter.stream_csv_to_destination(
                data_stream=enriched_stream,
                headers=enriched_headers,
                filename=filename,
            )

        except Exception as e:
            logger.exception(f"Error generating CSV for {entity_type}/{status}: {e}")
            return None

    def _stream_unexpected_skipped_data(self, entity_type: str) -> Generator[dict[str, Any], None, None]:
        """Stream unexpected skipped data (filtering out expected skip reasons)."""
        expected_reasons = SkipReason.expected_reasons()
        for item in self.stream_results_data(entity_type=entity_type, status="skipped"):
            if item.get("error_message") not in expected_reasons:
                yield item

    def _get_song_ids_mapping(self, catalog_service: "CatalogService") -> dict[str, str]:
        """Get song ID mapping for file IDs from catalog service."""
        if self.store.conn is None:
            return {}

        try:
            # Get all file IDs from the results
            file_ids: set[Any] = {
                str(data.get("file_id") or data.get("id"))
                for data in self.stream_results_data(entity_type=["file", "annotation"])
                if data.get("file_id") or data.get("id")
            }

            if not file_ids:
                return {}

            # Get song mapping from catalog service
            with catalog_service.connection() as conn:
                raw_mapping = catalog_service.repos.file.get_songs_by_file_ids_bulk(list(file_ids), conn)
                return {str(file_id): str(song_id) for file_id, song_id in raw_mapping.items() if song_id}

        except Exception:
            return {}


class ETLAnalyzer:
    """High-performance analyzer using DuckDB SQL queries."""

    def __init__(self, results: ETLResults) -> None:
        self.results = results
        self.conn: Any = results.store.conn
        if self.conn is None:
            msg = "ETLAnalyzer requires an active DuckDB connection, but none was found."
            raise RuntimeError(msg)

    def _count_where(self, where_clause: str | None = None, params: list[Any] | tuple[Any, ...] = ()) -> int:
        """Generic COUNT(*) helper with an optional WHERE clause and parameters."""
        if self.conn is None:
            msg = "ETLAnalyzer requires an active DuckDB connection, but none was found."
            raise RuntimeError(msg)
        query = "SELECT COUNT(*) FROM results"
        if where_clause:
            query += f" WHERE {where_clause}"
        result = self.conn.execute(query, params).fetchone()
        return result[0] if result else 0

    def _count_for(self, *, entity_type: str | None = None, status: str | None = None) -> int:
        """Count rows filtered by optional entity_type and status."""
        conditions: list[str] = []
        params: list[Any] = []
        if entity_type is not None:
            if entity_type not in ENTITY_TYPES:
                msg = f"Invalid entity_type '{entity_type}'. Allowed: {', '.join(ENTITY_TYPES)}"
                raise ValueError(msg)
            conditions.append("entity_type = ?")
            params.append(entity_type)
        if status is not None:
            if status not in STATUSES:
                msg = f"Invalid status '{status}'. Allowed: {', '.join(STATUSES)}"
                raise ValueError(msg)
            conditions.append("status = ?")
            params.append(status)
        where_clause = " AND ".join(conditions) if conditions else None
        return self._count_where(where_clause, params)

    def has_errors(self) -> bool:
        """Check if there are any errors."""
        # Flush pending results to ensure DB is up to date
        self.results.flush()
        result = self.conn.execute("SELECT COUNT(*) FROM results WHERE status = 'failed'").fetchone()
        return bool(result and result[0] > 0)

    def get_errors(self, entity_type: str | None = None) -> list[str]:
        """
        Get all errors from database.

        Args:
            entity_type: Optional entity type to filter errors by (e.g. "chunk")
        """
        # Flush pending results to ensure DB is up to date
        self.results.flush()
        errors = []

        # Add errors from database (including chunk errors from workers)
        try:
            # Build query based on whether entity_type is provided
            query = "SELECT error FROM results WHERE status = 'failed' AND error IS NOT NULL"
            params = []

            if entity_type:
                query += " AND entity_type = ?"
                params.append(entity_type)

            # Fetch all errors
            rows = self.conn.execute(query, params).fetchall()

            for (error_msg,) in rows:
                if error_msg and error_msg not in errors:
                    errors.append(error_msg)
        except Exception:
            logger.warning("Failed to fetch errors from database")

        return errors

    def count(self, entity_type: str | None = None, status: str | None = None) -> int:
        """Return a count filtered by optional entity_type and status.

        Examples:
            - count("annotation") -> processed annotations
            - count("song", "failed") -> failed songs
            - count(status="skipped") -> all skipped entities
        """
        return self._count_for(entity_type=entity_type, status=status)

    def counts_by_type(self, status: str | None = None) -> dict[str, int]:
        """Return counts grouped by entity_type, optionally filtered by status."""
        if self.conn is None:
            msg = "ETLAnalyzer requires an active DuckDB connection, but none was found."
            raise RuntimeError(msg)
        params: list[Any] = []
        base = "SELECT entity_type, COUNT(*) as count FROM results"
        where_clause = ""
        if status is not None:
            if status not in STATUSES:
                msg = f"Invalid status '{status}'. Allowed: {', '.join(STATUSES)}"
                raise ValueError(msg)
            where_clause = " WHERE status = ?"
            params.append(status)
        query = f"{base}{where_clause} GROUP BY entity_type"
        rows = self.conn.execute(query, params).fetchall()
        counts = dict.fromkeys(ENTITY_TYPES, 0)
        for etype, num in rows:
            if etype in counts:
                counts[etype] = num
        return counts

    def count_inserted_annotations_by_kind(self) -> dict[str, int]:
        """Count inserted annotations grouped by kind name.

        Uses the inserted annotation payloads (which include kind_id) and maps
        kind_id to kind name via KindRegistry.
        """
        if self.conn is None:
            return {}

        # Stream inserted annotations and aggregate by kind_id
        counts_by_kind_id: dict[str, int] = {}
        for data in self.results.stream_results_data(entity_type="annotation", status="success"):
            kind_id = data.get("kind_id")
            if not kind_id:
                continue
            kind_id_str = str(kind_id)
            counts_by_kind_id[kind_id_str] = counts_by_kind_id.get(kind_id_str, 0) + 1

        if not counts_by_kind_id:
            return {}

        # Map kind_id -> kind name
        kind_name_by_id: dict[str, str] = {}
        try:
            for kind_id_str in counts_by_kind_id:
                kind_uuid = UUID(kind_id_str)
                kind = KindRegistry.get_kind_by_id(kind_uuid)
                # Convert Enum to plain string if needed
                kind_name_by_id[kind_id_str] = getattr(kind.kind, "value", str(kind.kind))
        except Exception as e:
            logger.warning(f"Failed to map kind ids to names for per-kind counts: {e}")
            return {}

        # Build counts by kind name
        counts_by_kind_name: dict[str, int] = {}
        for kid, count in counts_by_kind_id.items():
            kind_name = kind_name_by_id.get(kid)
            if kind_name:
                counts_by_kind_name[kind_name] = counts_by_kind_name.get(kind_name, 0) + count

        return counts_by_kind_name

    def get_skip_breakdown(self) -> dict[str, int]:
        """Get skip reasons breakdown using SQL."""
        results = self.conn.execute("""
            SELECT reason, COUNT(*) as count
            FROM results
            WHERE status = 'skipped' AND reason IS NOT NULL
            GROUP BY reason
        """).fetchall()

        return dict(results)

    def get_skip_breakdown_by_type(self) -> dict[str, dict[str, int]]:
        """Get skip reasons breakdown by entity type using SQL."""
        results = self.conn.execute("""
            SELECT entity_type, reason, COUNT(*) as count
            FROM results
            WHERE status = 'skipped' AND reason IS NOT NULL
            GROUP BY entity_type, reason
        """).fetchall()

        breakdown: dict[str, dict[str, int]] = {}
        for entity_type, reason, count in results:
            if entity_type not in breakdown:
                breakdown[entity_type] = {}
            breakdown[entity_type][reason] = count
        return breakdown

    def get_failed_entities_breakdown(self) -> dict[str, dict[str, int]]:
        """Get failed entity breakdown by reason for each type using SQL."""
        results = self.conn.execute("""
            SELECT entity_type, error, COUNT(*) as count
            FROM results
            WHERE status = 'failed' AND error IS NOT NULL
            GROUP BY entity_type, error
        """).fetchall()

        # The structure needs to be {"failed_songs_breakdown": {"reason": count}}
        breakdown: dict[str, dict[str, int]] = {}
        for entity_type, reason, count in results:
            key = f"failed_{entity_type}s_breakdown"
            if key not in breakdown:
                breakdown[key] = {}
            breakdown[key][reason] = count
        return breakdown

    def get_annotation_dataset_breakdown(self, catalog_service: "CatalogService") -> dict[str, int]:
        """Get annotation dataset breakdown via memory-bounded streaming aggregation."""
        if self.conn is None:
            return {}

        dataset_counts: dict[str, int] = {}
        pending_song_ids: set[str] = set()
        pending_file_ids: set[str] = set()
        processed_song_ids: set[str] = set()  # Track already counted songs globally

        song_batch = 50_000
        file_batch = 50_000

        def flush_song_ids(song_ids: set[str]) -> None:
            if not song_ids:
                return
            try:
                with catalog_service.connection() as conn:
                    dataset_map: dict[UUID, str] = catalog_service.repos.song.get_datasets_by_song_ids_bulk(
                        song_ids=song_ids, conn=conn
                    )
            except Exception:
                return
            for song_id, dataset in dataset_map.items():
                if dataset and str(song_id) not in processed_song_ids:
                    dataset_counts[dataset] = dataset_counts.get(dataset, 0) + 1
                    processed_song_ids.add(str(song_id))

        def flush_file_ids(file_ids: set[str]) -> None:
            if not file_ids:
                return
            try:
                with catalog_service.connection() as conn:
                    f2s = catalog_service.repos.file.get_songs_by_file_ids_bulk(file_ids=file_ids, conn=conn)
            except Exception:
                return
            song_ids = {str(v) for v in f2s.values() if v}
            if song_ids:
                flush_song_ids(song_ids)

        for data in self.results.stream_results_data(entity_type="annotation", status="success"):
            sid = data.get("song_id")
            fid = data.get("file_id")
            if sid:
                pending_song_ids.add(str(sid))
                if len(pending_song_ids) >= song_batch:
                    flush_song_ids(pending_song_ids)
                    pending_song_ids.clear()
            elif fid:
                pending_file_ids.add(str(fid))
                if len(pending_file_ids) >= file_batch:
                    flush_file_ids(pending_file_ids)
                    pending_file_ids.clear()

        if pending_file_ids:
            flush_file_ids(pending_file_ids)
        if pending_song_ids:
            flush_song_ids(pending_song_ids)

        return dataset_counts

    def get_summary_stats(self) -> dict[str, Any]:
        """Get comprehensive summary statistics using SQL."""
        return {
            "annotations_inserted": self.count("annotation", "success"),
            "annotations_processed": self.count("annotation"),
            "annotations_skipped": self.count("annotation", "skipped"),
            "songs_inserted": self.count("song", "success"),
            "songs_processed": self.count("song"),
            "files_inserted": self.count("file", "success"),
            "files_processed": self.count("file"),
            "failed_entities": self.counts_by_type(status="failed"),
            "skip_breakdown": self.get_skip_breakdown(),
            "has_errors": self.has_errors(),
        }
