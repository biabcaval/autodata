"""Status enums and reason codes for ETL processing.

This module contains only enum definitions with no dependencies to avoid circular imports.
"""

from enum import Enum


class ProcessingStatus(str, Enum):
    """Status of a processed entity."""

    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


class SkipReason(str, Enum):
    """Centralized skip reasons for ETL processing.

    Categories:
    - Dataset validation: Issues with input data
    - Entity existence: Entity already exists in DB
    - Processing modes: Controlled by ETL configuration
    - No changes: Data matches existing (expected)
    """

    # Dataset validation
    INCONSISTENT_DATASET = "inconsistent_dataset"
    MISSING_DATASET = "missing_dataset"
    NO_SONG_ANNOTATIONS = "no_song_annotations"

    # Entity existence (expected in normal operations)
    SONG_EXISTS = "song_exists"
    FILE_EXISTS = "file_exists"
    SONG_AND_FILES_EXIST = "song_and_files_exist"

    # Processing modes
    ENTITY_CREATION_DISABLED = "entity_creation_disabled"

    # No changes (expected - annotation value matches existing)
    NO_CHANGE = "no_change"

    @classmethod
    def expected_reasons(cls) -> set[str]:
        """Reasons that are expected/normal and shouldn't trigger alerts."""
        return {cls.NO_CHANGE.value, cls.SONG_AND_FILES_EXIST.value}
