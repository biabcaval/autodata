"""Abstract base class for output adapters."""

from abc import ABC, abstractmethod
from collections.abc import Generator
from typing import IO, Any

BLOCK_SIZE = 64 * 1024 * 1024  # 64 MB buffer


class OutputAdapter(ABC):
    """Abstract base class for output adapters."""

    def __init__(self, output_uri: str) -> None:
        """Initialize adapter with output URI/path."""
        self.output_uri = output_uri

    @abstractmethod
    def write_artifact(self, content: str | IO[bytes], filename: str) -> str:
        """
        Write artifact to the output location.

        Args:
            content: The content to write
            filename: Name of the file to create

        Returns:
            Full path/URI where the artifact was written
        """

    @abstractmethod
    def stream_csv_to_destination(
        self,
        data_stream: Generator[dict[str, Any], None, None],
        headers: list[str],
        filename: str,
    ) -> str:
        """
        Stream CSV data directly to destination without memory accumulation.

        Args:
            data_stream: Generator yielding row dictionaries
            headers: List of CSV column headers
            filename: Name of the CSV file to create

        Returns:
            Full path/URI where the CSV was written
        """
