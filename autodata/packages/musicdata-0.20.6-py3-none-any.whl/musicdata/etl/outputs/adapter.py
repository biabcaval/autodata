"""Unified output adapter using fsspec."""

import csv
import shutil
from collections.abc import Generator
from typing import IO, Any, cast

import fsspec
import orjson
from loguru import logger

from .base import BLOCK_SIZE, OutputAdapter


class UnifiedOutputAdapter(OutputAdapter):
    """Unified output adapter using fsspec for any filesystem."""

    def _get_full_path(self, filename: str) -> str:
        """Create full output path for a given filename."""
        return f"{self.output_uri}{filename}" if self.output_uri.endswith("/") else f"{self.output_uri}/{filename}"

    def write_artifact(self, content: str | IO[bytes], filename: str) -> str:
        """Write artifact to any fsspec-supported location.

        Args:
            content: The content to write (can be a string or a binary file-like object).
            filename: The name of the artifact file.

        Returns:
            The full path to the written artifact.
        """
        full_path = self._get_full_path(filename)
        logger.info(f"Writing artifact to {full_path}")

        try:
            if isinstance(content, str):
                # Handle string content by writing in text mode
                with fsspec.open(full_path, "w", encoding="utf-8", block_size=BLOCK_SIZE) as dest_file:
                    f = cast("IO[str]", dest_file)
                    f.write(content)
            else:
                # Handle file-like object by streaming in binary mode with large buffer
                with fsspec.open(full_path, "wb", block_size=BLOCK_SIZE) as dest_file:
                    f = cast("IO[bytes]", dest_file)
                    shutil.copyfileobj(content, f, length=BLOCK_SIZE)

            logger.info(f"Successfully wrote artifact to {full_path}")
        except Exception as e:
            logger.error(f"Failed to write artifact to {full_path}: {e}")
            raise
        else:
            return full_path

    def stream_csv_to_destination(
        self,
        data_stream: Generator[dict[str, Any], None, None],
        headers: list[str],
        filename: str,
    ) -> str:
        """
        Stream CSV data directly to fsspec destination without memory accumulation.

        This method writes CSV data directly to the destination (local, GCS, S3, etc.)
        using fsspec's streaming capabilities, ensuring constant memory usage regardless
        of dataset size.

        Args:
            data_stream: Generator yielding row dictionaries
            headers: List of CSV column headers
            filename: Name of the CSV file to create

        Returns:
            Full path/URI where the CSV was written
        """
        full_path = self._get_full_path(filename)
        logger.info(f"Streaming CSV to {full_path}")

        try:
            # Open destination file for writing in text mode
            with fsspec.open(full_path, "w", encoding="utf-8", newline="", block_size=BLOCK_SIZE) as dest_file:
                f = cast("IO[str]", dest_file)
                writer = csv.writer(f)

                # Write headers first
                writer.writerow(headers)

                # Stream data rows directly to destination
                for row in data_stream:
                    # Extract values in header order with JSON serialization for complex types
                    serialized_values: list[Any] = []
                    for header in headers:
                        value = row.get(header)
                        if value is None:
                            serialized_values.append("")
                        elif isinstance(value, (dict, list)):
                            try:
                                serialized_values.append(orjson.dumps(value).decode())
                            except (TypeError, ValueError):
                                serialized_values.append(str(value))
                        else:
                            serialized_values.append(value)
                    writer.writerow(serialized_values)

            logger.info(f"Successfully streamed CSV to {full_path}")
        except Exception as e:
            logger.error(f"Failed to stream CSV to {full_path}: {e}")
            raise
        else:
            return full_path
