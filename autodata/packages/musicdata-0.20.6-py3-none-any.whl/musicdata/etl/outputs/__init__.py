"""Output adapters for ETL results."""

from .adapter import UnifiedOutputAdapter
from .base import OutputAdapter


def create_output_adapter(output_uri: str) -> OutputAdapter:
    """Create output adapter using fsspec for any protocol."""
    return UnifiedOutputAdapter(output_uri)


__all__ = [
    "OutputAdapter",
    "UnifiedOutputAdapter",
    "create_output_adapter",
]
