"""Catalog package for the musicdata project."""

# ruff: noqa: F401
from musicdata.catalog.services import CatalogService, ComparisonService
from musicdata.catalog.services.catalog_service import (
    AnnotationProcessingMode,
    ProcessingOptions,
)
