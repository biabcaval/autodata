"""Domain configuration classes for the musicdata catalog system."""

from dataclasses import dataclass

from musicdata.db.config import BigQueryConfig, DatabaseConfig


@dataclass
class CatalogConfig:
    """Main configuration for the catalog system."""

    database: DatabaseConfig
    bigquery: BigQueryConfig

    @classmethod
    def create(  # noqa: PLR0913
        cls,
        db_url: str | None = None,
        db_pool_size: int | None = None,
        bq_project_id: str | None = None,
        bq_credentials_path: str | None = None,
        bq_location: str | None = None,
        database_config: DatabaseConfig | None = None,
        bigquery_config: BigQueryConfig | None = None,
    ) -> "CatalogConfig":
        """Create configuration, loading from environment unless parameters are specified.

        By default, all configuration is loaded from environment variables.
        Any parameter you specify will override the corresponding environment value.

        Args:
            db_url: Database URL (overrides CATALOG_DB_URL)
            db_pool_size: Database connection pool size (overrides DB_POOL_SIZE)
            bq_project_id: BigQuery project ID (overrides GCP_PROJECT)
            bq_credentials_path: Path to BigQuery credentials file (overrides GOOGLE_APPLICATION_CREDENTIALS)
            bq_location: BigQuery location/region (overrides BQ_LOCATION)
            database_config: Pre-configured DatabaseConfig instance (overrides all db_* params)
            bigquery_config: Pre-configured BigQueryConfig instance (overrides all bq_* params)

        Returns:
            CatalogConfig instance with the specified configuration

        Examples:
            # Use environment variables for everything
            config = CatalogConfig.create()

            # Override just the database URL
            config = CatalogConfig.create(db_url="postgresql://localhost/test_db")

            # Override multiple parameters
            config = CatalogConfig.create(
                db_url="postgresql://localhost/test_db",
                bq_project_id="my-test-project"
            )

            # Use pre-configured instances
            db_config = DatabaseConfig(url="postgresql://...", pool_size=20)
            config = CatalogConfig.create(database_config=db_config)
        """
        # If pre-configured instances are provided, use them directly
        if database_config is None:
            # Load from environment first, then override with any provided parameters
            env_db_config = DatabaseConfig.from_env()
            database_config = DatabaseConfig(
                url=db_url if db_url is not None else env_db_config.url,
                pool_size=db_pool_size if db_pool_size is not None else env_db_config.pool_size,
            )

        if bigquery_config is None:
            # Load from environment first, then override with any provided parameters
            env_bq_config = BigQueryConfig.from_env()
            bigquery_config = BigQueryConfig(
                project_id=bq_project_id if bq_project_id is not None else env_bq_config.project_id,
                credentials_path=bq_credentials_path
                if bq_credentials_path is not None
                else env_bq_config.credentials_path,
                location=bq_location if bq_location is not None else env_bq_config.location,
            )

        return cls(database=database_config, bigquery=bigquery_config)
