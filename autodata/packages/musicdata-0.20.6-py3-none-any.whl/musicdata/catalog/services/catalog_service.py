"""Main catalog service that orchestrates repository operations."""

from collections import defaultdict
from collections.abc import Iterator
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

from joblib import Parallel, delayed
from loguru import logger
from sqlalchemy import Connection

from musicdata.annotations.validators import KindRegistry
from musicdata.catalog.config import CatalogConfig
from musicdata.catalog.exceptions import resolve_failure_type
from musicdata.catalog.services.annotation_service import AnnotationService
from musicdata.catalog.services.comparison_service import ComparisonService
from musicdata.catalog.services.song_processor import SongAtomicProcessor
from musicdata.catalog.services.types import (
    AnnotationProcessingMode,
    ExistingDataContext,
    FailedItem,
    InternalProcessingResult,
    ProcessingContext,
    ProcessingOptions,
    ProcessingResult,
    empty_internal_result,
    empty_result,
)
from musicdata.db.db_core import CatalogDatabase, CatalogTables, CatalogViews
from musicdata.db.models.base import SAFE_FILE_UPDATE_ANNOTATION_KINDS
from musicdata.db.models.models import AnnotationBatch
from musicdata.db.models.requests import (
    AnnotationRequest,
    BulkSongCreationRequest,
    BulkSongUpdateRequest,
    SongRequest,
    SongUpdateRequest,
)
from musicdata.db.repositories.manager import RepositoryManager
from musicdata.etl.models.status import SkipReason
from musicdata.utils.concurrency import ParallelOperationType, get_max_workers

if TYPE_CHECKING:
    from uuid import UUID


class CatalogService:
    """
    Main service for high-level catalog operations.

    This provides a clean, high-level API for catalog operations with optimized
    performance for ETL workloads and automatic change detection.

    Example usage:
        ```python
        # Simple usage with environment configuration
        catalog = CatalogService.create()

        # ETL bulk operations with automatic optimization
        with catalog.transaction() as conn:
            results = catalog.create_annotations_from_requests(requests, batch, conn)

        # Advanced usage with explicit transaction control
        with catalog.transaction() as conn:
            # Perform multiple operations within a transaction
            for batch_chunk in chunked_requests:
                results = catalog.create_annotations_from_requests(batch_chunk, batch, conn)

        # Convenient shortcuts for tables and direct access to components
        tables = catalog.t
        kind_registry = catalog.kind_registry  # For annotation kind lookups
        repos = catalog.repos  # For direct repository access

        # Centralized worker calculation for parallel operations
        # Get optimal workers for I/O bound operations (blob copying, etc.)
        io_workers = get_max_workers(ParallelOperationType.IO_BOUND, 50)

        # Get optimal workers for database intensive operations
        db_workers = get_max_workers(ParallelOperationType.DB_INTENSIVE, 25)

        # Mixed operations (I/O + database) - used by song processing
        mixed_workers = get_max_workers(ParallelOperationType.MIXED_IO_DB, 100)

        # Override for testing or special cases
        test_workers = get_max_workers(
            ParallelOperationType.DB_INTENSIVE,
            10,
            max_workers_override=2
        )
        ```
    """

    def __init__(
        self,
        repository_manager: RepositoryManager,
        comparison_service: ComparisonService | None = None,
    ) -> None:
        self.repos: RepositoryManager = repository_manager
        self._comparison: ComparisonService = comparison_service or ComparisonService()

        # Initialize KindRegistry with database connection (cache populated lazily on first access)
        KindRegistry.initialize(repository_manager.db.engine)

        self._annotations_service: AnnotationService = AnnotationService(repository_manager, self._comparison)
        self._song_processor: SongAtomicProcessor = SongAtomicProcessor(repository_manager, self._annotations_service)

        # Convenience shortcuts for direct table/view access
        self.t: CatalogTables = repository_manager.db.t
        self.v: CatalogViews = repository_manager.db.v

    @classmethod
    def create(cls, config: CatalogConfig | None = None) -> "CatalogService":
        """
        Create a service instance with the specified configuration.

        Args:
            config: Optional configuration. If None, loads from environment variables.

        Returns:
            Configured CatalogService instance.

        Examples:
            # Simple case - use environment variables
            service = CatalogService.create()

            # Custom configuration with specific parameters
            config = CatalogConfig.create(
                db_url="postgresql://user:pass@localhost/mydb",
                bq_project_id="my-project"
            )
            service = CatalogService.create(config)

            # Environment variables with specific overrides
            config = CatalogConfig.create(
                db_url="postgresql://localhost/test_db"
            )
            service = CatalogService.create(config)
        """
        config = config or CatalogConfig.create()

        # Create database
        db = CatalogDatabase(**config.database.to_sqlalchemy_kwargs())

        # Create repository manager with all repositories
        repository_manager = RepositoryManager(db, bigquery_config=config.bigquery)

        return cls(repository_manager=repository_manager)

    @contextmanager
    def transaction(self) -> Iterator[Connection]:
        """
        Provides a transactional scope for multiple operations.

        For ETL workloads, you can use this to group multiple operations:

        Example:
            with catalog.transaction() as conn:
                # All operations within this block are in a single transaction
                for batch_chunk in chunked_annotations:
                    catalog.create_annotations_from_requests(batch_chunk, batch, conn)
        """
        with self.repos.transaction() as conn:
            yield conn

    @contextmanager
    def connection(self) -> Iterator[Connection]:
        """Provides a read-only database connection."""
        with self.repos.connection() as conn:
            yield conn

    def create_annotations_bulk(
        self,
        requests: list[AnnotationRequest],
        batch: AnnotationBatch | None,
        conn: Connection,
        *,
        options: ProcessingOptions | None = None,
    ) -> ProcessingResult:
        """
        Create annotations in bulk with automatic change detection.

        This method is optimized for ETL workloads and provides the best ergonomics:
        - Bulk revision calculation in minimal database queries
        - Automatic change detection using existing bulk logic
        - Unchanged annotations are automatically skipped
        - Uses the provided connection (should be transactional)

        Args:
            requests: List of annotation requests
            batch: Optional batch to create
            conn: Database connection (should be transactional)
            options: Processing options

        Returns:
            ProcessingResult with inserted annotations, skipped requests, and failed requests.

        Example:
            requests = [AnnotationRequest.for_file(...), AnnotationRequest.for_file(...)]
            with catalog.transaction() as conn:
                results = catalog.create_annotations_bulk(
                    requests, batch, conn, options=ProcessingOptions(skip_missing=True)
                )
                print(f"Created: {len(results['inserted'])}, Skipped: {len(results['skipped'])}")
        """
        return self._annotations_service.create_annotations_bulk(requests, batch, conn, options=options)

    def _create_files_and_annotations(
        self,
        request: SongRequest,
        batch: AnnotationBatch | None,
        conn: Connection,
        *,
        options: ProcessingOptions,
    ) -> ProcessingResult:
        """
        Private helper: Create files and annotations for a song (assumes song already exists).

        This method handles files and annotations only:
        - Creates all files if they don't exist
        - Creates all annotations with proper change detection

        Args:
            request: SongRequest containing files and annotations (song assumed to exist)
            batch: Optional batch to create
            conn: Database connection (should be transactional)
            options: Processing options

        Returns:
            ProcessingResult with inserted files/annotations, skipped requests, and failed requests.
        """
        # Initialize unified results
        results = empty_result()

        # Create files and track results
        files = [file_req.to_file() for file_req in request.files]
        if files:
            # Perform bulk insertion
            inserted_files = self.repos.file.insert_files_bulk(conn, files)

            # Add actually inserted files to results
            if inserted_files:
                results["inserted"].extend(inserted_files)

        # Collect all annotation requests from song and files
        all_annotation_requests = []

        # Add song-level annotations
        for ann_req in request.annotations:
            if ann_req.song_id is None:
                ann_req.song_id = request.id
            all_annotation_requests.append(ann_req)

        # Add file-level annotations
        for file_req in request.files:
            for ann_req in file_req.annotations:
                if ann_req.file_id is None:
                    ann_req.file_id = file_req.id
                all_annotation_requests.append(ann_req)

        # Process annotations if any
        if all_annotation_requests:
            # Process annotations with unified structure
            annotation_results = self.create_annotations_bulk(
                all_annotation_requests,
                batch,
                conn,
                options=options,
            )

            # Aggregate unified results
            results["inserted"].extend(annotation_results.get("inserted", []))
            results["skipped"].extend(annotation_results.get("skipped", []))
            results["failed"].extend(annotation_results.get("failed", []))

        return results

    def _validate_and_plan_processing(self, request: BulkSongCreationRequest, conn: Connection) -> dict[str, Any]:
        """Validate what needs processing and create execution plan."""
        logger.info(f"Validating {len(request.songs)} songs for processing...")

        # Bulk check what songs already exist
        song_ids = [song.id for song in request.songs]
        existing_songs = self._annotations_service.validate_songs_exist_bulk(song_ids, conn)

        # Bulk check what files already exist
        all_file_ids = [file.id for song in request.songs for file in song.files]
        existing_files = self._annotations_service.validate_files_exist_bulk(all_file_ids, conn)

        # Analyze what needs processing
        songs_to_process = []
        songs_to_skip = []
        files_to_process = []

        for song_request in request.songs:
            song_exists = existing_songs.get(song_request.id, False)

            # Check which files need processing
            new_files = []
            existing_files_count = 0

            for file_req in song_request.files:
                if existing_files.get(file_req.id, False):
                    existing_files_count += 1
                else:
                    new_files.append(file_req)
                    files_to_process.append((song_request, file_req))

            # Determine song processing strategy
            if song_exists and not new_files:
                # Song and all files exist - skip entirely
                songs_to_skip.append((song_request, SkipReason.SONG_AND_FILES_EXIST.value))
            elif song_exists and new_files:
                # Song exists but has new files - process for files only
                songs_to_process.append(song_request)
            elif not song_exists:
                # New song - process everything
                songs_to_process.append(song_request)

        # Fetch existing files and their annotations for precheck validation
        # Only needed for songs that already exist and are being processed
        existing_song_ids_to_process = [
            song_req.id for song_req in songs_to_process if existing_songs.get(song_req.id, False)
        ]

        existing_song_files: dict[UUID, list[UUID]] = {}
        file_annotations: dict[UUID, dict[str, Any]] = {}

        if existing_song_ids_to_process:
            # Fetch all file IDs for existing songs in bulk
            existing_song_files = self.repos.file.get_files_by_song_ids_bulk(existing_song_ids_to_process, conn)

            # Collect all existing file IDs
            all_existing_file_ids = []
            for file_ids in existing_song_files.values():
                all_existing_file_ids.extend(file_ids)

            # Build file annotations structure: file_id -> {kind_name -> annotation_value}
            if all_existing_file_ids:
                # Fetch file_data annotations
                file_data_annotations = self.repos.annotation.get_latest_file_annotations_bulk(
                    all_existing_file_ids, "file_data", conn
                )
                for file_id, ann in file_data_annotations.items():
                    file_annotations.setdefault(file_id, {})["file_data"] = ann.annotation_value

                # Future: easily add more kinds here without signature changes, just by copying
                # the code above and changing the kind name

        # Build the existing data context (consolidates all existence/lookup data)
        existing_context = ExistingDataContext(
            songs=existing_songs,
            files=existing_files,
            song_files=existing_song_files,
            file_annotations=file_annotations,
        )

        logger.info(
            f"Processing plan: {len(songs_to_process)} songs to process, "
            f"{len(songs_to_skip)} to skip, "
            f"{len(files_to_process)} new files need blob copying, "
            f"{len(existing_context.song_files)} existing songs with "
            f"{len(existing_context.file_annotations)} existing files with annotations"
        )

        return {
            "songs_to_process": songs_to_process,
            "songs_to_skip": songs_to_skip,
            "files_to_process": files_to_process,  # Only new files
            "existing_context": existing_context,
        }

    def _process_songs_individually_with_blobs(
        self,
        songs: list[SongRequest],
        context: ProcessingContext,
    ) -> InternalProcessingResult:
        """Process songs in parallel using joblib with individual blob management.

        Args:
            songs: List of song requests to process
            context: Processing context with batch, options, and existence maps
        """
        if not songs:
            return empty_internal_result()

        # Process all songs in parallel - joblib handles memory efficiently
        db_pool_size = getattr(self.repos.db.engine.pool, "size", lambda: 50)()
        max_workers = get_max_workers(
            ParallelOperationType.IO_BOUND,
            item_count=len(songs),
            db_pool_size=db_pool_size,
            max_workers_override=context.options.max_workers_override,
        )
        logger.info(f"Processing {len(songs)} songs with {max_workers} workers")

        # Use verbose=1 for progress tracking (can be controlled via environment/config)
        song_results = Parallel(
            n_jobs=max_workers,
            backend="threading",
            verbose=0,  # Set to 1 to see progress bars
            prefer="threads",  # Explicitly prefer threads for I/O bound work
        )(delayed(self._song_processor.process_creation)(song, context) for song in songs)

        # Aggregate results
        aggregated_results = empty_internal_result()

        # Filter out None results from parallel execution
        valid_song_results = [r for r in song_results if r is not None]

        for song_result in valid_song_results:
            aggregated_results["inserted"].extend(song_result["inserted"])
            aggregated_results["skipped"].extend(song_result["skipped"])
            aggregated_results["failed"].extend(song_result["failed"])
            aggregated_results["successful_songs"].extend(song_result["successful_songs"])

        logger.info(
            f"Parallel song processing completed: {len(aggregated_results['successful_songs'])} successful, "
            f"{len(aggregated_results['failed'])} failed"
        )

        return aggregated_results

    def _process_song_request_annotations(
        self, successful_songs: list[SongRequest], batch: AnnotationBatch | None, *, options: ProcessingOptions
    ) -> ProcessingResult:
        """Process annotations in bulk for all successfully inserted songs/files."""
        if not successful_songs:
            return empty_result()

        logger.info(f"Processing annotations for {len(successful_songs)} songs")

        # Collect all annotation requests
        all_annotation_requests: list[AnnotationRequest] = []
        for song_request in successful_songs:
            all_annotation_requests.extend(self._song_processor.collect_annotation_requests(song_request))

        if not all_annotation_requests:
            return empty_result()

        # Process annotations in bulk (separate transaction)
        try:
            with self.repos.transaction() as ann_conn:
                return self.create_annotations_bulk(all_annotation_requests, batch, ann_conn, options=options)
        except Exception as e:  # noqa: BLE001
            failure_type = resolve_failure_type(e)
            logger.error(f"Bulk annotation processing failed: {e} [{failure_type}]")
            # Return all as failed
            failed_annotations: list[FailedItem] = [
                (req, str(e), {"entity_hierarchy": "bulk_annotation_processing", "failure_type": failure_type})
                for req in all_annotation_requests
            ]
            return {"inserted": [], "skipped": [], "failed": failed_annotations}

    def _log_processing_summary(self, results: ProcessingResult) -> None:
        """Simple logging summary."""
        inserted_count = len(results["inserted"])
        failed_count = len(results["failed"])
        skipped_count = len(results["skipped"])

        logger.info(
            f"Bulk processing completed: "
            f"{inserted_count} entities inserted, "
            f"{skipped_count} entities skipped, "
            f"{failed_count} entities failed"
        )

    def create_songs_only_bulk(
        self,
        songs: list[Any],
        conn: Connection,
    ) -> ProcessingResult:
        """
        Bulk insert songs without files/blobs (fast path).

        Used when load_songs_and_files=False for quick song creation without
        any blob operations.

        Args:
            songs: List of Song objects to insert
            conn: Database connection

        Returns:
            ProcessingResult with inserted songs, skipped, and failed.
        """
        if not songs:
            return empty_result()

        try:
            inserted_songs = self.repos.song.insert_songs_bulk(conn, songs)
            logger.info(f"Bulk inserted {len(inserted_songs)} songs (fast path)")
        except Exception as e:  # noqa: BLE001
            failure_type = resolve_failure_type(e)
            logger.error(f"Bulk song insertion failed: {e} [{failure_type}]")
            failed: list[FailedItem] = [
                (s, str(e), {"entity_hierarchy": f"song→{s.id}", "failure_type": failure_type}) for s in songs
            ]
            return {"inserted": [], "skipped": [], "failed": failed}

        return {
            "inserted": inserted_songs,
            "skipped": [],
            "failed": [],
        }

    def create_songs_bulk(
        self,
        request: BulkSongCreationRequest,
        *,
        options: ProcessingOptions | None = None,
    ) -> ProcessingResult:
        """
        Create complete songs with their files and annotations using unified per-song processing.

        Uses a unified approach where each song is processed completely (blobs + database)
        in parallel with individual blob tracking per song:
        1. Validate what needs processing (bulk existence checks with own connection)
        2. Process songs individually in parallel (each with own blob tracking and transaction)
        3. Process annotations in bulk (separate transaction)

        Args:
            request: BulkSongCreationRequest containing songs with optional blob copying
            options: Processing options

        Returns:
            ProcessingResult with inserted songs/files/annotations, skipped, and failed.
        """
        if not request.songs:
            return empty_result()

        logger.info(f"Starting unified per-song processing of {len(request.songs)} songs")

        # Phase 1: Validate and plan (creates own connection for validation)
        with self.repos.connection() as validation_conn:
            processing_plan = self._validate_and_plan_processing(request, validation_conn)

        # Normalize options
        options = options or ProcessingOptions()

        # Phase 2: Process songs individually (each with own blob management)
        creation_context = ProcessingContext(
            batch=request.batch,
            options=options,
            existing=processing_plan["existing_context"],
        )
        song_results = self._process_songs_individually_with_blobs(
            processing_plan["songs_to_process"],
            creation_context,
        )

        # Phase 3: Process annotations in bulk for ALL songs that should have annotations
        # This includes successful songs from Phase 2 AND songs that were skipped because they already exist
        songs_for_annotation_processing = song_results["successful_songs"]

        # Add back songs that were skipped because song+files exist - they should still get annotation processing
        for song_request, reason in processing_plan["songs_to_skip"]:
            if reason == SkipReason.SONG_AND_FILES_EXIST.value:
                songs_for_annotation_processing.append(song_request)

        if options.annotation_mode == AnnotationProcessingMode.BULK_AFTER:
            annotation_results = self._process_song_request_annotations(
                songs_for_annotation_processing,
                request.batch,
                options=options,
            )
        else:
            # In per-song atomic mode, annotations for newly processed songs are handled per-song.
            # For songs skipped as "song_and_files_exist", we can safely bulk process their annotations
            # since their songs/files already exist and don't need to be in the same transaction.
            skipped_songs = [
                sr for sr, reason in processing_plan["songs_to_skip"] if reason == SkipReason.SONG_AND_FILES_EXIST.value
            ]
            all_annotation_requests: list[AnnotationRequest] = []
            for song_request in skipped_songs:
                all_annotation_requests.extend(self._song_processor.collect_annotation_requests(song_request))

            if all_annotation_requests:
                try:
                    with self.repos.transaction() as conn:
                        annotation_results = self.create_annotations_bulk(
                            all_annotation_requests,
                            request.batch,
                            conn,
                            options=options,
                        )
                except Exception as e:  # noqa: BLE001
                    failure_type = resolve_failure_type(e)
                    logger.error(f"Bulk annotation processing for skipped songs failed: {e} [{failure_type}]")
                    failed: list[FailedItem] = [
                        (
                            req,
                            str(e),
                            {
                                "entity_hierarchy": "bulk_annotation_processing_skipped_songs",
                                "failure_type": failure_type,
                            },
                        )
                        for req in all_annotation_requests
                    ]
                    annotation_results: ProcessingResult = {"inserted": [], "skipped": [], "failed": failed}
            else:
                annotation_results = empty_result()

        # Aggregate final results
        total_results = self._aggregate_processing_results(processing_plan, song_results, annotation_results)

        self._log_processing_summary(total_results)
        return total_results

    def _aggregate_processing_results(
        self, processing_plan: dict[str, Any], song_results: ProcessingResult, annotation_results: ProcessingResult
    ) -> ProcessingResult:
        """Aggregate results from all processing phases into unified format."""
        return {
            "inserted": (song_results.get("inserted", []) + annotation_results.get("inserted", [])),
            "skipped": (
                [
                    (song, reason, {"entity_hierarchy": f"song→{song.id}"})
                    for song, reason in processing_plan.get("songs_to_skip", [])
                ]
                + song_results.get("skipped", [])
                + annotation_results.get("skipped", [])
            ),
            "failed": (song_results.get("failed", []) + annotation_results.get("failed", [])),
        }

    def update_songs_bulk(
        self,
        request: BulkSongUpdateRequest,
        *,
        options: ProcessingOptions | None = None,
    ) -> ProcessingResult:
        """
        Update files across multiple songs in bulk with parallel processing.

        This is the ETL-ready API that mirrors create_songs_bulk structure:
        1. Validate files exist and check for blocking annotations (bulk)
        2. Update songs individually in parallel (each with blob tracking and transaction)
        3. Return aggregated results

        Args:
            request: BulkSongUpdateRequest containing songs with files to update
            options: Processing options

        Returns:
            ProcessingResult with inserted annotations, skipped, and failed.
        """
        if not request.songs:
            return empty_result()

        logger.info(f"Starting bulk update of {len(request.songs)} songs")

        # Enforce options for update workflow:
        # - Always atomic (files + annotations updated together)
        # - Always allow value change (replacing file changes hash/metadata)
        # - Always precompute file_data (required for file updates)
        if options is None:
            options = ProcessingOptions(
                annotation_mode=AnnotationProcessingMode.PER_SONG_ATOMIC,
                allow_unintended_value_change=True,
                precompute_kinds=["file_data"],
            )
        else:
            # Force critical options on provided config
            options_dict = options.model_dump()
            options_dict["annotation_mode"] = AnnotationProcessingMode.PER_SONG_ATOMIC
            options_dict["allow_unintended_value_change"] = True

            precompute_kinds = set(options_dict.get("precompute_kinds", []))
            precompute_kinds.add("file_data")
            options_dict["precompute_kinds"] = list(precompute_kinds)

            options = ProcessingOptions.model_validate(options_dict)

        # Phase 1: Validate and plan
        with self.repos.connection() as validation_conn:
            update_plan = self._validate_and_plan_update(request, validation_conn)

        # Phase 2: Update songs in parallel
        update_context = ProcessingContext(
            batch=request.batch,
            options=options,
            existing=update_plan["existing_context"],
        )
        update_results = self._update_songs_individually_with_blobs(
            update_plan["songs_to_process"],
            update_context,
        )

        # Aggregate final results
        total_results: ProcessingResult = {
            "inserted": update_results["inserted"],
            "skipped": [
                (song, reason, {"entity_hierarchy": f"song→{song.id}"}) for song, reason in update_plan["songs_to_skip"]
            ]
            + update_results["skipped"],
            "failed": update_results["failed"],
        }

        self._log_processing_summary(total_results)
        return total_results

    def _validate_and_plan_update(
        self,
        request: BulkSongUpdateRequest,
        conn: Connection,
    ) -> dict[str, Any]:
        """
        Validate update request and build execution plan.
        """
        songs_to_skip = []

        # 1. Check if songs exist and resolve datasets
        song_ids = [song.id for song in request.songs]
        existing_datasets = self.repos.song.get_datasets_by_song_ids_bulk(song_ids, conn)

        # Identify missing songs and fill datasets
        valid_songs = []
        for song in request.songs:
            if song.id not in existing_datasets:
                songs_to_skip.append((song, "song_not_found"))
                continue

            valid_songs.append(song)

        if not valid_songs:
            return {
                "songs_to_process": [],
                "songs_to_skip": songs_to_skip,
                "existing_files": {},
                "existing_context": ExistingDataContext(),
            }

        # 2. Check files exist
        all_file_ids = []
        for song in valid_songs:
            all_file_ids.extend([f.id for f in song.files])

        existing_files = self.repos.file.get_files_by_ids_bulk(all_file_ids, conn)

        processed_valid_songs = []
        for song in valid_songs:
            files_missing = [f.id for f in song.files if f.id not in existing_files]
            if files_missing:
                songs_to_skip.append((song, f"files_not_found: {files_missing}"))
                continue
            processed_valid_songs.append(song)

        # 3. Check blocking annotations
        # An annotation kind is "blocking" if:
        # - It exists on the file AND is not in SAFE_FILE_UPDATE_ANNOTATION_KINDS
        # - AND the request does NOT include a replacement annotation of that kind
        # This allows callers to update files with unsafe annotations by providing replacements.
        file_kinds_map = self.repos.annotation.get_kind_names_by_file_ids_bulk(all_file_ids, conn)
        safe_kinds = {k.value for k in SAFE_FILE_UPDATE_ANNOTATION_KINDS}

        final_songs_to_process = []
        for song in processed_valid_songs:
            blocking_files = []
            for f in song.files:
                existing_kinds = set(file_kinds_map.get(f.id, []))
                unsafe_existing = existing_kinds - safe_kinds

                if unsafe_existing:
                    # Check which unsafe kinds are being replaced by the request
                    provided_kinds = {KindRegistry.get_kind_by_id(ann.kind_id).kind.value for ann in f.annotations}
                    unresolved_unsafe = unsafe_existing - provided_kinds

                    if unresolved_unsafe:
                        blocking_files.append(f"{f.id} ({sorted(unresolved_unsafe)})")

            if blocking_files:
                songs_to_skip.append((song, f"blocking_annotations: {blocking_files}"))
                continue

            final_songs_to_process.append(song)

        # Build context for downstream

        # Fetch annotations for existing files to support prechecks
        # This ensures prechecks have context on other files in the song (e.g. consistency checks)
        # or the previous state of the file being updated.
        file_annotations = defaultdict(dict)

        # Collect all file IDs for the songs being processed (not just the ones being updated)
        # This allows song-level prechecks to see all files.
        song_ids_to_process = [s.id for s in final_songs_to_process]
        all_song_files = self.repos.file.get_files_by_song_ids_bulk(song_ids_to_process, conn)

        all_relevant_file_ids = []
        for file_ids in all_song_files.values():
            all_relevant_file_ids.extend(file_ids)

        if all_relevant_file_ids:
            # We fetch file_data as it's critical for most prechecks (media properties)
            # We could expand this list if other annotations become relevant for prechecks
            file_data_annotations = self.repos.annotation.get_latest_file_annotations_bulk(
                all_relevant_file_ids, "file_data", conn
            )
            for file_id, ann in file_data_annotations.items():
                file_annotations[file_id]["file_data"] = ann.annotation_value

        existing_context = ExistingDataContext(
            song_files=dict(all_song_files),
            song_datasets=existing_datasets,
            file_annotations=file_annotations,
        )

        return {
            "songs_to_process": final_songs_to_process,
            "songs_to_skip": songs_to_skip,
            "existing_context": existing_context,
        }

    def _update_songs_individually_with_blobs(
        self,
        songs: list[SongUpdateRequest],
        context: ProcessingContext,
    ) -> InternalProcessingResult:
        """Process song updates in parallel.

        Args:
            songs: List of song update requests to process
            context: Processing context with batch, options, and existing data
        """
        if not songs:
            return empty_internal_result()

        # Calculate workers
        db_pool_size = getattr(self.repos.db.engine.pool, "size", lambda: 50)()
        n_jobs = get_max_workers(
            ParallelOperationType.IO_BOUND,
            len(songs),
            db_pool_size=db_pool_size,
            max_workers_override=context.options.max_workers_override,
        )

        results = Parallel(
            n_jobs=n_jobs,
            return_as="generator",
            backend="threading",
        )(delayed(self._song_processor.process_update)(song, context) for song in songs)

        # Aggregate
        inserted = []
        skipped = []
        failed = []
        successful_songs = []

        for res in results:
            if res is None:
                continue
            inserted.extend(res["inserted"])
            skipped.extend(res["skipped"])
            failed.extend(res["failed"])
            successful_songs.extend(res["successful_songs"])

        final_result: InternalProcessingResult = {
            "inserted": inserted,
            "skipped": skipped,
            "failed": failed,
            "successful_songs": successful_songs,
        }
        return final_result
