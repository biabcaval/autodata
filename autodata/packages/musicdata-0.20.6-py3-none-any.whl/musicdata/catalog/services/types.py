"""Common types for catalog services."""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Any, TypedDict
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from musicdata.db.models import AnnotationBatch

if TYPE_CHECKING:
    from collections.abc import Collection


# Type aliases for skipped/failed items (preserves existing tuple structure)
SkippedItem = tuple[Any, str, dict[str, Any]]  # (request, reason, context)
FailedItem = tuple[Any, str, dict[str, Any]]  # (request, error, context)


class ProcessingResult(TypedDict):
    """Standard result structure for bulk operations (public API).

    All public bulk processing methods (create_annotations_bulk, create_songs_bulk,
    update_songs_bulk, etc.) return this structure.

    Attributes:
        inserted: Successfully processed items (annotations, songs, files, etc.)
        skipped: Items skipped with reason - tuple of (request, reason_code, context_dict)
        failed: Items that failed - tuple of (request, error_message, context_dict)
    """

    inserted: list[Any]
    skipped: list[SkippedItem]
    failed: list[FailedItem]


class InternalProcessingResult(ProcessingResult):
    """Internal result structure with song tracking (not part of public API).

    Used by internal methods that need to track successfully processed songs
    for coordination between processing phases.
    """

    successful_songs: list[Any]


def empty_result() -> ProcessingResult:
    """Create an empty processing result."""
    return {"inserted": [], "skipped": [], "failed": []}


def empty_internal_result() -> InternalProcessingResult:
    """Create an empty internal processing result with song tracking."""
    return {"inserted": [], "skipped": [], "failed": [], "successful_songs": []}


class AnnotationProcessingMode(Enum):
    BULK_AFTER = "bulk_after"  # Inserts annotations in bulk in a separate transaction after the song/file
    PER_SONG_ATOMIC = "per_song_atomic"  # Inserts annotations in the same transaction as the song/file


class ProcessingOptions(BaseModel):
    """Operational parameters for song/file/annotation processing."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    annotation_mode: AnnotationProcessingMode = Field(default=AnnotationProcessingMode.BULK_AFTER)
    allow_unintended_value_change: bool = Field(default=False, description="Whether to allow unintended value changes")
    allow_standard_downgrade: bool = Field(default=False, description="Whether to allow standard downgrade")
    skip_missing: bool = Field(
        default=False,
        description="Whether to skip annotations for songs/files that don't exist in the database or throw an error",
    )
    precompute_kinds: list[str] = Field(default_factory=list, description="Annotation kinds to precompute")
    encryption_public_key_env: str = Field(
        default="ENCRYPTION_PUBLIC_KEY_PATH",
        description=("Env var with path to RSA public key PEM for encrypting media metadata"),
    )
    max_workers_override: int | None = Field(
        default=None, description="Override number of workers for parallel operations"
    )

    @field_validator("precompute_kinds")
    @classmethod
    def deduplicate_precompute_kinds(cls, kinds: Collection[str]) -> list[str]:
        """Ensure precompute_kinds contains unique items while preserving order."""
        seen: set[str] = set()
        unique_kinds: list[str] = []
        for kind in kinds:
            cleaned = kind.strip()
            if not cleaned or cleaned in seen:
                continue
            seen.add(cleaned)
            unique_kinds.append(cleaned)
        return unique_kinds


class ExistingDataContext(BaseModel):
    """Context containing existing database data for processing and validation.

    Consolidates all data fetched from the database about existing entities.
    Using a single context object makes it easy to add new data without changing
    method signatures.
    """

    model_config = ConfigDict(frozen=True)

    # Existence checks (bool maps for fast lookup)
    songs: dict[UUID, bool] = Field(default_factory=dict, description="Song existence map")
    files: dict[UUID, bool] = Field(default_factory=dict, description="File existence map")

    # Relationship data
    song_files: dict[UUID, list[UUID]] = Field(default_factory=dict, description="Existing files grouped by song ID")

    # Map song_id -> dataset name
    # Used for update file workflows, which don't have a dataset in the request
    song_datasets: dict[UUID, str] = Field(default_factory=dict, description="Dataset name for song ID")

    # Annotation data for prechecks
    # Map file_id -> {kind_name: annotation_value}
    file_annotations: dict[UUID, dict[str, Any]] = Field(
        default_factory=dict, description="Existing annotations grouped by file ID and kind name"
    )


class ProcessingContext(BaseModel):
    """All context needed for song/file processing.

    Groups related data that's always passed together, reducing parameter count
    and making relationships explicit.
    """

    model_config = ConfigDict(frozen=True)

    batch: AnnotationBatch | None
    options: ProcessingOptions
    existing: ExistingDataContext = Field(default_factory=ExistingDataContext)
