"""Song Atomic Processor: Handles the atomic processing of single songs."""

from pathlib import Path
from typing import Any
from uuid import UUID

from loguru import logger

from musicdata.annotations import KindRegistry
from musicdata.catalog.exceptions import (
    AnnotationError,
    BlobOperationError,
    ConfigurationError,
    PrecheckError,
    SongProcessingError,
    resolve_failure_type,
)
from musicdata.catalog.services.annotation_service import AnnotationService
from musicdata.catalog.services.types import (
    AnnotationProcessingMode,
    ExistingDataContext,
    FailedItem,
    InternalProcessingResult,
    ProcessingContext,
    ProcessingOptions,
    SkippedItem,
    empty_internal_result,
)
from musicdata.db.models import AnnotationBatch
from musicdata.db.models.requests import (
    AnnotationRequest,
    FileRequest,
    SongRequest,
    SongUpdateRequest,
)
from musicdata.db.repositories.manager import RepositoryManager
from musicdata.etl.prechecks import (
    SongPrecheckContext,
    ValidationSeverity,
    run_all_song_prechecks,
)
from musicdata.etl.precompute import run_precompute_pipeline
from musicdata.utils.gcp import (
    BlobExt,
    TransactionalBlobTracker,
    copy_between_buckets,
    transactional_blob_manager,
)


class SongAtomicProcessor:
    """
    Handles the atomic processing of a single song.

    This encapsulates the logic for:
    1. Blob management (copying/precomputing) with rollback support.
    2. Logic-level validation (prechecks).
    3. Atomic Database insertion/updates.
    """

    def __init__(
        self,
        repository_manager: RepositoryManager,
        annotation_service: AnnotationService,
    ) -> None:
        self.repos = repository_manager
        self.annotations = annotation_service

    def collect_annotation_requests(self, song_request: SongRequest) -> list[AnnotationRequest]:
        """Collect all annotation requests for a song, ensuring required IDs are set."""
        collected: list[AnnotationRequest] = []

        # Song-level annotations
        for ann_req in song_request.annotations:
            if ann_req.song_id is None:
                ann_req.song_id = song_request.id
            collected.append(ann_req)

        # File-level annotations
        for file_req in song_request.files:
            for ann_req in file_req.annotations:
                if ann_req.file_id is None:
                    ann_req.file_id = file_req.id
                collected.append(ann_req)

        return collected

    def process_creation(  # noqa: C901
        self,
        song_request: SongRequest,
        context: ProcessingContext,
    ) -> InternalProcessingResult:
        """Process a single song: copy blobs, then insert song/files with blob tracking.

        Args:
            song_request: The song to create with its files and annotations
            context: Processing context containing batch, options, and existence maps
        """
        song_result = empty_internal_result()
        options = context.options

        try:
            # Each song gets its own blob tracking context for isolation
            with transactional_blob_manager() as blob_tracker:
                # Step 1: Copy or Precompute + stage blobs for this song
                if options.precompute_kinds:
                    # Force per-song atomic annotations for precompute path
                    options = ProcessingOptions.model_validate(
                        {**options.model_dump(), "annotation_mode": AnnotationProcessingMode.PER_SONG_ATOMIC}
                    )
                    _processed = self._precompute_and_stage_blobs(
                        song_request,
                        context.existing.files,
                        blob_tracker,
                        options=options,
                        batch=context.batch,
                    )
                    logger.debug(f"Precomputed and staged {_processed} files for song {song_request.id}")
                else:
                    _blobs_copied = self._copy_blobs(song_request, context.existing.files, blob_tracker)

                # Run song-level prechecks using precomputed data (if any)
                try:
                    precheck_ctx = self._build_precheck_context(song_request, context.existing)
                    self._apply_prechecks(song_request, precheck_ctx)
                except PrecheckError:
                    raise  # Propagate specific precheck errors
                except Exception as e:
                    # Fail-safe: treat unexpected precheck errors as blocking to avoid silent bad data
                    msg = f"Precheck execution failed: {e}"
                    raise SongProcessingError(msg) from e

                # Step 2: Insert song/files with individual transaction
                # Buffer inserted entities locally; commit to song_result only after successful transaction
                inserted_buffer: list[Any] = []
                skipped_buffer: list[SkippedItem] = []
                failed_buffer: list[FailedItem] = []

                with self.repos.transaction() as song_conn:
                    # Insert song only if it doesn't exist
                    if not context.existing.songs.get(song_request.id, False):
                        song = song_request.to_song()
                        self.repos.song.insert_song(song_conn, song)
                        inserted_buffer.append(song)

                    # Insert only new files
                    new_files = [
                        file_req.to_file()
                        for file_req in song_request.files
                        if not context.existing.files.get(file_req.id, False)
                    ]

                    if new_files:
                        inserted_files = self.repos.file.insert_files_bulk(song_conn, new_files)
                        if inserted_files:
                            inserted_buffer.extend(inserted_files)

                    # If per-song atomic mode, process annotations within the same transaction
                    if options.annotation_mode == AnnotationProcessingMode.PER_SONG_ATOMIC:
                        all_annotation_requests = self.collect_annotation_requests(song_request)
                        if all_annotation_requests:
                            ann_results = self.annotations.create_annotations_bulk(
                                all_annotation_requests,
                                context.batch,
                                song_conn,
                                options=options,
                            )
                            inserted_buffer.extend(ann_results.get("inserted", []))
                            skipped_buffer.extend(ann_results.get("skipped", []))
                            failed_buffer.extend(ann_results.get("failed", []))

                # Transaction succeeded: commit buffered results
                if inserted_buffer:
                    song_result["inserted"].extend(inserted_buffer)
                if skipped_buffer:
                    song_result["skipped"].extend(skipped_buffer)
                if failed_buffer:
                    song_result["failed"].extend(failed_buffer)

                song_result["successful_songs"].append(song_request)

        except Exception as e:  # noqa: BLE001
            # transactional_blob_manager() automatically rolls back on exception
            failure_type = resolve_failure_type(e)
            logger.warning(f"Failed to process song {song_request.id}: {e} [{failure_type}]")

            error_context = {
                "entity_hierarchy": f"song→{song_request.id}",
                "failure_type": failure_type,
                "dataset": song_request.dataset,
            }
            song_result["failed"].append((song_request, str(e), error_context))

        return song_result

    def process_update(
        self,
        song_request: SongUpdateRequest,
        context: ProcessingContext,
    ) -> InternalProcessingResult:
        """Process a single song update with blob management.

        Args:
            song_request: The song update request with files to update
            context: Processing context containing batch, options, and existing data
        """
        try:
            with transactional_blob_manager() as blob_tracker:
                # 1. Precompute and stage blobs
                # Get dataset from context since it's not in the request
                dataset = context.existing.song_datasets.get(song_request.id)
                if not dataset:
                    msg = f"Dataset not found for song {song_request.id} in execution context"
                    # This should be caught by validation, but fail safe
                    failed: list[FailedItem] = [(song_request, msg, {})]
                    return {"inserted": [], "skipped": [], "failed": failed, "successful_songs": []}

                processed_count = self._precompute_and_update_files(
                    song_request,
                    blob_tracker,
                    context.options,
                    context.batch,
                    dataset_name=dataset,
                )

                if processed_count == 0:
                    skipped: list[SkippedItem] = [(song_request, "no_files_processed", {})]
                    return {"inserted": [], "skipped": skipped, "failed": [], "successful_songs": []}

                # 2. Run song-level prechecks using new file_data
                try:
                    precheck_ctx = self._build_precheck_context(song_request, context.existing)
                    self._apply_prechecks(song_request, precheck_ctx)
                except PrecheckError:
                    raise  # Propagate specific precheck errors
                except Exception as e:
                    msg = f"Precheck execution failed: {e}"
                    raise SongProcessingError(msg) from e

                # 3. Transactional update
                with self.repos.transaction() as conn:
                    # Update files and insert annotations
                    inserted_annotations_models = []
                    file_updates = []
                    all_annotation_reqs = []

                    for file_req in song_request.files:
                        # Prepare file update
                        file_updates.append(
                            {
                                "id": file_req.id,
                                "path": file_req.path,
                                "md5_hash": file_req.md5_hash,
                            }
                        )

                        # Collect annotation requests
                        if file_req.annotations:
                            all_annotation_reqs.extend(file_req.annotations)

                    # Bulk Update Files
                    if file_updates:
                        self.repos.file.update_files_bulk(file_updates, conn)

                    # Bulk Insert Annotations using shared logic
                    if all_annotation_reqs:
                        ann_results = self.annotations.create_annotations_bulk(
                            all_annotation_reqs,
                            context.batch,
                            conn,
                            options=context.options,
                        )
                        inserted_annotations_models.extend(ann_results.get("inserted", []))
                        # Update requests might fail/skip during annotation creation
                        # But for update workflows we usually expect success if prechecks passed
                        if ann_results.get("failed"):
                            error_msg = (
                                f"Failed to create annotations for song {song_request.id}: {ann_results['failed']}"
                            )
                            logger.error(error_msg)
                            raise AnnotationError(error_msg)  # noqa: TRY301

                    result: InternalProcessingResult = {
                        "inserted": inserted_annotations_models,
                        "skipped": [],
                        "failed": [],
                        "successful_songs": [song_request],
                    }
                    return result
        except Exception as e:  # noqa: BLE001
            # transactional_blob_manager() automatically rolls back on exception
            failure_type = resolve_failure_type(e)
            logger.error(f"Failed to update song {song_request.id}: {e} [{failure_type}]")

            failed_result: list[FailedItem] = [(song_request, str(e), {"failure_type": failure_type})]
            return {"inserted": [], "skipped": [], "failed": failed_result, "successful_songs": []}

    def _get_target_path(self, song_request: SongRequest, file_request: FileRequest) -> str:
        """Helper to generate target path."""
        return (
            f"datasets/{song_request.dataset}/{song_request.id}/"
            f"{file_request.id}{Path(file_request.path).suffix.lower()}"
        )

    def _copy_blobs(
        self, song_request: SongRequest, existing_files: dict[UUID, bool], blob_tracker: TransactionalBlobTracker
    ) -> int:
        """Copy blobs for a single song's files."""
        blobs_copied = 0

        for file_req in song_request.files:
            if existing_files.get(file_req.id, False):
                continue  # File already exists, skip blob copying

            target_path = self._get_target_path(song_request, file_req)
            target_uri = f"moises-data-catalog/{target_path}"

            # Normalize current path to bucket/path (no gs://) for robust comparison
            current_uri = BlobExt.from_uri(file_req.path).uri_without_gs

            if current_uri == target_uri:
                # Already in the correct location: compute/verify md5 from remote metadata
                existing_blob = BlobExt.from_uri(target_uri)
                actual_md5 = existing_blob.md5_hash_decoded
                if file_req.md5_hash != actual_md5:
                    file_req.md5_hash = actual_md5
            else:
                # Track target blob for rollback (auto-detects new vs replacement)
                target_blob = BlobExt("moises-data-catalog", target_path)
                blob_tracker.track(target_blob)

                # Copy blob into the standardized bucket/path
                try:
                    copied_blob = copy_between_buckets(file_req.path, "moises-data-catalog", target_path)
                except Exception as e:
                    msg = f"Failed to copy blob from {file_req.path} to {target_path}: {e}"
                    raise BlobOperationError(msg) from e

                file_req.path = copied_blob.uri_without_gs
                file_req.md5_hash = copied_blob.md5_hash_decoded
                blobs_copied += 1

        return blobs_copied

    def _get_effective_precompute_kinds(
        self,
        annotations: list[AnnotationRequest],
        requested_kinds: list[str],
    ) -> list[str]:
        """
        Filter out precompute kinds that are already provided as annotations.

        When annotations of precomputable kinds (e.g., file_data, media_metadata) are
        already provided in the request, we skip recomputing them. This allows callers
        to supply their own precomputed data.

        Args:
            annotations: List of annotation requests already attached to the file
            requested_kinds: List of kind names requested for precomputation

        Returns:
            List of kind names that still need to be precomputed
        """
        if not annotations or not requested_kinds:
            return requested_kinds

        # Build set of kind names that are already provided
        provided_kind_names: set[str] = set()
        for ann in annotations:
            kind = KindRegistry.get_kind_by_id(ann.kind_id)
            provided_kind_names.add(kind.kind.value)

        # Return only kinds not already provided
        return [k for k in requested_kinds if k not in provided_kind_names]

    def _precompute_file(
        self,
        file_req: FileRequest,
        target_path: str,
        blob_tracker: TransactionalBlobTracker,
        precompute_kinds: list[str],
        batch_id: UUID,
    ) -> None:
        """Run precompute pipeline and attach resulting annotations to file.

        Mutates file_req in place:
        - Updates path and md5_hash from cleaned blob
        - Appends annotation requests for precomputed kinds

        Args:
            file_req: File request to precompute (mutated in place)
            target_path: Destination path in the data catalog bucket
            blob_tracker: Transactional blob tracker for rollback support
            precompute_kinds: Kinds to precompute (e.g., ["file_data", "media_metadata"])
            batch_id: Batch ID to associate with created annotations
        """
        effective_kinds = self._get_effective_precompute_kinds(
            file_req.annotations,
            precompute_kinds,
        )

        try:
            cleaned_blob, step_results = run_precompute_pipeline(
                file_req.path,
                dest_bucket="moises-data-catalog",
                dest_blob_name=target_path,
                blob_tracker=blob_tracker,
                selected_kinds=effective_kinds,
            )
        except Exception as e:
            msg = f"Precompute pipeline failed for {file_req.path}: {e}"
            raise BlobOperationError(msg) from e

        if cleaned_blob is not None:
            file_req.path = cleaned_blob.uri_without_gs
            file_req.md5_hash = cleaned_blob.md5_hash_decoded

        for step_result in step_results:
            try:
                kind = KindRegistry.get_kind_by_name(step_result.kind)
            except Exception:  # noqa: BLE001
                msg = f"Precompute kind '{step_result.kind}' not found in kinds cache"
                raise AnnotationError(msg) from None

            file_req.annotations.append(
                AnnotationRequest.for_file(
                    file_id=file_req.id,
                    kind_id=kind.id,
                    annotation_value=step_result.annotation_value,
                    standard=step_result.standard,
                    annotation_source=step_result.annotation_source,
                    batch_id=batch_id,
                )
            )

    def _precompute_and_stage_blobs(
        self,
        song_request: SongRequest,
        existing_files: dict[UUID, bool],
        blob_tracker: TransactionalBlobTracker,
        *,
        options: ProcessingOptions,
        batch: AnnotationBatch | None,
    ) -> int:
        """Run media precompute for each new file and stage cleaned blobs.

        For files that already exist, no action is taken. For new files, this will:
        - Download the source blob
        - Extract tags and encrypt them (media_metadata)
        - Strip metadata and upload cleaned file to target path
        - Update the in-memory FileRequest with final path and md5
        - Attach file-level annotations (e.g., file_data, media_metadata)

        Returns number of processed files for this song.
        """
        if batch is None:
            msg = "Batch is required when precompute pre-processing is enabled"
            raise ConfigurationError(msg)

        processed = 0
        for file_req in song_request.files:
            if existing_files.get(file_req.id, False):
                continue

            target_path = self._get_target_path(song_request, file_req)
            self._precompute_file(
                file_req,
                target_path,
                blob_tracker,
                options.precompute_kinds,
                batch.id,
            )
            processed += 1

        return processed

    def _build_precheck_context(
        self,
        song_request: SongRequest | SongUpdateRequest,
        existing_context: ExistingDataContext,
    ) -> SongPrecheckContext:
        """Build precheck context from precomputed annotations and existing database data.

        Combines:
        1. Precomputed annotations attached to new file requests
        2. Existing annotations already in the database

        This allows prechecks to validate consistency across both new and existing files.

        Returns an (possibly empty) context; plugins decide whether to run.
        """
        annotations_by_file: dict[UUID, dict[str, Any]] = {}

        # Step 1: Collect precomputed data from new files in the song request
        for file_req in song_request.files:
            kinds_map: dict[str, Any] = {}

            # Access annotations directly to ensure we see any added in-memory
            annotations = file_req.annotations
            if not annotations:
                continue

            for ann_req in annotations:
                try:
                    kind = KindRegistry.get_kind_by_id(ann_req.kind_id)
                    kind_name = kind.kind.value
                    kinds_map[kind_name] = ann_req.annotation_value
                except Exception as e:
                    msg = f"Failed to resolve annotation kind id {ann_req.kind_id} for file {file_req.id}: {e}"
                    raise AnnotationError(msg) from e

            if kinds_map:
                annotations_by_file[file_req.id] = kinds_map

        # Step 2: Merge existing annotations from database for files already in this song
        # Priority: NEW precomputed annotations (from Step 1) override OLD database annotations
        existing_file_ids = existing_context.song_files.get(song_request.id, [])

        for file_id in existing_file_ids:
            if file_id in existing_context.file_annotations:
                # Merge ALL annotation kinds at once - no code change needed for new kinds!
                existing_anns = existing_context.file_annotations[file_id]
                new_anns = annotations_by_file.get(file_id, {})
                # Start with existing, then overlay new (new takes priority)
                annotations_by_file[file_id] = {**existing_anns, **new_anns}

        return SongPrecheckContext(annotations_by_file=annotations_by_file)

    def _apply_prechecks(self, song_request: SongRequest | SongUpdateRequest, ctx: SongPrecheckContext) -> None:
        """Run all registered song prechecks and apply their effects.

        - ERROR issues raise and fail the song
        - WARNING issues mark all files in the song as problematic
        """
        issues = run_all_song_prechecks(song_request, ctx)

        hard_issues = [i for i in issues if i.severity == ValidationSeverity.ERROR]
        if hard_issues:
            # Include detailed messages with field names and values for better debugging
            summary = "; ".join(f"{i.plugin}:{i.code}: {i.message}" for i in hard_issues)
            raise PrecheckError(summary)

        if any(i.severity == ValidationSeverity.WARNING for i in issues):
            for f in song_request.files:
                f.is_problematic = True

    def _precompute_and_update_files(
        self,
        song_request: SongUpdateRequest,
        blob_tracker: TransactionalBlobTracker,
        options: ProcessingOptions,
        batch: AnnotationBatch | None,
        dataset_name: str,
    ) -> int:
        """Precompute file data and update file requests with new paths/hashes.

        Unlike _precompute_and_stage_blobs, this processes all files without
        skipping (files are pre-validated in the update workflow).

        Returns number of processed files.
        """
        if batch is None:
            msg = "Batch is required when precompute pre-processing is enabled"
            raise ConfigurationError(msg)

        processed = 0
        for file_req in song_request.files:
            # Target path construction uses dataset from context
            suffix = Path(file_req.path).suffix.lower()
            target_path = f"datasets/{dataset_name}/{song_request.id}/{file_req.id}{suffix}"

            self._precompute_file(
                file_req,
                target_path,
                blob_tracker,
                options.precompute_kinds,
                batch.id,
            )
            processed += 1

        return processed
