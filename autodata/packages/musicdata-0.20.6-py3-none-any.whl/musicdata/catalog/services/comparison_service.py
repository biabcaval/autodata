"""Service for annotation comparison operations."""

from typing import Any, ClassVar

from loguru import logger

from musicdata.catalog.exceptions import StandardDowngradeError, UnintendedValueChangeError
from musicdata.db.models import Annotation, Standard
from musicdata.etl.models.status import SkipReason


class ComparisonService:
    """Service for comparing annotations and detecting changes."""

    # Define standard priority order (higher index = higher priority)
    STANDARD_PRIORITY: ClassVar[dict[Standard, int]] = {
        Standard.BRONZE: 1,
        Standard.SILVER: 2,
        Standard.GOLD: 3,
    }

    @staticmethod
    def _make_value_canonical_and_comparable(value: Any) -> Any:  # noqa: ANN401
        """
        Recursively transforms a value (often from JSON-like structures)
        into a canonical and comparable form.
        - Dictionaries: converted to a tuple of (key, canonical_value) pairs, sorted by key.
        - Lists: converted to a tuple of canonical_value elements, sorted if possible.
        - Other types are returned as is.
        """
        if isinstance(value, dict):
            return tuple(
                sorted((k, ComparisonService._make_value_canonical_and_comparable(v)) for k, v in value.items())
            )
        if isinstance(value, list):
            # Make elements canonical.
            canonical_elements = [ComparisonService._make_value_canonical_and_comparable(elem) for elem in value]
            # Try to sort them. If they are unmixable types (e.g. int and tuple), sorting will fail.
            try:
                return tuple(sorted(canonical_elements))
            except TypeError:
                # If sorting fails (e.g., list of mixed, non-comparable types),
                # return as a tuple of canonical elements (order becomes significant for this list).
                return tuple(canonical_elements)
        # Add set handling if sets can appear in annotation_value from Pydantic models or elsewhere
        if isinstance(value, set):
            return tuple(sorted(ComparisonService._make_value_canonical_and_comparable(elem) for elem in value))
        return value  # Primitives (int, str, UUID, float, bool, None) are returned as is

    def _is_standard_downgrade(self, old_standard: Standard, new_standard: Standard) -> bool:
        """
        Check if the new standard represents a downgrade from the old standard.

        Args:
            old_standard: The existing annotation's standard
            new_standard: The new annotation's standard

        Returns:
            True if the new standard is lower priority than the old standard
        """
        old_priority = self.STANDARD_PRIORITY[old_standard]
        new_priority = self.STANDARD_PRIORITY[new_standard]
        return new_priority < old_priority

    def are_annotations_effectively_same(
        self,
        new_ann: Annotation,
        old_ann: Annotation | None,
        *,
        allow_unintended_value_change: bool = False,
        allow_standard_downgrade: bool = False,
    ) -> bool:
        """
        Compares an old annotation with new annotation data,
        focusing on semantic equality. Checks kind_id, standard, and annotation_value.

        IMPORTANT: When annotation kinds are versioned, old and new annotations may have
        different kind_ids but represent the same kind (e.g., 'key' v1 vs 'key' v2).
        The kind_name parameter ensures downgrade checks happen correctly across kind versions.

        Args:
            old_ann: The existing annotation (None if this is a new annotation)
            new_ann: The new annotation data
            allow_unintended_value_change: Whether to allow unintended value changes (default: False)
            allow_standard_downgrade: Whether to allow standard downgrades (default: False)

        Returns:
            True if annotations are effectively the same, False otherwise

        Raises:
            UnintendedValueChangeError: When standard is the same but value differs
            StandardDowngradeError: When attempting to downgrade annotation standard
        """
        if old_ann is None:
            # If there's no old annotation, the new one is considered different (it will be an insert).
            return False

        # Determine entity type and ID for logging
        entity_id = new_ann.file_id if new_ann.file_id else new_ann.song_id
        entity_type = "file" if new_ann.file_id else "song"

        # Note: We don't check kind_id equality - callers ensure same kind by name
        # Different kind_ids indicate kind versioning (schema change)
        kind_ids_differ = old_ann.kind_id != new_ann.kind_id

        # 1. Check for standard downgrades FIRST (critical for kind versioning)
        # This must happen before any early returns to block downgrades
        if old_ann.standard != new_ann.standard:
            if not allow_standard_downgrade and self._is_standard_downgrade(old_ann.standard, new_ann.standard):
                error_msg = (
                    f"Standard downgrade not allowed for {entity_type} {entity_id}. "
                    f"Attempted to downgrade from {old_ann.standard} to {new_ann.standard}."
                )
                if kind_ids_differ:
                    error_msg += f" Kind_id changed from {old_ann.kind_id} to {new_ann.kind_id} (kind versioning)."
                error_msg += " Use allow_standard_downgrade=True to override."
                raise StandardDowngradeError(error_msg)

            logger.debug(
                f"Annotation for {entity_type} {entity_id}: 'standard' differs. "
                f"Old: {old_ann.standard}, New: {new_ann.standard}"
            )
            return False

        # 2. After blocking downgrades, check if kind_ids differ
        # If kind schema changed (different kind_id), treat as different annotation
        # This ensures new schema versions are always inserted, even with same value
        if kind_ids_differ:
            logger.debug(
                f"Annotation for {entity_type} {entity_id}: 'kind_id' differs "
                f"(kind versioning/schema change). Old: {old_ann.kind_id}, New: {new_ann.kind_id}"
            )
            return False

        # 3. Compare 'annotation_value' by converting to a canonical, comparable form
        # This handles nested structures, list order, and dict key order.
        old_av_comparable = self._make_value_canonical_and_comparable(old_ann.annotation_value)
        new_av_comparable = self._make_value_canonical_and_comparable(new_ann.annotation_value)

        if old_av_comparable != new_av_comparable:
            msg = f"Annotation for {entity_type} {entity_id}: 'annotation_value' differs after canonicalization."

            # Raise when the standard is the same but the value differs (source is ignored)
            if not allow_unintended_value_change and old_ann.standard == new_ann.standard:
                raise UnintendedValueChangeError(msg)

            logger.debug(msg)
            return False

        # If all checks pass, the annotations are considered effectively the same.
        return True

    def filter_changed_annotations(
        self,
        new_annotations: list[Annotation],
        existing_annotations: dict[str, Annotation],  # key could be file_id or song_id
        *,
        allow_unintended_value_change: bool = False,
        allow_standard_downgrade: bool = False,
    ) -> tuple[list[Annotation], list[tuple[Annotation, str, dict]]]:
        """
        Bulk comparison for ETL performance.

        IMPORTANT: Caller MUST ensure all annotations in new_annotations are for the same kind.

        Args:
            new_annotations: List of new annotations to process (all same kind)
            existing_annotations: Dict mapping entity_id (file_id/song_id) to existing annotation
            allow_unintended_value_change: Whether to allow unintended value changes (default: False)
            allow_standard_downgrade: Whether to allow standard downgrades (default: False)

        Returns:
            Tuple of (annotations_to_insert, annotations_skipped)

        Raises:
            StandardDowngradeError: When attempting to downgrade annotation standards
            UnintendedValueChangeError: When standard is the same but value differs
        """
        annotations_to_insert = []
        annotations_skipped = []

        for new_ann in new_annotations:
            # Determine the key for lookup (file_id or song_id)
            entity_type = "file" if new_ann.file_id else "song"
            entity_id = str(new_ann.file_id) if new_ann.file_id else str(new_ann.song_id)
            existing_ann = existing_annotations.get(entity_id)

            try:
                if self.are_annotations_effectively_same(
                    new_ann=new_ann,
                    old_ann=existing_ann,
                    allow_unintended_value_change=allow_unintended_value_change,
                    allow_standard_downgrade=allow_standard_downgrade,
                ):
                    annotations_skipped.append((new_ann, SkipReason.NO_CHANGE.value, {}))
                else:
                    annotations_to_insert.append(new_ann)
            except UnintendedValueChangeError:
                logger.warning(f"Skipping annotation for {entity_type} {entity_id}: Unintended value change")
                annotations_skipped.append((new_ann, "unintended_value_change", {}))
            except StandardDowngradeError:
                logger.warning(f"Skipping annotation for {entity_type} {entity_id}: Standard downgrade")
                annotations_skipped.append((new_ann, "standard_downgrade", {}))

        logger.debug(
            f"Bulk comparison complete: {len(annotations_to_insert)} to insert, {len(annotations_skipped)} skipped"
        )

        return annotations_to_insert, annotations_skipped
