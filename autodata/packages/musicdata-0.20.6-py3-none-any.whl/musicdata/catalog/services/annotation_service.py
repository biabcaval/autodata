"""Annotation Service: Handles bulk annotation creation and change detection."""

from collections import defaultdict
from collections.abc import Collection
from uuid import UUID

from loguru import logger
from sqlalchemy import Connection

from musicdata.annotations import KindRegistry
from musicdata.catalog.services.comparison_service import ComparisonService
from musicdata.catalog.services.types import ProcessingOptions, ProcessingResult, SkippedItem, empty_result
from musicdata.db.models import Annotation, AnnotationBatch
from musicdata.db.models.requests import AnnotationRequest
from musicdata.db.repositories.manager import RepositoryManager


class AnnotationService:
    """
    Service for handling annotation operations, specifically bulk creation and change detection.
    """

    def __init__(
        self,
        repository_manager: RepositoryManager,
        comparison_service: ComparisonService,
    ) -> None:
        self.repos = repository_manager
        self.comparison = comparison_service

    def validate_files_exist_bulk(self, file_ids: Collection[UUID], conn: Connection) -> dict[UUID, bool]:
        """Bulk validation that files exist in the database."""
        return self.repos.file.do_files_exist_bulk(file_ids, conn)

    def validate_songs_exist_bulk(self, song_ids: Collection[UUID], conn: Connection) -> dict[UUID, bool]:
        """Bulk validation that songs exist in the database."""
        return self.repos.song.do_songs_exist_bulk(song_ids, conn)

    def _prepare_annotations_with_change_detection(
        self,
        annotations: list[Annotation],
        request_lookup: dict[str, AnnotationRequest],
        conn: Connection,
        *,
        options: ProcessingOptions,
    ) -> tuple[list[Annotation], list[SkippedItem]]:
        """
        Prepare annotations for bulk insert by performing change detection in bulk.

        This method handles both file- and song-level annotations. It groups by
        (is_song, kind_id), retrieves the latest annotations per entity in bulk,
        and uses the comparison service to determine which annotations changed.

        Returns a tuple of (annotations_to_insert, requests_to_skip).
        """
        if not annotations:
            return [], []

        annotations_to_insert: list[Annotation] = []
        requests_to_skip: list[SkippedItem] = []

        # Group by (is_song, kind_id)
        grouped: dict[tuple[bool, UUID], list[Annotation]] = defaultdict(list)
        for ann in annotations:
            is_song = ann.song_id is not None
            grouped[(is_song, ann.kind_id)].append(ann)

        for (is_song, kind_id), annotations_for_kind in grouped.items():
            kind = KindRegistry.get_kind_by_id(kind_id)

            if is_song:
                entity_ids: list[UUID] = [a.song_id for a in annotations_for_kind if a.song_id is not None]  # type: ignore[assignment]
                existing_annotations = self.repos.annotation.get_latest_song_annotations_bulk(
                    entity_ids, kind.kind.value, conn
                )
                id_getter = lambda a: a.song_id  # noqa: E731
                entity_label = "song"
            else:
                entity_ids = [a.file_id for a in annotations_for_kind if a.file_id is not None]  # type: ignore[assignment]
                existing_annotations = self.repos.annotation.get_latest_file_annotations_bulk(
                    entity_ids, kind.kind.value, conn
                )
                id_getter = lambda a: a.file_id  # noqa: E731
                entity_label = "file"

            existing_by_str_id = {str(k): v for k, v in existing_annotations.items()}

            # Filter out unchanged annotations for this kind
            changed_annotations, skipped_annotations = self.comparison.filter_changed_annotations(
                annotations_for_kind,
                existing_by_str_id,
                allow_unintended_value_change=options.allow_unintended_value_change,
                allow_standard_downgrade=options.allow_standard_downgrade,
            )

            # Track skipped requests using dictionary lookup
            for ann, reason, _context in skipped_annotations:
                original_request = request_lookup[ann.model_dump_json()]
                context = {
                    "entity_hierarchy": f"{entity_label}→{id_getter(ann)}→annotation",
                    "annotation_kind": str(ann.kind_id),
                    "skip_reason_detail": reason,
                }
                requests_to_skip.append((original_request, reason, context))

            annotations_to_insert.extend(changed_annotations)

        return annotations_to_insert, requests_to_skip

    def _filter_requests_by_entity_existence(
        self, requests: list[AnnotationRequest], conn: Connection
    ) -> tuple[list[AnnotationRequest], list[SkippedItem]]:
        """
        Filter annotation requests by referenced entity existence.

        Skips requests whose referenced file or song does not exist, while passing
        through requests that target the other entity type or have no entity set
        (the latter should be validated elsewhere).

        Returns:
            (valid_requests, skipped_requests)
        """
        if not requests:
            return [], []

        # Partition requests by entity reference
        file_requests = [req for req in requests if req.file_id is not None]
        song_requests = [req for req in requests if req.song_id is not None]

        # Bulk existence checks
        files_exist: dict[UUID, bool] = {}
        songs_exist: dict[UUID, bool] = {}

        if file_requests:
            file_ids = [req.file_id for req in file_requests if req.file_id is not None]
            files_exist = self.validate_files_exist_bulk(file_ids, conn)
        if song_requests:
            song_ids = [req.song_id for req in song_requests if req.song_id is not None]
            songs_exist = self.validate_songs_exist_bulk(song_ids, conn)

        # Filter and collect skips
        valid_requests: list[AnnotationRequest] = []
        skipped_requests: list[SkippedItem] = []

        for req in requests:
            if req.file_id is not None and not files_exist.get(req.file_id, False):
                logger.warning(f"File {req.file_id} not found in database, skipping annotation")
                context = {"entity_hierarchy": f"missing_file→{req.file_id}→annotation", "missing_entity": "file"}
                skipped_requests.append((req, "file_not_found", context))
                continue
            if req.song_id is not None and not songs_exist.get(req.song_id, False):
                logger.warning(f"Song {req.song_id} not found in database, skipping annotation")
                context = {"entity_hierarchy": f"missing_song→{req.song_id}→annotation", "missing_entity": "song"}
                skipped_requests.append((req, "song_not_found", context))
                continue
            valid_requests.append(req)

        return valid_requests, skipped_requests

    def _filter_missing_entities(
        self, requests: list[AnnotationRequest], conn: Connection, *, skip: bool
    ) -> tuple[list[AnnotationRequest], list[SkippedItem]]:
        """
        Apply missing-entity filters depending on configuration.

        When skip is False, returns original requests and an empty skipped list.
        When skip is True, applies file and song existence filters and returns
        filtered requests along with combined skipped entries.
        """
        if not skip:
            return requests, []

        return self._filter_requests_by_entity_existence(requests, conn)

    def create_annotations_bulk(
        self,
        requests: list[AnnotationRequest],
        batch: AnnotationBatch | None,
        conn: Connection,
        *,
        options: ProcessingOptions | None = None,
    ) -> ProcessingResult:
        """
        Create annotations in bulk with automatic change detection.

        This method is optimized for ETL workloads and provides the best ergonomics:
        - Bulk revision calculation in minimal database queries
        - Automatic change detection using existing bulk logic
        - Unchanged annotations are automatically skipped
        - Uses the provided connection (should be transactional)

        Args:
            requests: List of annotation requests
            batch: Optional batch to create
            conn: Database connection (should be transactional)
            options: Processing options

        Returns:
            ProcessingResult with inserted annotations, skipped requests, and failed requests.
        """
        if not requests:
            return empty_result()

        options = options or ProcessingOptions()

        # Filter out requests for non-existent songs/files if enabled
        valid_requests, validation_skipped = self._filter_missing_entities(requests, conn, skip=options.skip_missing)

        # Continue with existing logic using valid_requests
        if not valid_requests:
            return {"inserted": [], "skipped": validation_skipped, "failed": []}

        # Calculate revisions for all valid requests efficiently
        revision_map = self.repos.annotation.get_next_revisions_bulk(valid_requests, conn)

        # Detect duplicates in the batch - business rule: only one annotation per (entity_id, kind_id) per batch
        seen_keys: set[tuple[UUID, UUID, bool]] = set()
        annotations = []
        request_to_annotation_map = {}

        for request in valid_requests:
            # Create the key for revision lookup
            if request.song_id is not None:
                entity_id = request.song_id
            elif request.file_id is not None:
                entity_id = request.file_id
            else:
                msg = f"AnnotationRequest must have either song_id or file_id set: {request}"
                raise ValueError(msg)

            key = (entity_id, request.kind_id, request.is_song_annotation)

            # Check for duplicates
            if key in seen_keys:
                entity_type = "song" if request.is_song_annotation else "file"
                msg = f"Duplicate annotation in batch: {entity_type}_id={entity_id}, kind_id={request.kind_id}"
                raise ValueError(msg)

            seen_keys.add(key)

            # Get the base revision for this group
            revision = revision_map[key]

            # Create annotation with calculated revision
            annotation = request.to_annotation(revision=revision)
            annotations.append(annotation)
            # Use model_dump_json() for clean hashable mapping
            request_to_annotation_map[annotation.model_dump_json()] = request

        # Group by entity type for bulk change detection
        file_annotations = [ann for ann in annotations if ann.file_id is not None]
        song_annotations = [ann for ann in annotations if ann.song_id is not None]

        # Prepare file annotations
        file_request_lookup = {
            ann.model_dump_json(): request_to_annotation_map[ann.model_dump_json()] for ann in file_annotations
        }
        file_annotations_to_insert, file_skipped_requests = self._prepare_annotations_with_change_detection(
            file_annotations,
            file_request_lookup,
            conn,
            options=options,
        )

        # Prepare song annotations
        song_request_lookup = {
            ann.model_dump_json(): request_to_annotation_map[ann.model_dump_json()] for ann in song_annotations
        }
        song_annotations_to_insert, song_skipped_requests = self._prepare_annotations_with_change_detection(
            song_annotations,
            song_request_lookup,
            conn,
            options=options,
        )

        # Combine all annotations to insert
        annotations_to_insert = file_annotations_to_insert + song_annotations_to_insert

        # Create batch if provided and annotations will be inserted
        if annotations_to_insert and batch:
            was_inserted = self.repos.batch.insert_batch_atomic(conn, batch)
            if was_inserted:
                logger.info(f"Created batch {batch.id}")
            else:
                logger.debug(f"Batch {batch.id} already exists, reusing it")

        # Bulk insert only the changed annotations
        if annotations_to_insert:
            self.repos.annotation.insert_annotations_bulk(conn, annotations_to_insert)
            logger.info(f"Bulk inserted {len(annotations_to_insert)} annotations")

        # Combine validation skipped requests with change detection skipped requests
        all_skipped_requests = validation_skipped + file_skipped_requests + song_skipped_requests

        return {
            "inserted": annotations_to_insert,
            "skipped": all_skipped_requests,
            "failed": [],  # No failed cases in current implementation (all failures are skips)
        }
