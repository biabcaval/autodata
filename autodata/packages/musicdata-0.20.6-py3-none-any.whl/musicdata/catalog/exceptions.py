"""Domain exceptions for the musicdata catalog system."""


class CatalogError(Exception):
    """Base exception for catalog-related errors."""


# Business Rule Violations
class UnintendedValueChangeError(CatalogError):
    """Raised when an annotation value changes unexpectedly."""


class StandardDowngradeError(CatalogError):
    """Raised when attempting to downgrade an annotation standard (e.g., GOLD -> SILVER)."""


class NothingToUpdateError(CatalogError):
    """Raised when an update operation has nothing to update."""


# Validation Errors
class ValidationError(CatalogError):
    """Raised when validation fails."""


class UnknownStemError(CatalogError):
    """Raised when a stem name is not found in the catalog."""


# Configuration Errors
class ConfigurationError(CatalogError):
    """Raised when configuration is invalid."""


# Processing Errors
class SongProcessingError(CatalogError):
    """Error during song creation/update processing."""


class BlobOperationError(CatalogError):
    """Error during blob copy/precompute operations."""


class PrecheckError(CatalogError):
    """Error during precheck validation."""


class AnnotationError(CatalogError):
    """Error during annotation creation."""


def resolve_failure_type(e: Exception) -> str:
    """Resolve exception to a failure type string for monitoring."""
    if isinstance(e, BlobOperationError):
        return "blob_operation"
    if isinstance(e, PrecheckError):
        return "precheck"
    if isinstance(e, AnnotationError):
        return "annotation_error"
    if isinstance(e, SongProcessingError):
        return "song_processing"
    if isinstance(e, CatalogError):
        return "catalog_error"
    return "unknown"
