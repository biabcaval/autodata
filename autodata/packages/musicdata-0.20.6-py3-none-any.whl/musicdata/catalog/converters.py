"""Catalog helper utilities.

This module provides helpers that are intentionally decoupled from the ETL flow.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import orjson
import pandas as pd

from musicdata.annotations import KindRegistry

if TYPE_CHECKING:  # Avoid runtime import cycles
    from musicdata.db.models.requests import BulkSongCreationRequest


def bulk_song_creation_request_to_dataframe(request: BulkSongCreationRequest) -> pd.DataFrame:
    """
    Convert a BulkSongCreationRequest into a pandas DataFrame.

    The resulting DataFrame contains the required columns:
    - dataset
    - song_id
    - file_id
    - path

    Plus one column per kind name resolved from each request's kind_id using
    KindRegistry.get_kind_by_id(kind_id).kind.value.

    Notes:
    - File-level annotations are added to the corresponding file rows.
    - Song-level annotations (if any) are represented in their own row per song,
      where "file_id" and "path" are empty (None).
    - Annotation values are emitted as JSON strings (serialized via orjson.dumps).

    Args:
        request: The bulk song creation request to transform.

    Returns:
        A pandas DataFrame with one row per file and dynamic columns per
        annotation kind.
    """
    rows: list[dict[str, Any]] = []
    all_kind_names: set[str] = set()

    def _to_json_string(value: object) -> str | None:
        if value is None:
            return None
        if isinstance(value, str):
            return value
        return orjson.dumps(value, option=orjson.OPT_SORT_KEYS).decode()

    for song in request.songs:
        # Create one row for song-level annotations (if any)
        song_level_annotations: dict[str, Any] = {}
        for ann in getattr(song, "annotations", []) or []:
            kind = KindRegistry.get_kind_by_id(ann.kind_id)
            kind_name = kind.kind.value
            song_level_annotations[kind_name] = _to_json_string(ann.annotation_value)
            all_kind_names.add(kind_name)

        if song_level_annotations:
            song_row: dict[str, Any] = {
                "dataset": song.dataset,
                "song_id": str(song.id),
                "file_id": None,
                "path": None,
            }
            song_row.update(song_level_annotations)
            rows.append(song_row)

        # Create one row per file for file-level annotations
        for file in song.files:
            row: dict[str, Any] = {
                "dataset": song.dataset,
                "song_id": str(song.id),
                "file_id": str(file.id),
                "path": file.path,
            }

            # Add file-level annotations
            for ann in getattr(file, "annotations", []) or []:
                kind = KindRegistry.get_kind_by_id(ann.kind_id)
                kind_name = kind.kind.value
                row[kind_name] = _to_json_string(ann.annotation_value)
                all_kind_names.add(kind_name)

            rows.append(row)

    # Construct DataFrame with stable column order: required + sorted kinds
    required_cols = ["dataset", "song_id", "file_id", "path"]
    annotation_cols = sorted(all_kind_names)
    columns = required_cols + annotation_cols

    # Build DataFrame and ensure required/annotation columns exist and order is preserved
    df = pd.DataFrame(rows)
    for col in columns:
        if col not in df.columns:
            df[col] = None
    # Use reindex to guarantee DataFrame return type and column order
    return df.reindex(columns=columns)
