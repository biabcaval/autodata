"""Infrastructure exceptions for database and external service operations."""


class DatabaseError(Exception):
    """Raised when database operations fail."""


class AnnotationNotFoundError(DatabaseError):
    """Raised when a requested annotation is not found."""


class BigQueryError(Exception):
    """Raised when BigQuery operations fail."""
