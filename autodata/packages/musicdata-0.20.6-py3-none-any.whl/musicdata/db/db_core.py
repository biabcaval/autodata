from __future__ import annotations

import csv
import os
from typing import TYPE_CHECKING, Any, Generic, TypeVar
from uuid import UUID, uuid4

from loguru import logger
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import (
    Connection,
    CursorResult,
    Engine,
    MetaData,
    Table,
    Update,
    create_engine,
    text,
    update,
)

if TYPE_CHECKING:
    from sqlalchemy.engine import Connectable


T = TypeVar("T")
V = TypeVar("V")
KFP_RUN_ID = os.getenv("KFP_RUN_ID")


class DatabaseError(Exception):
    """Generic error class."""


class ArgumentError(DatabaseError):
    """Raised when an invalid or conflicting function argument is supplied."""


class TrackAlreadyLoadedError(Exception):
    "Raised when a track is already in the database."


class CurationTables:
    def __init__(self, metadata: MetaData) -> None:
        self.files_metadata = metadata.tables["public.files_metadata"]
        self.genre_types = metadata.tables["public.genre_types"]
        self.stem_taxonomy = metadata.tables["public.stem_taxonomy"]
        self.stem_types = metadata.tables["public.stem_types"]
        self.stem_types_to_taxonomy = metadata.tables["public.stem_types_to_taxonomy"]
        self.tag = metadata.tables["public.tag"]
        self.track = metadata.tables["public.track"]
        self.track_files = metadata.tables["public.track_files"]


class CurationViews:
    def __init__(self, metadata: MetaData) -> None:
        pass


class DataScienceTables:
    def __init__(self, metadata: MetaData) -> None:
        self.ai_covers = metadata.tables["public.ai_covers"]
        self.ai_voice_segments = metadata.tables["public.ai_voice_segments"]
        self.aligned_lyrics = metadata.tables["public.aligned_lyrics"]
        self.jam_tracks = metadata.tables["jamendo.tracks"]
        self.kv_pairs = metadata.tables["public.kv_pairs"]
        self.lf_lrc = metadata.tables["lyricfind.lrc"]
        self.lf_lyrics = metadata.tables["lyricfind.lyrics"]
        self.lf_lyrics_realigned = metadata.tables["lyricfind.lyrics_realigned"]
        self.lf_lyrics_tags = metadata.tables["lyricfind.lyrics_tags"]
        self.lf_tags = metadata.tables["lyricfind.tags"]
        self.lf_track_files = metadata.tables["lyricfind.track_files"]
        self.lf_track_files_altvc = metadata.tables["lyricfind.track_files_altvc"]
        self.lf_tracks_subset = metadata.tables["lyricfind.tracks_subset"]
        self.poems = metadata.tables["poetizer.poems"]
        self.user_edited_lyrics = metadata.tables["public.user_edited_lyrics"]
        self.user_edited_sections = metadata.tables["public.user_edited_sections"]
        self.voc_artists = metadata.tables["vocals.artists"]
        self.voc_files = metadata.tables["vocals.files"]
        self.voc_musics = metadata.tables["vocals.musics"]
        self.voc_phrases = metadata.tables["vocals.phrases"]
        self.voc_recordings = metadata.tables["vocals.recordings"]


class DataScienceViews:
    def __init__(self, metadata: MetaData) -> None:
        pass


class CatalogTables:
    def __init__(self, metadata: MetaData) -> None:
        self.annotation_batches = metadata.tables["public.annotation_batches"]
        self.annotation_kinds = metadata.tables["public.annotation_kinds"]
        self.annotations = metadata.tables["public.annotations"]
        self.files = metadata.tables["public.files"]
        self.songs = metadata.tables["public.songs"]


class CatalogViews:
    def __init__(self, metadata: MetaData) -> None:
        self.annotations_with_name = metadata.tables["public.annotations_with_name"]
        self.latest_annotations_with_name = metadata.tables["public.latest_annotations_with_name"]


class BaseDatabase(Generic[T, V]):
    def __init__(
        self,
        tables_class: type[T],
        env_var: str,
        schemas: list[str],
        views_class: type[V],
        url: str | None = None,
        **kwargs,
    ) -> None:
        self.engine = create_engine(url or os.environ[env_var], **kwargs)
        self.metadata = _get_reflected_metadata(self.engine, schemas)
        self.tables: T = tables_class(self.metadata)  # type: ignore[call-arg]
        self.t = self.tables  # Alias for convenience

        # Initialize views
        self.views: V = views_class(self.metadata)  # type: ignore[call-arg]
        self.v = self.views  # Alias for convenience


class CurationDatabase(BaseDatabase[CurationTables, CurationViews]):
    """
    Example:

        ```python
        # Creating a database instance with custom pool size
        db = CurationDatabase(pool_size=10)
        ```
    """

    def __init__(self, url: str | None = None, **kwargs) -> None:
        super().__init__(
            tables_class=CurationTables,
            env_var="CURATION_DB_URL",
            schemas=["public"],
            views_class=CurationViews,
            url=url,
            **kwargs,
        )


class DataScienceDatabase(BaseDatabase[DataScienceTables, DataScienceViews]):
    """
    Example:

        ```python
        # Creating a database instance with custom pool size
        db = DataScienceDatabase(pool_size=10)
        ```
    """

    def __init__(self, url: str | None = None, **kwargs) -> None:
        super().__init__(
            tables_class=DataScienceTables,
            env_var="POSTGRES_URL",
            schemas=["public", "lyricfind", "poetizer", "vocals", "jamendo"],
            views_class=DataScienceViews,
            url=url,
            **kwargs,
        )


class CatalogDatabase(BaseDatabase[CatalogTables, CatalogViews]):
    """
    Example:

        ```python
        # Creating a database instance with custom pool size
        db = CatalogDatabase(pool_size=10)
        ```
    """

    def __init__(self, url: str | None = None, **kwargs) -> None:
        super().__init__(
            tables_class=CatalogTables,
            env_var="CATALOG_DB_URL",
            schemas=["public"],
            views_class=CatalogViews,
            url=url,
            **kwargs,
        )


class KeyStore:
    def __init__(self, db: DataScienceDatabase) -> None:
        self.engine = db.engine
        self.kv_table = db.tables.kv_pairs

    def get(self, key: str) -> str:
        """Get the value of the key from the kv-store. Raises `ArgumentError` if the
        key is not found."""
        stmt = self.kv_table.select().where(self.kv_table.c.key == key)
        result = execute_statement(self.engine, stmt).first()
        if result is None:
            msg = f"Key '{key}' not found in the key-value store"
            raise ArgumentError(msg)
        return result.value

    def set(self, key: str, value: str | None) -> None:
        """Sets the key-value pair in the kv-store. Updates the value if the key
        already exists, otherwise inserts it.
        """
        if self.get(key) is None:
            self._insert(key, value)
        else:
            self._update(key, value)

    def _insert(self, key: str, value: str | None) -> None:
        """Inserts a key-value pair into the kv-store."""
        insert_rows(self.engine, self.kv_table, [{"key": key, "value": value}])

    def _update(self, key: str, value: str | None) -> None:
        """Updates values or just clears it if no `value` was used."""
        old_value = self.get(key)
        logger.info(
            "Old value for key '{}' is '{}', new value is '{}'",
            key,
            old_value,
            value,
        )
        stmt = update(self.kv_table).where(self.kv_table.c.key == key).values(value=value)
        _update_row(self.engine, stmt)


class BaseTrackModel(BaseModel):
    """Base model that handles None exclusion and provides common array field validation."""

    def model_dump(self, **kwargs) -> dict[str, Any]:
        """Dump model excluding None values by default."""
        kwargs["exclude_none"] = True
        return super().model_dump(**kwargs)

    @classmethod
    def validate_optional_array_field(cls, value: Any) -> Any:  # noqa: ANN401
        """Helper method for validating optional array fields."""
        if value is None:
            value = []
        return value


class Track(BaseTrackModel):
    curator_user: str | None = Field(default=None)
    tags: list[UUID] | None = Field(default=[])
    id: UUID
    genre_types_ids: list[UUID] | None = Field(default=[])
    dataset: str
    shortest_duration: int | None = None
    bpm: int | None = None
    additional_data: dict | None = None

    @field_validator("tags", "genre_types_ids", mode="before")
    @classmethod
    def _validate_array_fields(cls, value: Any) -> Any:  # noqa: ANN401
        return cls.validate_optional_array_field(value)


class TrackFile(BaseTrackModel):
    path: str
    id: UUID
    track_id: UUID
    stem_types_ids: list[UUID] | None = Field(default=[])
    stem_taxonomy_ids: list[UUID] | None = Field(default=[])
    highres_md5_hash: str | None = None
    highres_path: str | None = None
    is_lossless: bool | None = None
    lowres_md5_hash: str | None = None
    tags: list[UUID] | None = Field(default=[])

    @field_validator("tags", "stem_types_ids", "stem_taxonomy_ids", mode="before")
    @classmethod
    def _validate_array_fields(cls, value: Any) -> Any:  # noqa: ANN401
        return cls.validate_optional_array_field(value)


class CatalogTagHelper:
    """Helper class to get and insert genre types, tags, and stem types
    into the Curation Catalog database.
    """

    _VALID_TABLE_NAMES = frozenset(["tag", "stem_types", "genre_types", "stem_taxonomy"])

    def __init__(self, table_name: str, db: CurationDatabase) -> None:
        if table_name not in self._VALID_TABLE_NAMES:
            msg = f"Invalid table name: '{table_name}'. Valid options are: {', '.join(self._VALID_TABLE_NAMES)}"
            raise ValueError(msg)

        self._db = db
        self._table = getattr(db.t, table_name)
        self._cache: dict[tuple[str, UUID | None], UUID] = {}

    @staticmethod
    def normalize_name(name: str) -> str:
        return name.replace(" ", "_").replace("-", "_").replace(".", "").lower()

    def get_id(
        self,
        name: str,
        parent_id: UUID | None = None,
        *,
        normalize: bool = False,
    ) -> UUID:
        """Get the ID for a catalog entity (tag/stem/genre) by name.

        Args:
            name: The name of the entity to look up
            parent_id: Optional parent ID to filter by
            normalize: If True, normalize the name before querying

        Returns:
            UUID: The ID of the matching entity

        Raises:
            DatabaseError: If no matching entity is found
        """
        # Check cache first
        cache_key = (name, parent_id)
        if cache_key in self._cache:
            return self._cache[cache_key]

        if normalize:
            name = self.normalize_name(name)

        stmt = self._table.select().where(
            self._table.c.name == name,
        )
        if parent_id:
            stmt = stmt.where(self._table.c.parent_id == parent_id)

        result = execute_statement(self._db.engine, stmt)
        row = result.first()

        if not row:
            entity_type = self._table.name.replace("_", " ")
            msg = f"No {entity_type} found with name '{name}'"
            if parent_id:
                msg += f" and parent_id '{parent_id}'"
            raise DatabaseError(msg)

        try:
            tag_id = row._asdict()["id"]
        except (AttributeError, KeyError) as e:
            msg = f"Unexpected row structure when getting {self._table.name} ID: {e}"
            raise DatabaseError(msg) from e

        self._cache[cache_key] = tag_id
        return tag_id

    def insert(self, name: str, parent_id: UUID | None, *, normalize: bool = False) -> UUID:
        """Insert tag into database. If inserting a root tag, `parent_id` should
        be None.
        """
        if normalize:
            name = self.normalize_name(name)
        tag_id = uuid4()
        data = {
            "name": name,
            "id": tag_id,
            "parent_id": parent_id,
        }
        insert_rows(self._db.engine, self._table, data)
        self._cache[(name, parent_id)] = tag_id
        return tag_id

    def get_or_create(
        self,
        name: str,
        parent_id: UUID | None = None,
        *,
        normalize: bool = False,
    ) -> UUID:
        """Get or create tag in the database."""
        try:
            tag_id = self.get_id(name, parent_id, normalize=normalize)
        except DatabaseError:
            tag_id = self.insert(name, parent_id, normalize=normalize)
        return tag_id


class _StemHelper(CatalogTagHelper):
    """Internal helper class for stem type mapping functionality.
    This class is intended for internal use only and should not be used directly.
    Instead, use StemTypeHelper or StemTaxonomyHelper.
    """

    def __init__(self, db: CurationDatabase, table_name: str) -> None:
        super().__init__(table_name, db)
        self._mapping = self._generate_mapping()

    def _generate_mapping(self) -> dict:
        default_mapping = self._get_default_types()

        current_dir = os.path.dirname(os.path.abspath(__file__))
        csv_full_path = os.path.join(current_dir, "resources/stem_types_mapping.csv")
        custom_mapping = self._read_csv_as_dict(csv_full_path)

        custom_mapping.update(default_mapping)  # Default types override custom types
        return custom_mapping

    def _get_default_types(self) -> dict[str, str]:
        """Returns a dictionary of default stem types, where the key and the value
        are the same."""
        with self._db.engine.connect() as connection:
            result = connection.execute(self._db.t.stem_types.select())
            return {row.name: row.name for row in result}

    @staticmethod
    def _read_csv_as_dict(csv_file_path: str) -> dict[str, str]:
        with open(csv_file_path, encoding="utf-8") as infile:
            reader = csv.reader(infile)
            return {rows[0]: rows[1] for rows in reader}

    def get_mapping(self, name: str, *, normalize: bool = False) -> str:
        """Returns the curation catalog stem type name for the given data source
        stem name.
        """
        if normalize:
            name = self.normalize_name(name)
        try:
            return self._mapping[name]
        except KeyError:
            msg = f"Stem type '{name}' not found in mapping. Please add it to the stem_types_mapping.csv file."
            raise ValueError(msg) from None

    def extend_mapping(self, mapping: dict[str, str]) -> None:
        """Extends the stem type mapping with the provided dictionary.
        The provided dictionary should have the data source stem type name as the key
        and the curation catalog stem type name as the value.

            ```
            "source_stem_type": "catalog_stem_type"
            ```
        """
        self._mapping.update(mapping)


class StemMapperHelper:
    def __init__(self) -> None:
        self._mapping = self._generate_mapping()

    @staticmethod
    def normalize_name(name: str) -> str:
        return name.strip().replace(" ", "_").replace("-", "_").replace(".", "").lower()

    @staticmethod
    def _read_csv_as_dict(csv_file_path: str) -> dict[str, str]:
        with open(csv_file_path, encoding="utf-8") as infile:
            reader = csv.reader(infile)
            return {rows[0]: rows[1] for rows in reader}

    def _generate_mapping(self) -> dict:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        csv_full_path = os.path.join(current_dir, "../resources/stem_types_taxonomy_mapping.csv")
        return self._read_csv_as_dict(csv_full_path)

    def get_mapping(self, name: str, *, normalize: bool = False) -> str:
        """Returns the curation catalog stem type name for the given data source
        stem name.
        """
        if normalize:
            name = self.normalize_name(name)
        try:
            return self._mapping[name]
        except KeyError:
            msg = f"Stem type '{name}' not found in mapping. Please add it to the stem_types_taxonomy_mapping.csv file."
            raise ValueError(msg) from None

    def extend_mapping(self, mapping: dict[str, str]) -> None:
        """Extends the stem type mapping with the provided dictionary.
        The provided dictionary should have the data source stem type name as the key
        and the curation catalog stem type name as the value.

            ```
            "source_stem_type": "catalog_stem_type"
            ```
        """
        self._mapping.update(mapping)


class StemTypeHelper(_StemHelper):
    def __init__(self, db: CurationDatabase) -> None:
        super().__init__(db, "stem_types")


class StemTaxonomyHelper(_StemHelper):
    def __init__(self, db: CurationDatabase) -> None:
        super().__init__(db, "stem_taxonomy")


def _is_list_of_dicts(obj: list[dict]) -> bool:
    return isinstance(obj, list) and all(isinstance(item, dict) for item in obj)


def execute_statement(
    connectable: Connectable,
    *exec_args,
) -> CursorResult:
    """Executes a SQLAlchemy statement. When `connectable` type is `Engine`,
    a new transaction is created. When `connectable` type is `Connection`,
    then it is assumed that there is a parent transaction, therefore only
    `execute` is called and commits or rollbacks should be managed by the caller.

    If using as part of a transaction, it is usually desirable to use
    `Connection` instead of `Engine`.
    """
    if isinstance(connectable, Engine):
        with connectable.begin() as conn:
            return conn.execute(*exec_args)
    elif isinstance(connectable, Connection):
        return connectable.execute(*exec_args)
    else:
        msg = "Connectable should be of type Engine or Connection"
        raise ArgumentError(msg)


def _get_reflected_metadata(engine: Engine, schemas: list[str]) -> MetaData:
    metadata = MetaData()
    for schema in schemas:
        metadata.reflect(engine, schema=schema, views=True)
    return metadata


def drop_table(name: str, schema: str, engine: Engine) -> None:
    logger.info("Removing table '{}.{}', if it exists", schema, name)
    with engine.begin() as conn:
        conn.execute(text(f"DROP TABLE IF EXISTS {schema}.{name};"))


def insert_rows(
    connectable: Connectable,
    table: Table,
    data: dict[str, Any] | list[dict[str, Any]],
) -> CursorResult[Any]:
    """Inserts rows into the table. Adds `kfp_run_id` to the data.

    Commits only when `connectable` type is `Engine`. When using `Connection` the
    caller is responsible for managing transactions.
    """
    if not isinstance(data, list):
        data = [data]
    if not _is_list_of_dicts(data):
        msg = "Expected data to be of type list[dict]"
        raise ArgumentError(msg)
    for row in data:
        row["kfp_run_id"] = KFP_RUN_ID
    return execute_statement(connectable, table.insert(), data)


def _update_row(connectable: Connectable, stmt: Update) -> CursorResult:
    """Updates rows in the table. Adds `kfp_run_id` to the data.

    Commits only when `connectable` type is `Engine`. When using `Connection` the
    caller is responsible for managing transactions.
    """
    if not isinstance(stmt, Update):
        msg = "Expected stmt to be of type Update"
        raise ArgumentError(msg)
    stmt = stmt.values(kfp_run_id=KFP_RUN_ID)
    return execute_statement(connectable, stmt)


def is_track_loaded(db: CurationDatabase, conn: Connection, track_id: UUID) -> bool:
    stmt = db.t.track.select().where(db.t.track.c.id == track_id)
    result = conn.execute(stmt)
    return result.first() is not None
