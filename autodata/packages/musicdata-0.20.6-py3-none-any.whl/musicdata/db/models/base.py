"""Database models for data validation using Pydantic."""

from datetime import UTC, datetime
from enum import Enum
from typing import Annotated, Any, LiteralString, NamedTuple, TypeVar
from uuid import UUID

from pydantic import BaseModel, BeforeValidator, ConfigDict, Field, StrictStr, model_validator
from pydantic.types import Json
from pydantic_core import PydanticCustomError


class ErrorDetail(NamedTuple):
    """A generic error payload that holds an error code and message to be used by `PydanticCustomError`."""

    code: LiteralString
    message: LiteralString


class ErrorMessages:
    """Error messages and codes used across the models."""

    EMPTY_JSON = ErrorDetail("empty_json", "JSON value cannot be empty")
    EMPTY_STRING = ErrorDetail("empty_string", "String cannot be empty or contain only whitespace")
    EMPTY_SET = ErrorDetail("empty_set", "Set must not be empty")
    DUPLICATE_ITEMS = ErrorDetail("duplicate_items", "List contains duplicate items {duplicate_str}")


ItemT = TypeVar("ItemT")  # For list items
KeyT = TypeVar("KeyT")  # For dictionary keys
ValueT = TypeVar("ValueT")  # For dictionary values

# Constants
MAX_DUPLICATES_TO_SHOW = 3


# Helper functions and validators
def _validate_non_empty_string(v: str) -> str:
    """Validate that a string is not empty and not just whitespace."""
    if not v or v.isspace():
        error = ErrorMessages.EMPTY_STRING
        raise PydanticCustomError(error.code, error.message)
    return v


def _validate_non_empty_json(v: dict | list) -> dict | list:
    """Validate that a JSON value (dict or list) is not empty."""
    if v in ({}, []):
        error = ErrorMessages.EMPTY_JSON
        raise PydanticCustomError(error.code, error.message)
    return v


def _validate_non_empty_list(v: list[Any]) -> list[Any]:
    """Validate that a list is not empty."""
    if not v:
        raise PydanticCustomError(ErrorMessages.EMPTY_SET.code, ErrorMessages.EMPTY_SET.message)
    return v


def _validate_non_empty_dict(v: dict[Any, Any]) -> dict[Any, Any]:
    """Validate that a dictionary is not empty."""
    if not v:
        error = ErrorMessages.EMPTY_JSON
        raise PydanticCustomError(error.code, error.message)
    return v


def _validate_unique_items(v: list[Any]) -> list[Any]:
    """Validate that a list contains no duplicate items (assumes list is already non-empty)."""
    seen = set()
    duplicates = []

    for item in v:
        if item in seen:
            duplicates.append(item)
        else:
            seen.add(item)

    if duplicates:
        # If we found duplicates, raise a custom error
        duplicate_str = ", ".join(str(d) for d in duplicates[:MAX_DUPLICATES_TO_SHOW])
        if len(duplicates) > MAX_DUPLICATES_TO_SHOW:
            duplicate_str += f", and {len(duplicates) - MAX_DUPLICATES_TO_SHOW} more"

        # Use the error message directly instead of formatting it
        error = ErrorMessages.DUPLICATE_ITEMS
        raise PydanticCustomError(error.code, error.message, {"duplicate_str": duplicate_str})

    return v


def enforce_unique_items(v: list[Any]) -> list[Any]:
    """Remove duplicate items from a list, preserving the order of first occurrence."""
    seen = set()
    unique_items = []

    for item in v:
        if item not in seen:
            seen.add(item)
            unique_items.append(item)

    return unique_items


# Common configuration and types
MODEL_CONFIG = ConfigDict(from_attributes=True, validate_assignment=True)

# Flexible JSON type that accepts both JSON strings and already-parsed dict/list objects
# Uses pydantic.Json for string parsing and direct validation for objects
NonEmptyJson = Annotated[
    Json[dict | list] | dict | list,  # Union: JSON strings OR direct objects
    BeforeValidator(_validate_non_empty_json),  # Ensure non-empty after parsing
]
UtcDateTime = datetime  # Type alias for datetime fields with UTC timezone
PositiveInt = Annotated[int, Field(strict=True, gt=0)]
NonEmptyString = Annotated[StrictStr, BeforeValidator(_validate_non_empty_string)]
NonEmptyUUIDs = Annotated[
    list[UUID], BeforeValidator(_validate_non_empty_list), BeforeValidator(_validate_unique_items)
]
# Generic composable list validators using TypeVar
# Usage: NonEmptyList[MyType], UniqueList[MyType], UniqueNonEmptyList[MyType]
NonEmptyList = Annotated[list[ItemT], BeforeValidator(_validate_non_empty_list)]
UniqueList = Annotated[list[ItemT], BeforeValidator(_validate_unique_items)]
UniqueNonEmptyList = Annotated[
    list[ItemT], BeforeValidator(_validate_non_empty_list), BeforeValidator(_validate_unique_items)
]
# Generic dictionary validator for non-empty dictionaries
NonEmptyDict = Annotated[dict[KeyT, ValueT], BeforeValidator(_validate_non_empty_dict)]

# For optional collections, just use list[T] | None or dict[K, V] | None directly!
# The EnhancedSerializationModel automatically cleans the JSON schema to remove null branches.


# Base model
class BaseModelWithNoneExclusion(BaseModel):
    """Base model that handles None exclusion and auto-populates timestamps."""

    model_config = MODEL_CONFIG

    @model_validator(mode="before")
    @classmethod
    def _fill_timestamps(cls, data: Any) -> Any:  # noqa: ANN401
        """Auto-fill created_at and updated_at with current UTC time if None or missing."""
        if isinstance(data, dict):
            now = datetime.now(UTC)
            if data.get("created_at") is None:
                data["created_at"] = now
            if data.get("updated_at") is None:
                data["updated_at"] = now
        return data

    def model_dump(self, **kwargs) -> dict[str, Any]:
        """Dump model excluding None values by default."""
        if "exclude_none" not in kwargs:
            kwargs["exclude_none"] = True
        return super().model_dump(**kwargs)


# Shared enums and models
class AnnotationKindType(str, Enum):
    """Valid annotation kinds."""

    ADDITIONAL_DATA = "additional_data"
    BEAT = "beat"
    CHORD = "chord"
    ERA = "era"
    FILE_DATA = "file_data"
    GENRE = "genre"
    GUITAR_CHORD = "guitar_chord"
    KEY = "key"
    MEDIA_METADATA = "media_metadata"
    METER = "meter"
    MOOD = "mood"
    POST_PRODUCTION = "post_production"
    PREDICTED_OFFSET = "predicted_offset"
    PREDICTED_SEGMENT = "predicted_segment"
    PREDICTED_STEM_TYPES = "predicted_stem_types"
    PREDICTED_TRANSCRIPTION = "predicted_transcription"
    PRODUCTION = "production"
    SEGMENT = "segment"
    STEM_TYPES = "stem_types"
    TAG_SCORE = "tag_score"
    TEMPO = "tempo"
    TRANSCRIPTION = "transcription"


# Annotation kind classification for file updates
# Whitelist of annotation kinds that can be safely handled during file updates.
# Any annotation kind NOT in this list will block file updates (fail-safe approach).
#
# Safe file update annotation kinds:
# - FILE_DATA: Will be recomputed with new file metadata
# Other annotation kinds will be preserved.
SAFE_FILE_UPDATE_ANNOTATION_KINDS: frozenset[AnnotationKindType] = frozenset(
    [
        AnnotationKindType.ADDITIONAL_DATA,
        AnnotationKindType.ERA,
        AnnotationKindType.FILE_DATA,
        AnnotationKindType.GENRE,
        AnnotationKindType.MEDIA_METADATA,
        AnnotationKindType.MOOD,
        AnnotationKindType.POST_PRODUCTION,
        AnnotationKindType.PREDICTED_STEM_TYPES,
        AnnotationKindType.PRODUCTION,
        AnnotationKindType.STEM_TYPES,
        AnnotationKindType.TAG_SCORE,
    ]
)


class AnnotationKind(BaseModelWithNoneExclusion):
    """Annotation kind model representing entries in the annotation_kinds table."""

    id: UUID
    kind: AnnotationKindType
    revision: PositiveInt
    json_schema: NonEmptyJson
    constraints: NonEmptyJson | None = None
    active: bool = True
    created_at: UtcDateTime | None = None
    updated_at: UtcDateTime | None = None
