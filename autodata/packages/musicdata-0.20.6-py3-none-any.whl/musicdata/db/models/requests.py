"""Request models for annotation operations."""

from typing import Any
from uuid import UUID

from pydantic import Field, model_validator

from musicdata.db.models.base import BaseModelWithNoneExclusion
from musicdata.db.models.models import (
    Annotation,
    AnnotationBatch,
    AnnotationSource,
    BaseAnnotationData,
    File,
    FileCreationMethod,
    NonEmptyJson,
    Song,
    Standard,
    Visibility,
)


class AnnotationRequest(BaseModelWithNoneExclusion, BaseAnnotationData):
    """
    Request model for creating annotations with automatic revision handling.

    This model mirrors the structure of the Annotation model but is optimized
    for creation requests where revision and timestamps are handled automatically.
    """

    def to_annotation(self, *, revision: int) -> "Annotation":
        """
        Convert request to full Annotation model with calculated revision.

        Args:
            revision: The calculated revision number

        Returns:
            Annotation: Full annotation model ready for database insertion
        """
        return Annotation(
            song_id=self.song_id,
            file_id=self.file_id,
            kind_id=self.kind_id,
            annotation_value=self.annotation_value,
            standard=self.standard,
            annotation_source=self.annotation_source,
            revision=revision,
            batch_id=self.batch_id,
            migrated=self.migrated,
        )

    @property
    def is_song_annotation(self) -> bool:
        """Check if this is a song annotation."""
        return self.song_id is not None

    @property
    def is_file_annotation(self) -> bool:
        """Check if this is a file annotation."""
        return self.file_id is not None

    @classmethod
    def for_file(  # noqa: PLR0913
        cls,
        file_id: UUID,
        kind_id: UUID,
        annotation_value: NonEmptyJson,
        standard: Standard,
        annotation_source: AnnotationSource,
        batch_id: UUID,
        *,
        migrated: bool = False,
    ) -> "AnnotationRequest":
        """
        Convenience factory method for file annotations.

        Args:
            file_id: The file ID
            kind_id: The annotation kind ID
            annotation_value: The annotation data
            standard: The annotation standard
            annotation_source: The annotation source
            batch_id: The batch ID
            migrated: Whether this annotation was migrated

        Returns:
            AnnotationRequest: Request model for file annotation
        """
        return cls(
            file_id=file_id,
            kind_id=kind_id,
            annotation_value=annotation_value,
            standard=standard,
            annotation_source=annotation_source,
            batch_id=batch_id,
            migrated=migrated,
        )

    @classmethod
    def for_song(  # noqa: PLR0913
        cls,
        song_id: UUID,
        kind_id: UUID,
        annotation_value: NonEmptyJson,
        standard: Standard,
        annotation_source: AnnotationSource,
        batch_id: UUID,
        *,
        migrated: bool = False,
    ) -> "AnnotationRequest":
        """
        Convenience factory method for song annotations.

        Args:
            song_id: The song ID
            kind_id: The annotation kind ID
            annotation_value: The annotation data
            standard: The annotation standard
            annotation_source: The annotation source
            batch_id: The batch ID
            migrated: Whether this annotation was migrated

        Returns:
            AnnotationRequest: Request model for song annotation
        """
        return cls(
            song_id=song_id,
            kind_id=kind_id,
            annotation_value=annotation_value,
            standard=standard,
            annotation_source=annotation_source,
            batch_id=batch_id,
            migrated=migrated,
        )


class SongReferenceValidator:
    """Validation logic for song references."""

    @classmethod
    def validate_references(cls, data: dict[str, Any]) -> dict[str, Any]:
        """Validate that all nested files and annotations have correct parent references."""
        if not isinstance(data, dict) or "id" not in data:
            return data

        song_id = data["id"]

        # Validate files reference this song correctly
        if "files" in data:
            files = data.get("files", [])
            for file_data in files:
                if isinstance(file_data, dict):
                    cls._validate_file_song_id(file_data, song_id)

        # Validate direct song annotations reference this song correctly
        if "annotations" in data:
            annotations = data.get("annotations", [])
            for annotation_data in annotations:
                if isinstance(annotation_data, dict):
                    cls._validate_annotation_song_id(annotation_data, song_id)

        return data

    @staticmethod
    def _validate_file_song_id(file_data: dict[str, Any], expected_song_id: UUID) -> None:
        """Validate that file has correct song_id - all references must be explicit."""
        current_song_id = file_data.get("song_id")

        if current_song_id is None:
            msg = f"File song_id is required but not provided (expected: {expected_song_id})"
            raise ValueError(msg)

        if str(current_song_id) != str(expected_song_id):
            msg = f"File song_id {current_song_id} doesn't match Song request id {expected_song_id}"
            raise ValueError(msg)

    @staticmethod
    def _validate_annotation_song_id(annotation_data: dict[str, Any], expected_song_id: UUID) -> None:
        """Validate that annotation has correct song_id - all references must be explicit."""
        current_song_id = annotation_data.get("song_id")

        if current_song_id is None:
            msg = f"Annotation song_id is required but not provided (expected: {expected_song_id})"
            raise ValueError(msg)

        if str(current_song_id) != str(expected_song_id):
            msg = f"Annotation song_id {current_song_id} doesn't match Song request id {expected_song_id}"
            raise ValueError(msg)


class SongRequest(BaseModelWithNoneExclusion):
    """Request to create/upsert a song with its files and annotations."""

    # Song data
    id: UUID
    dataset: str
    visibility: Visibility = Visibility.PRIVATE
    deleted: bool = False

    # Related files (optional)
    files: list["FileRequest"] = Field(default_factory=list)

    # Direct song annotations (optional)
    annotations: list[AnnotationRequest] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def validate_nested_references(cls, data: dict[str, Any]) -> dict[str, Any]:
        """Validate that all nested files and annotations have correct parent references."""
        return SongReferenceValidator.validate_references(data)

    def to_song(self) -> Song:
        """Convert to Song model."""
        return Song(
            id=self.id,
            dataset=self.dataset,
            visibility=self.visibility,
            deleted=self.deleted,
            created_at=None,  # Will be set by database
            updated_at=None,  # Will be set by database
        )


class FileRequest(BaseModelWithNoneExclusion):
    """Request to create/upsert a file with its annotations, with optional blob copying."""

    # File data
    id: UUID
    song_id: UUID
    path: str  # Source blob URI for copying, or final path after copying
    md5_hash: str  # Empty string if needs to be computed after blob copying
    creation_method: FileCreationMethod | None = None
    deleted: bool = False
    is_problematic: bool = False

    # File annotations (optional)
    annotations: list[AnnotationRequest] = Field(default_factory=list)

    def to_file(self) -> File:
        """Convert to File model."""
        return File(
            id=self.id,
            song_id=self.song_id,
            path=self.path,
            md5_hash=self.md5_hash,
            creation_method=self.creation_method,
            deleted=self.deleted,
            is_problematic=self.is_problematic,
            created_at=None,  # Will be set by database
            updated_at=None,  # Will be set by database
        )

    @model_validator(mode="before")
    @classmethod
    def validate_annotation_file_ids(cls, data: dict[str, Any]) -> dict[str, Any]:
        """Validate that all nested annotations have the correct file_id."""
        if not isinstance(data, dict) or "annotations" not in data or "id" not in data:
            return data

        file_id = data["id"]
        annotations = data.get("annotations", [])

        # Validate each annotation in the list
        for annotation_data in annotations:
            if isinstance(annotation_data, dict):
                cls._validate_annotation_file_id(annotation_data, file_id)

        return data

    @classmethod
    def _validate_annotation_file_id(cls, annotation_data: dict[str, Any], expected_file_id: UUID) -> None:
        """Validate that annotation has correct file_id - all references must be explicit."""
        current_file_id = annotation_data.get("file_id")

        if current_file_id is None:
            msg = f"Annotation file_id is required but not provided (expected: {expected_file_id})"
            raise ValueError(msg)

        if current_file_id != expected_file_id:
            msg = f"Annotation file_id {current_file_id} doesn't match FileRequest id {expected_file_id}"
            raise ValueError(msg)


class BulkSongCreationRequest(BaseModelWithNoneExclusion):
    """Request for bulk creation of complete songs with their files and annotations."""

    songs: list[SongRequest] = Field(default_factory=list)
    batch: AnnotationBatch | None = None


class BulkFileCreationRequest(BaseModelWithNoneExclusion):
    """Request for bulk creation of files (assumes songs already exist)."""

    files: list[FileRequest] = Field(default_factory=list)
    batch: AnnotationBatch | None = None


class BulkAnnotationCreationRequest(BaseModelWithNoneExclusion):
    """Request for bulk creation of annotations (assumes files/songs already exist)."""

    annotations: list[AnnotationRequest] = Field(default_factory=list)
    batch: AnnotationBatch | None = None


class SongUpdateRequest(BaseModelWithNoneExclusion):
    """Request to update files for an existing song."""

    id: UUID
    files: list[FileRequest] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def validate_nested_references(cls, data: dict[str, Any]) -> dict[str, Any]:
        """Validate that all nested files have correct parent references."""
        return SongReferenceValidator.validate_references(data)


class BulkSongUpdateRequest(BaseModelWithNoneExclusion):
    """Request for bulk update of files across multiple songs."""

    songs: list[SongUpdateRequest] = Field(default_factory=list)
    batch: AnnotationBatch | None = None
