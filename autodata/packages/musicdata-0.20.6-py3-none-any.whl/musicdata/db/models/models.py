"""Database models for data validation using Pydantic."""

from enum import Enum
from typing import Annotated, Any, Self, TypeVar
from uuid import UUID

from pydantic import BaseModel, BeforeValidator, ValidationInfo, model_validator
from pydantic_core import PydanticCustomError

from musicdata.annotations.validators import KindRegistry
from musicdata.db.models.base import (
    BaseModelWithNoneExclusion,
    ErrorDetail,
    NonEmptyJson,
    NonEmptyString,
    PositiveInt,
    UtcDateTime,
)

T = TypeVar("T", bound="BaseAnnotationData")


class ErrorMessages:
    """Error messages and codes used across the models."""

    ENTITY_REFERENCE = ErrorDetail("missing_entity_reference", "Either song_id or file_id must be set")
    MULTIPLE_REFERENCES = ErrorDetail("multiple_entity_references", "Only one of song_id or file_id can be set")
    MISSING_KIND = ErrorDetail("missing_kind_id", "kind_id must be provided to validate annotation_value")
    INVALID_ANNOTATION = ErrorDetail("invalid_annotation", "annotation_value does not match schema: {error}")


class Standard(str, Enum):
    """Valid annotation standard types."""

    BRONZE = "bronze"
    SILVER = "silver"
    GOLD = "gold"


class AnnotationSource(str, Enum):
    """Valid annotation source types."""

    MUSICLAB = "musiclab"
    CURATION_PLATFORM = "curation_platform"
    PURCHASED = "purchased"
    PUBLIC = "public"
    EXTRACTED_METADATA = "extracted_metadata"
    INFERRED = "inferred"
    ML_PREDICTED = "ml_predicted"
    OTHER_SOURCES = "other_sources"
    UNKNOWN = "unknown"


class Visibility(str, Enum):
    """Valid visibility types."""

    PUBLIC = "public"
    PRIVATE = "private"


class FileCreationMethod(str, Enum):
    """Valid file creation method types."""

    GENERATED = "generated"
    MIXED = "mixed"
    SEPARATED = "separated"


def _validate_annotation_value(v: dict | list, info: ValidationInfo | dict[str, Any]) -> dict | list:
    """Validator exposed to Pydantic which delegates to the test-friendly internal function."""
    # Get the kind_id and ensure it exists
    data = getattr(info, "data", info)
    kind_id = data.get("kind_id") if isinstance(data, dict) else None
    if not kind_id:
        error = ErrorMessages.MISSING_KIND
        raise PydanticCustomError(error.code, error.message)

    try:
        KindRegistry.validate_value(value=v, kind_id=kind_id)
    except ValueError as e:
        error = ErrorMessages.INVALID_ANNOTATION
        raise PydanticCustomError(
            error.code,
            error.message,
            {"error": str(e)},
        ) from e

    return v


class BaseAnnotationData(BaseModel):
    """Base class for shared annotation data fields and validation logic."""

    # Entity reference fields
    song_id: UUID | None = None
    file_id: UUID | None = None

    # Annotation core data
    kind_id: UUID
    annotation_value: Annotated[NonEmptyJson, BeforeValidator(_validate_annotation_value)]
    standard: Standard
    annotation_source: AnnotationSource
    batch_id: UUID
    migrated: bool = False

    @model_validator(mode="after")
    def check_entity_reference(self) -> Self:
        """Validate that either song_id or file_id is set, but not both."""
        if self.song_id is None and self.file_id is None:
            error = ErrorMessages.ENTITY_REFERENCE
            raise PydanticCustomError(error.code, error.message)
        if self.song_id is not None and self.file_id is not None:
            error = ErrorMessages.MULTIPLE_REFERENCES
            raise PydanticCustomError(error.code, error.message)
        return self


class Song(BaseModelWithNoneExclusion):
    """Song model representing entries in the public.songs table."""

    id: UUID
    dataset: NonEmptyString
    deleted: bool = False
    created_at: UtcDateTime | None = None
    updated_at: UtcDateTime | None = None
    visibility: Visibility


class File(BaseModelWithNoneExclusion):
    """File model representing entries in the public.files table."""

    id: UUID
    song_id: UUID
    path: NonEmptyString
    md5_hash: NonEmptyString
    creation_method: FileCreationMethod | None = None
    deleted: bool = False
    created_at: UtcDateTime | None = None
    updated_at: UtcDateTime | None = None
    is_problematic: bool = False


class AnnotationBatch(BaseModelWithNoneExclusion):
    """Annotation batch model representing entries in the annotation_batches table."""

    id: UUID
    description: NonEmptyString | None = None
    created_at: UtcDateTime | None = None


class Annotation(BaseModelWithNoneExclusion, BaseAnnotationData):
    """Annotation model representing entries in the annotations table."""

    # Operational details (additional to base data)
    revision: PositiveInt = 1

    # Timestamps
    created_at: UtcDateTime | None = None
    updated_at: UtcDateTime | None = None
