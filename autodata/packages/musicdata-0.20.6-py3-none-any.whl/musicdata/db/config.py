"""Infrastructure configuration classes for database and external services."""

import os
from dataclasses import dataclass
from typing import Any


@dataclass
class DatabaseConfig:
    """Configuration for database connections."""

    url: str | None = None
    pool_size: int = 60  # The default pool size is 60, but it is "lazy" and creates connections on demand

    @classmethod
    def from_env(cls) -> "DatabaseConfig":
        """Create configuration from environment variables."""
        return cls(
            url=os.getenv("CATALOG_DB_URL"),
            pool_size=int(os.getenv("DB_POOL_SIZE", cls.pool_size)),
        )

    def to_sqlalchemy_kwargs(self) -> dict[str, Any]:
        """Convert to SQLAlchemy engine kwargs."""
        return {
            "pool_size": self.pool_size,
        }


@dataclass
class BigQueryConfig:
    """Configuration for BigQuery connections."""

    project_id: str | None = None
    credentials_path: str | None = None
    location: str | None = None

    @classmethod
    def from_env(cls) -> "BigQueryConfig":
        """Create configuration from environment variables."""
        return cls(
            project_id=os.getenv("GCP_PROJECT"),
            credentials_path=os.getenv("GOOGLE_APPLICATION_CREDENTIALS"),
            location=os.getenv("BQ_LOCATION"),
        )

    def to_bigquery_kwargs(self) -> dict[str, Any]:
        """Convert to BigQuery client kwargs."""
        kwargs = {"location": self.location}
        if self.project_id:
            kwargs["project"] = self.project_id
        # Note: We do not pass credentials_path here because the BigQuery client
        # expects a Credentials object, not a file path.
        # If GOOGLE_APPLICATION_CREDENTIALS is set (which is where credentials_path comes from),
        # the client will automatically pick it up via Application Default Credentials (ADC).
        return kwargs
