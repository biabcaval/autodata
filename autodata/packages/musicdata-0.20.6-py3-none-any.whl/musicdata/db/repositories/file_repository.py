"""Repository for File entity operations."""

from collections.abc import Collection
from typing import Any
from uuid import UUID

from loguru import logger
from sqlalchemy import Connection, bindparam, func, select, update

from musicdata.db import insert_rows
from musicdata.db.db_core import CatalogDatabase
from musicdata.db.exceptions import DatabaseError
from musicdata.db.models.models import File
from musicdata.db.repositories.base import BaseRepository


class FileRepository(BaseRepository):
    """Repository for File entity operations."""

    def __init__(self, db: CatalogDatabase) -> None:
        super().__init__(db)

    def insert_file_if_not_exists(self, conn: Connection, file: File) -> bool:
        """
        Insert a file if it doesn't already exist.

        Args:
            conn: Database connection
            file: File entity to insert

        Returns:
            True if file was inserted, False if it already existed
        """
        # Check if file already exists using SQLAlchemy core syntax
        stmt = select(self.t.files.c.id).where(self.t.files.c.id == file.id)
        result = self._safe_execute(conn, stmt)

        if result.fetchone():
            return False  # File already exists

        # Insert the file using insert_rows helper, excluding server-managed timestamps
        insert_rows(
            conn,
            self.t.files,
            file.model_dump(exclude={"created_at", "updated_at"}, exclude_none=False, mode="json"),
        )
        return True

    def insert_files_bulk(self, conn: Connection, files: list[File]) -> list[File]:
        """
        Bulk insert files that don't already exist.

        Args:
            conn: Database connection
            files: List of files to insert

        Returns:
            List of files actually inserted
        """
        if not files:
            return []

        # Get existing file IDs
        file_ids = [file.id for file in files]
        stmt = select(self.t.files.c.id).where(self.t.files.c.id.in_(file_ids))
        result = self._safe_execute(conn, stmt)
        existing_ids = {row[0] for row in result.fetchall()}

        # Filter out existing files
        files_to_insert = [file for file in files if file.id not in existing_ids]

        if not files_to_insert:
            return []

        # Bulk insert new files using insert_rows helper, excluding server-managed timestamps
        insert_data = [
            file.model_dump(exclude={"created_at", "updated_at"}, exclude_none=False, mode="json")
            for file in files_to_insert
        ]
        insert_rows(conn, self.t.files, insert_data)

        return files_to_insert

    def do_files_exist_bulk(self, file_ids: Collection[UUID], conn: Connection) -> dict[UUID, bool]:
        """
        Check which files exist in bulk.

        Args:
            file_ids: List of file IDs to check
            conn: Database connection

        Returns:
            Dictionary mapping file_id to existence boolean
        """
        if not file_ids:
            return {}

        stmt = select(self.t.files.c.id).where(self.t.files.c.id.in_(file_ids))
        result = self._safe_execute(conn, stmt)
        existing_ids = {row[0] for row in result.fetchall()}

        return {file_id: file_id in existing_ids for file_id in file_ids}

    def get_songs_by_file_ids_bulk(self, file_ids: Collection[UUID | str], conn: Connection) -> dict[UUID, UUID]:
        """
        Get song IDs for multiple file IDs in bulk.

        Args:
            file_ids: Collection of file IDs to get song IDs for (list, tuple, set, etc.)
            conn: Database connection

        Returns:
            Dictionary mapping file_id to song_id (only includes existing files)
        """
        if not file_ids:
            return {}

        stmt = select(self.t.files.c.id, self.t.files.c.song_id).where(self.t.files.c.id.in_(file_ids))
        result = self._safe_execute(conn, stmt)

        return {row[0]: row[1] for row in result.fetchall()}

    def get_files_by_song_ids_bulk(self, song_ids: Collection[UUID | str], conn: Connection) -> dict[UUID, list[UUID]]:
        """
        Get all file IDs for multiple songs in bulk.

        Args:
            song_ids: Collection of song IDs to get files for (list, tuple, set, etc.)
            conn: Database connection

        Returns:
            Dictionary mapping song_id to list of file_ids
        """
        if not song_ids:
            return {}

        stmt = select(self.t.files.c.song_id, self.t.files.c.id).where(self.t.files.c.song_id.in_(song_ids))
        result = self._safe_execute(conn, stmt)

        # Group file_ids by song_id
        song_files: dict[UUID, list[UUID]] = {}
        for row in result.fetchall():
            song_id, file_id = row[0], row[1]
            if song_id not in song_files:
                song_files[song_id] = []
            song_files[song_id].append(file_id)

        return song_files

    def get_files_by_ids_bulk(self, file_ids: Collection[UUID | str], conn: Connection) -> dict[UUID, File]:
        """
        Get multiple files by their IDs in a single query.

        Args:
            file_ids: Collection of file IDs to retrieve (list, tuple, set, etc.)
            conn: Database connection

        Returns:
            Dictionary mapping file_id to File model (only includes existing files)
        """
        if not file_ids:
            return {}

        stmt = select(self.t.files).where(self.t.files.c.id.in_(file_ids))
        result = self._safe_execute(conn, stmt)

        files = {}
        for row in result.fetchall():
            file_obj = File.model_validate(row)
            files[file_obj.id] = file_obj

        return files

    def get_file_by_id(self, file_id: UUID, conn: Connection) -> File | None:
        """
        Get a file by its ID.

        Args:
            file_id: The file ID
            conn: Database connection

        Returns:
            File model or None if not found
        """
        stmt = select(self.t.files).where(self.t.files.c.id == file_id)
        result = self._safe_execute(conn, stmt)
        row = result.fetchone()

        if not row:
            return None

        return File.model_validate(row)

    def update_file(self, file_id: UUID, updates: dict, conn: Connection) -> None:
        """
        Update a file record with the given updates.

        Args:
            file_id: The file ID to update
            updates: Dictionary of fields to update (e.g., {"path": "new/path", "md5_hash": "abc123"})
            conn: Database connection

        Raises:
            DatabaseError: If update fails or file doesn't exist
        """
        try:
            # Always update updated_at timestamp
            values = {**updates, "updated_at": func.now()}
            stmt = update(self.t.files).where(self.t.files.c.id == file_id).values(**values)
            result = self._safe_execute(conn, stmt)

            if result.rowcount == 0:
                error_msg = f"No file found with ID {file_id} to update"
                logger.error(error_msg)
                raise DatabaseError(error_msg)  # noqa: TRY301

            logger.debug(f"Updated file {file_id} with values: {updates}")
        except DatabaseError:
            # Re-raise DatabaseError as-is
            raise
        except Exception as e:
            error_msg = f"Failed to update file {file_id}: {e}"
            logger.error(error_msg)
            raise DatabaseError(error_msg) from e

    def update_files_bulk(self, updates: list[dict], conn: Connection) -> None:
        """
        Bulk update multiple files with different values.

        Args:
            updates: List of dicts, each must contain 'id' plus fields to update.
            conn: Database connection
        """
        if not updates:
            return

        try:
            # Inspect first element to determine structure
            first_keys = set(updates[0].keys())

            if "id" not in first_keys:
                msg = "Bulk update items must contain 'id'"
                raise ValueError(msg)  # noqa: TRY301

            # Determine fields to update (exclude ID keys)
            update_fields = first_keys - {"id"}

            if not update_fields:
                logger.debug("No fields to update in bulk operation.")
                return

            # Prepare processed updates list
            processed_updates = []

            # Iterate to validate and remap
            for i, update_item in enumerate(updates):
                item_keys = set(update_item.keys())

                # Validate keys match exactly
                if item_keys != first_keys:
                    msg = f"Bulk update item at index {i} has inconsistent keys. Expected {first_keys}, got {item_keys}"
                    raise ValueError(msg)  # noqa: TRY301

                # Create new dict for execution: remap 'id' -> 'file_id' for bindparam safety
                processed_item = update_item.copy()
                processed_item["file_id"] = processed_item.pop("id")
                processed_updates.append(processed_item)

            # Construct values dict with bindparams for input keys + automatic updated_at
            values_clause: dict[str, Any] = {key: bindparam(key) for key in update_fields}
            values_clause["updated_at"] = func.now()

            stmt = update(self.t.files).where(self.t.files.c.id == bindparam("file_id")).values(**values_clause)

            # execute() with a list of dictionaries triggers executemany
            conn.execute(stmt, processed_updates)
            logger.debug(f"Bulk updated {len(processed_updates)} files.")

        except Exception as e:
            error_msg = f"Failed to bulk update files: {e}"
            logger.error(error_msg)
            raise DatabaseError(error_msg) from e
