"""Repository for Song entity operations."""

from collections.abc import Collection
from uuid import UUID

from loguru import logger
from sqlalchemy import Connection, select

from musicdata.db.db_core import CatalogDatabase
from musicdata.db.exceptions import DatabaseError
from musicdata.db.models.models import Song
from musicdata.db.repositories.base import BaseRepository


class SongRepository(BaseRepository):
    """Repository for Song entity operations."""

    def __init__(self, db: CatalogDatabase) -> None:
        super().__init__(db)

    def insert_song(self, conn: Connection, song: Song) -> None:
        """
        Insert a song into the database.

        Args:
            conn: Database connection
            song: Song entity to insert
        """
        stmt = self.t.songs.insert().values(
            id=song.id,
            dataset=song.dataset,
            deleted=song.deleted,
            visibility=song.visibility.value,
        )
        conn.execute(stmt)

    def insert_songs_bulk(self, conn: Connection, songs: list[Song]) -> list[Song]:
        """
        Bulk insert songs that don't already exist.

        Args:
            conn: Database connection
            songs: List of songs to insert

        Returns:
            List of songs actually inserted
        """
        if not songs:
            return []

        # Get existing song IDs
        song_ids = [song.id for song in songs]
        stmt = select(self.t.songs.c.id).where(self.t.songs.c.id.in_(song_ids))
        result = self._safe_execute(conn, stmt)
        existing_ids = {row[0] for row in result.fetchall()}

        # Filter out existing songs
        songs_to_insert = [song for song in songs if song.id not in existing_ids]

        if not songs_to_insert:
            return []

        # Bulk insert new songs using model_dump, excluding server-managed timestamps
        insert_data = [
            song.model_dump(exclude={"created_at", "updated_at"}, exclude_none=False, mode="json")
            for song in songs_to_insert
        ]

        try:
            stmt = self.t.songs.insert()
            conn.execute(stmt, insert_data)
        except Exception as e:
            logger.error(f"Failed to bulk insert songs: {e}")
            msg = f"Failed to bulk insert songs: {e}"
            raise DatabaseError(msg) from e

        return songs_to_insert

    def do_songs_exist_bulk(self, song_ids: Collection[UUID], conn: Connection) -> dict[UUID, bool]:
        """
        Check which songs exist in bulk.

        Args:
            song_ids: List of song IDs to check

        Returns:
            Dictionary mapping song_id to existence boolean
        """
        if not song_ids:
            return {}

        stmt = select(self.t.songs.c.id).where(self.t.songs.c.id.in_(song_ids))
        result = self._safe_execute(conn, stmt)
        existing_ids = {row[0] for row in result.fetchall()}

        return {song_id: song_id in existing_ids for song_id in song_ids}

    def get_datasets_by_song_ids_bulk(self, song_ids: Collection[UUID | str], conn: Connection) -> dict[UUID, str]:
        """
        Get dataset names for multiple song IDs in bulk.

        Args:
            song_ids: Collection of song IDs to get datasets for (list, tuple, set, etc.)

        Returns:
            Dictionary mapping song_id to dataset name
        """
        if not song_ids:
            return {}

        stmt = select(self.t.songs.c.id, self.t.songs.c.dataset).where(self.t.songs.c.id.in_(song_ids))
        result = self._safe_execute(conn, stmt)

        return {row[0]: row[1] for row in result.fetchall()}

    def get_song_by_id(self, song_id: UUID, conn: Connection) -> Song | None:
        """
        Get a song by its ID.

        Args:
            song_id: The song ID
            conn: Database connection

        Returns:
            Song model or None if not found
        """
        stmt = select(self.t.songs).where(self.t.songs.c.id == song_id)
        result = self._safe_execute(conn, stmt)
        row = result.fetchone()

        if not row:
            return None

        return Song.model_validate(row)
