"""Repository for batch-related database operations."""

from uuid import UUID

from loguru import logger
from sqlalchemy import Connection, select
from sqlalchemy.dialects.postgresql import insert

from musicdata.db import insert_rows
from musicdata.db.db_core import CatalogDatabase
from musicdata.db.exceptions import DatabaseError
from musicdata.db.models import AnnotationBatch
from musicdata.db.repositories.base import BaseRepository


class BatchRepository(BaseRepository):
    """Repository for batch database operations."""

    def __init__(self, db: CatalogDatabase) -> None:
        super().__init__(db)

    def is_batch_loaded(self, batch_id: UUID, conn: Connection) -> bool:
        """Checks if an annotation batch is already loaded in the database."""
        stmt = select(self.t.annotation_batches.c.id).where(self.t.annotation_batches.c.id == batch_id)
        return self._safe_execute(conn, stmt).scalar_one_or_none() is not None

    def insert_batch(self, conn: Connection, batch: AnnotationBatch) -> bool:
        """
        Insert an annotation batch using provided connection.
        Returns True if inserted, False if already exists.
        """
        try:
            insert_rows(conn, self.t.annotation_batches, batch.model_dump())
            logger.info(f"Inserted new annotation batch: {batch.id}")
        except Exception as e:
            logger.error(f"Failed to insert batch {batch.id}: {e}")
            msg = f"Failed to insert batch: {e}"
            raise DatabaseError(msg) from e
        return True

    def insert_batch_atomic(self, conn: Connection, batch: AnnotationBatch) -> bool:
        """
        Atomically insert an annotation batch, ignoring conflicts.

        This method uses PostgreSQL's ON CONFLICT DO NOTHING to handle
        concurrent batch creation without race conditions. Perfect for
        multi-process environments where multiple processes might try
        to create the same batch simultaneously.

        Args:
            conn: Database connection
            batch: AnnotationBatch to insert

        Returns:
            bool: True if batch was inserted, False if it already existed
        """
        try:
            batch_data = batch.model_dump()

            # Use PostgreSQL's INSERT ... ON CONFLICT DO NOTHING
            stmt = insert(self.t.annotation_batches).values(batch_data)
            stmt = stmt.on_conflict_do_nothing(index_elements=["id"])

            result = self._safe_execute(conn, stmt)

            # Check if a row was actually inserted
            was_inserted = result.rowcount > 0

            if was_inserted:
                logger.info(f"Inserted new annotation batch: {batch.id}")
            else:
                logger.debug(f"Annotation batch {batch.id} already exists, skipped insertion")

        except Exception as e:
            logger.error(f"Failed to insert batch {batch.id}: {e}")
            msg = f"Failed to insert batch: {e}"
            raise DatabaseError(msg) from e

        return was_inserted

    def insert_batch_if_not_exists(self, conn: Connection, batch: AnnotationBatch) -> bool:
        """
        Insert an annotation batch using provided connection if it doesn't already exist.
        Returns True if inserted, False if already exists.
        """
        if not self.is_batch_loaded(batch.id, conn):
            return self.insert_batch(conn, batch)
        logger.info(f"Annotation batch {batch.id} already exists. Skipping insertion.")
        return False

    def get_batch_by_id(self, conn: Connection, batch_id: UUID) -> AnnotationBatch | None:
        """Get batch by ID, returns None if not found."""
        stmt = select(self.t.annotation_batches).where(self.t.annotation_batches.c.id == batch_id)

        row = self._safe_execute(conn, stmt).fetchone()
        if not row:
            return None
        return AnnotationBatch.model_validate(row)
