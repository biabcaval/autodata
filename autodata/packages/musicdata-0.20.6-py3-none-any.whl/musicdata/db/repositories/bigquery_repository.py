"""Repository for BigQuery-related operations."""

import re

import pandas as pd
from google.cloud import bigquery
from google.cloud.bigquery_storage import BigQueryReadClient
from loguru import logger

from musicdata.db.config import BigQueryConfig
from musicdata.db.exceptions import BigQueryError


class BigQueryRepository:
    """Repository for BigQuery-only operations that don't interact with the database."""

    def __init__(
        self,
        client: bigquery.Client | None = None,
        config: BigQueryConfig | None = None,
        bqstorage_client: BigQueryReadClient | None = None,
    ) -> None:
        if client:
            self.client = client
        elif config:
            self.client = bigquery.Client(**config.to_bigquery_kwargs())
        else:
            # Fallback to default client
            self.client = bigquery.Client()

        # Initialize BigQuery Storage API client early to fail fast if unavailable
        try:
            self.bqstorage_client = bqstorage_client or BigQueryReadClient()
        except Exception as e:
            msg = f"Failed to initialize BigQuery Storage API client: {e}"
            logger.error(msg)
            raise BigQueryError(msg) from e

    @staticmethod
    def validate_bigquery_identifier(identifier: str, identifier_type: str = "identifier") -> None:
        """Validate BigQuery identifier (project, dataset, table, or full table ID) to prevent SQL injection.

        Args:
            identifier: The identifier to validate
            identifier_type: Type of identifier for error messages (e.g., "project", "dataset", "table")

        Raises:
            BigQueryError: If the identifier contains invalid characters
        """
        # BigQuery identifiers: Allow alphanumeric, underscores, hyphens, and dots
        if not re.match(r"^[a-zA-Z0-9_.-]+$", identifier):
            msg = (
                f"Invalid BigQuery {identifier_type} format: {identifier}. "
                "Only alphanumeric characters, underscores, hyphens, and dots are allowed."
            )
            raise BigQueryError(msg)

    @staticmethod
    def validate_bigquery_table_components(project: str, dataset: str, table: str) -> None:
        """Validate individual BigQuery table components.

        Args:
            project: Project ID
            dataset: Dataset ID
            table: Table name

        Raises:
            BigQueryError: If any component contains invalid characters
        """
        BigQueryRepository.validate_bigquery_identifier(project, "project")
        BigQueryRepository.validate_bigquery_identifier(dataset, "dataset")
        BigQueryRepository.validate_bigquery_identifier(table, "table")

    @staticmethod
    def _validate_dataset_id(dataset_id: str) -> None:
        """Validate BigQuery dataset ID to prevent SQL injection."""
        BigQueryRepository.validate_bigquery_identifier(dataset_id, "dataset ID")

    def get_table_data(self, table_id: str) -> pd.DataFrame:
        """Fetches data from the specified BigQuery table or view.

        Args:
            table_id: The BigQuery table ID in format 'project.dataset.table' or 'dataset.table'

        Returns:
            pd.DataFrame: The query results as a pandas DataFrame

        Raises:
            BigQueryError: If the query fails or table_id is invalid
        """
        self._validate_dataset_id(table_id)
        logger.info(f"Fetching data from {table_id}...")
        query = f"SELECT * FROM `{table_id}`"  # noqa: S608
        try:
            return self.client.query(query).to_dataframe()
        except Exception as e:
            msg = f"Failed to fetch data from {table_id}: {e}"
            logger.error(msg)
            raise BigQueryError(msg) from e

    def execute_query(
        self, query: str, query_parameters: list[bigquery.ScalarQueryParameter] | None = None
    ) -> pd.DataFrame:
        """Executes a custom BigQuery SQL query with optional parameters.

        Args:
            query: The SQL query string to execute (use @param_name for named parameters)
            query_parameters: Optional list of BigQuery query parameters for parameterized queries

        Returns:
            pd.DataFrame: The query results as a pandas DataFrame

        Raises:
            BigQueryError: If the query fails or is invalid

        Examples:
            ```python
            # Simple query without parameters
            df = repo.execute_query("SELECT * FROM `project.dataset.table` LIMIT 10")

            # Parameterized query with named parameters
            params = [
                bigquery.ScalarQueryParameter("min_date", "DATE", "2024-01-01"),
                bigquery.ScalarQueryParameter("limit_count", "INT64", 1000)
            ]
            df = repo.execute_query(
                "SELECT * FROM `project.dataset.table` WHERE date >= @min_date LIMIT @limit_count",
                query_parameters=params
            )
            ```
        """
        if not query or not query.strip():
            msg = "Query cannot be empty"
            raise BigQueryError(msg)

        logger.info("Executing custom BigQuery query...")
        logger.debug(f"Query: {query}")
        if query_parameters:
            logger.debug(f"Parameters: {[f'{p.name}={p.value}' for p in query_parameters]}")

        try:
            job_config = bigquery.QueryJobConfig()
            if query_parameters:
                job_config.query_parameters = query_parameters

            job = self.client.query(query, job_config=job_config)
            return job.to_dataframe(bqstorage_client=self.bqstorage_client)
        except Exception as e:
            msg = f"Failed to execute query: {e}"
            logger.error(msg)
            raise BigQueryError(msg) from e

    def execute_query_iter(
        self,
        query: str,
        query_parameters: list[bigquery.ScalarQueryParameter] | None = None,
        *,
        yield_as: str = "dict",
        page_size: int | None = None,
    ):
        """Execute a query and stream results efficiently.

        This method keeps memory usage bounded and uses the BigQuery Storage API
        for high-throughput transfers. It avoids materializing a full DataFrame
        unless you explicitly iterate over chunked DataFrames.

        Args:
            query: SQL query to execute.
            query_parameters: Optional list of query parameters.
            yield_as: One of {"dict", "dataframe"}. If "dict", yields Python
                dict rows (fetched via Storage API in columnar record batches and
                converted per-chunk). If "dataframe", yields pandas DataFrames
                in chunks (Storage API fast path).
            page_size: Optional page size hint when creating the initial RowIterator
                handle. The Storage API performs its own batching; this value may
                be ignored by the backend.

        Yields:
            dict | pd.DataFrame: Depending on `yield_as`.

        Raises:
            BigQueryError: On invalid arguments or when the Storage API is not
                available, or execution failure.
        """
        if not query or not query.strip():
            msg = "Query cannot be empty"
            raise BigQueryError(msg)

        if yield_as not in {"dict", "dataframe"}:
            msg = "yield_as must be one of {'dict', 'dataframe'} when using Storage API"
            raise BigQueryError(msg)

        logger.info("Executing streaming BigQuery query...")
        logger.debug(f"Query: {query}")
        if query_parameters:
            logger.debug(f"Parameters: {[f'{p.name}={p.value}' for p in query_parameters]}")

        try:
            job_config = bigquery.QueryJobConfig()
            if query_parameters:
                job_config.query_parameters = query_parameters

            job = self.client.query(query, job_config=job_config)

            # Use RowIterator for iteration/pagination
            row_iter = job.result(page_size=page_size)

            # Use the pre-initialized BigQuery Storage API client
            bqstorage_client = self.bqstorage_client
            if bqstorage_client is None:
                msg = "BigQuery Storage API client is not initialized."
                raise BigQueryError(msg)  # noqa: TRY301

            if yield_as == "dataframe":
                yield from row_iter.to_dataframe_iterable(bqstorage_client=bqstorage_client)
                return

            # yield_as == "dict": stream Arrow tables and yield dict records per chunk
            for table in row_iter.to_arrow_iterable(bqstorage_client=bqstorage_client):
                yield table.to_pylist()
        except Exception as e:
            msg = f"Failed to execute streaming query: {e}"
            logger.error(msg)
            raise BigQueryError(msg) from e
