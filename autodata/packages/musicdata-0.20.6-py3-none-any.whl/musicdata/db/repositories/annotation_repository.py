"""Repository for annotation-related database operations."""

from collections import defaultdict
from collections.abc import Sequence
from uuid import UUID

from loguru import logger
from sqlalchemy import Connection, and_, func, select, text

from musicdata.db import insert_rows
from musicdata.db.db_core import CatalogDatabase
from musicdata.db.exceptions import AnnotationNotFoundError, DatabaseError
from musicdata.db.models import Annotation
from musicdata.db.models.requests import AnnotationRequest
from musicdata.db.repositories.base import BaseRepository


class AnnotationRepository(BaseRepository):
    """Repository for annotation database operations."""

    def __init__(self, db: CatalogDatabase) -> None:
        super().__init__(db)

    def get_latest_file_annotation(self, file_id: UUID, kind_name: str, conn: Connection) -> Annotation | None:
        """
        Retrieves the latest annotation for a given file ID and kind name.
        Returns an Annotation Pydantic model or None if not found.
        """
        # Use functional index on get_kind_name_for_annotation for optimal performance
        stmt = text(
            """
            SELECT
                a.*,
                get_kind_name_for_annotation(a.kind_id) AS kind_name
            FROM
                annotations a
            WHERE
                a.file_id = :file_id
                AND get_kind_name_for_annotation(a.kind_id) = :kind_name
            ORDER BY
                a.revision DESC
            LIMIT 1
            """
        )

        row = self._safe_execute(conn, stmt, {"file_id": file_id, "kind_name": kind_name}).fetchone()
        if not row:
            return None
        return Annotation.model_validate(row)

    def get_latest_file_annotations_bulk(
        self, file_ids: list[UUID] | list[str], kind_name: str, conn: Connection
    ) -> dict[UUID, Annotation]:
        """
        Bulk retrieval of latest annotations for multiple files.
        Returns a dictionary mapping file_id to Annotation.
        """
        if not file_ids:
            return {}

        chunk_size = 10000
        results: dict[UUID, Annotation] = {}

        for i in range(0, len(file_ids), chunk_size):
            chunk = file_ids[i : i + chunk_size]

            # Use functional index on get_kind_name_for_annotation for optimal performance
            stmt = text(
                """
                WITH ranked_annotations AS (
                    SELECT
                        a.*,
                        get_kind_name_for_annotation(a.kind_id) AS kind_name,
                        ROW_NUMBER() OVER (PARTITION BY a.file_id ORDER BY a.revision DESC) as rn
                    FROM
                        annotations a
                    WHERE
                        a.file_id = ANY(CAST(:file_ids AS uuid[]))
                        AND get_kind_name_for_annotation(a.kind_id) = :kind_name
                )
                SELECT * FROM ranked_annotations WHERE rn = 1
                """
            )

            rows = self._safe_execute(conn, stmt, {"file_ids": chunk, "kind_name": kind_name}).fetchall()
            for row in rows:
                results[row.file_id] = Annotation.model_validate(row)

        return results

    def get_all_latest_file_annotations_bulk(
        self, file_ids: list[UUID] | list[str], conn: Connection
    ) -> dict[UUID, dict[str, Annotation]]:
        """
        Bulk retrieval of latest annotations for all kinds for multiple files.

        Returns a nested dictionary mapping file_id to kind_name to Annotation.
        For each file, returns the latest revision of each annotation kind.

        Args:
            file_ids: List of file UUIDs or string UUIDs
            conn: Database connection

        Returns:
            dict mapping file_id -> kind_name -> Annotation
        """
        if not file_ids:
            return {}

        chunk_size = 10000
        results: dict[UUID, dict[str, Annotation]] = defaultdict(dict)

        for i in range(0, len(file_ids), chunk_size):
            chunk = file_ids[i : i + chunk_size]

            # Partition by file_id AND kind_name to get latest revision for each kind per file
            stmt = text(
                """
                WITH ranked_annotations AS (
                    SELECT
                        a.*,
                        get_kind_name_for_annotation(a.kind_id) AS kind_name,
                        ROW_NUMBER() OVER (
                            PARTITION BY a.file_id, get_kind_name_for_annotation(a.kind_id)
                            ORDER BY a.revision DESC
                        ) as rn
                    FROM
                        annotations a
                    WHERE
                        a.file_id = ANY(CAST(:file_ids AS uuid[]))
                )
                SELECT * FROM ranked_annotations WHERE rn = 1
                """
            )

            rows = self._safe_execute(conn, stmt, {"file_ids": chunk}).fetchall()
            for row in rows:
                results[row.file_id][row.kind_name] = Annotation.model_validate(row)

        return dict(results)

    def get_latest_song_annotations_bulk(
        self, song_ids: list[UUID] | list[str], kind_name: str, conn: Connection
    ) -> dict[UUID, Annotation]:
        """
        Bulk retrieval of latest annotations for multiple songs.
        Returns a dictionary mapping song_id to Annotation.
        """
        if not song_ids:
            return {}

        chunk_size = 10000
        results: dict[UUID, Annotation] = {}

        for i in range(0, len(song_ids), chunk_size):
            chunk = song_ids[i : i + chunk_size]

            # Use functional index on get_kind_name_for_annotation for optimal performance
            stmt = text(
                """
                WITH ranked_annotations AS (
                    SELECT
                        a.*,
                        get_kind_name_for_annotation(a.kind_id) AS kind_name,
                        ROW_NUMBER() OVER (PARTITION BY a.song_id ORDER BY a.revision DESC) as rn
                    FROM
                        annotations a
                    WHERE
                        a.song_id = ANY(CAST(:song_ids AS uuid[]))
                        AND get_kind_name_for_annotation(a.kind_id) = :kind_name
                )
                SELECT * FROM ranked_annotations WHERE rn = 1
                """
            )

            rows = self._safe_execute(conn, stmt, {"song_ids": chunk, "kind_name": kind_name}).fetchall()
            for row in rows:
                results[row.song_id] = Annotation.model_validate(row)

        return results

    def get_all_latest_song_annotations_bulk(
        self, song_ids: list[UUID] | list[str], conn: Connection
    ) -> dict[UUID, dict[str, Annotation]]:
        """
        Bulk retrieval of latest annotations for all kinds for multiple songs.

        Returns a nested dictionary mapping song_id to kind_name to Annotation.
        For each song, returns the latest revision of each annotation kind.

        Args:
            song_ids: List of song UUIDs or string UUIDs
            conn: Database connection

        Returns:
            dict mapping song_id -> kind_name -> Annotation
        """
        if not song_ids:
            return {}

        chunk_size = 10000
        results: dict[UUID, dict[str, Annotation]] = defaultdict(dict)

        for i in range(0, len(song_ids), chunk_size):
            chunk = song_ids[i : i + chunk_size]

            # Partition by song_id AND kind_name to get latest revision for each kind per song
            stmt = text(
                """
                WITH ranked_annotations AS (
                    SELECT
                        a.*,
                        get_kind_name_for_annotation(a.kind_id) AS kind_name,
                        ROW_NUMBER() OVER (
                            PARTITION BY a.song_id, get_kind_name_for_annotation(a.kind_id)
                            ORDER BY a.revision DESC
                        ) as rn
                    FROM
                        annotations a
                    WHERE
                        a.song_id = ANY(CAST(:song_ids AS uuid[]))
                )
                SELECT * FROM ranked_annotations WHERE rn = 1
                """
            )

            rows = self._safe_execute(conn, stmt, {"song_ids": chunk}).fetchall()
            for row in rows:
                results[row.song_id][row.kind_name] = Annotation.model_validate(row)

        return dict(results)

    def get_latest_song_annotation(self, song_id: UUID, kind_name: str, conn: Connection) -> Annotation | None:
        """
        Retrieves the latest annotation for a given song ID and kind name.
        Returns an Annotation Pydantic model or None if not found.
        """
        # Use functional index on get_kind_name_for_annotation for optimal performance
        stmt = text(
            """
            SELECT
                a.*,
                get_kind_name_for_annotation(a.kind_id) AS kind_name
            FROM
                annotations a
            WHERE
                a.song_id = :song_id
                AND get_kind_name_for_annotation(a.kind_id) = :kind_name
            ORDER BY
                a.revision DESC
            LIMIT 1
            """
        )

        row = self._safe_execute(conn, stmt, {"song_id": song_id, "kind_name": kind_name}).fetchone()
        if not row:
            return None
        return Annotation.model_validate(row)

    def insert_annotation(self, conn: Connection, annotation: Annotation | list[Annotation]) -> None:
        """Inserts a new annotation record or multiple annotation records."""
        try:
            if isinstance(annotation, list):
                annotations_to_insert = [ann.model_dump() for ann in annotation]
                if not annotations_to_insert:
                    logger.debug("No annotations provided to insert.")
                    return
                insert_rows(conn, self.t.annotations, annotations_to_insert)
                logger.debug(f"Inserted {len(annotations_to_insert)} annotations.")
            else:
                insert_rows(conn, self.t.annotations, annotation.model_dump())
                logger.debug(f"Inserted annotation for file {annotation.file_id}.")
        except Exception as e:
            error_msg = f"Failed to insert annotation(s): {e}"
            logger.error(error_msg)
            raise DatabaseError(error_msg) from e

    def insert_annotations_bulk(self, conn: Connection, annotations: list[Annotation]) -> None:
        """
        Inserts multiple annotations efficiently.
        Optimized for ETL workloads.
        """
        if not annotations:
            logger.debug("No annotations provided for bulk insert.")
            return

        try:
            annotations_data = [ann.model_dump() for ann in annotations]
            insert_rows(conn, self.t.annotations, annotations_data)
            logger.debug(f"Bulk inserted {len(annotations)} annotations.")
        except Exception as e:
            error_msg = f"Failed to bulk insert annotations: {e}"
            logger.error(error_msg)
            raise DatabaseError(error_msg) from e

    def get_annotation_by_id(self, annotation_id: UUID, conn: Connection) -> Annotation:
        """Get annotation by ID, raises exception if not found."""
        stmt = text(
            """
            SELECT
                a.*,
                get_kind_name_for_annotation(a.kind_id) AS kind_name
            FROM
                annotations a
            WHERE
                a.id = :annotation_id
            """
        )

        row = self._safe_execute(conn, stmt, {"annotation_id": annotation_id}).fetchone()
        if not row:
            error_msg = f"Annotation with ID {annotation_id} not found"
            raise AnnotationNotFoundError(error_msg)
        return Annotation.model_validate(row)

    def get_next_revision(
        self,
        kind_id: UUID,
        conn: Connection,
        *,
        song_id: UUID | None = None,
        file_id: UUID | None = None,
    ) -> int:
        """
        Get the next revision number for an annotation of the given kind for the specified entity.

        Args:
            kind_id: The annotation kind ID
            conn: Database connection
            song_id: The song ID (if this is a song annotation)
            file_id: The file ID (if this is a file annotation)

        Returns:
            int: The next revision number (1 if no existing annotations, max_revision + 1 otherwise)

        Raises:
            ValueError: If neither song_id nor file_id is provided, or if both are provided
        """
        if song_id is None and file_id is None:
            msg = "Either song_id or file_id must be provided"
            raise ValueError(msg)
        if song_id is not None and file_id is not None:
            msg = "Cannot specify both song_id and file_id"
            raise ValueError(msg)

        if song_id is not None:
            where_clause = and_(
                self.t.annotations.c.song_id == song_id,
                self.t.annotations.c.kind_id == kind_id,
            )
        else:
            where_clause = and_(
                self.t.annotations.c.file_id == file_id,
                self.t.annotations.c.kind_id == kind_id,
            )

        stmt = select(func.max(self.t.annotations.c.revision)).where(where_clause)

        result = self._safe_execute(conn, stmt).scalar()
        return (result or 0) + 1

    def get_kind_names_by_file_ids_bulk(
        self, file_ids: Sequence[UUID | str], conn: Connection
    ) -> dict[UUID, list[str]]:
        """
        Get all annotation kind names that exist for multiple files in bulk (any revision).

        Args:
            file_ids: Sequence of file IDs (list, tuple, etc.)
            conn: Database connection

        Returns:
            Dictionary mapping file_id to list of unique annotation kind names
        """
        if not file_ids:
            return {}

        # Chunk size for ANY query to avoid performance issues with large lists
        chunk_size = 10000
        kinds_by_file: dict[UUID, list[str]] = defaultdict(list)

        for i in range(0, len(file_ids), chunk_size):
            chunk = file_ids[i : i + chunk_size]

            # Join with annotation_kinds to avoid function call overhead
            stmt = text(
                """
                SELECT DISTINCT a.file_id, get_kind_name_for_annotation(a.kind_id) AS kind_name
                FROM annotations a
                WHERE a.file_id = ANY(CAST(:file_ids AS uuid[]))
                """
            )

            rows = self._safe_execute(conn, stmt, {"file_ids": chunk}).fetchall()

            for row in rows:
                kinds_by_file[row.file_id].append(row.kind_name)

        return kinds_by_file

    def get_next_revisions_bulk(
        self,
        requests: list[AnnotationRequest],
        conn: Connection,
    ) -> dict[tuple[UUID, UUID, bool], int]:
        """
        Get the next revision numbers for multiple annotation requests efficiently.

        Since business rules guarantee only one request per (entity_id, kind_id, is_song)
        combination in a batch, this method creates a simple mapping of keys to next revisions.

        IMPORTANT: This method calculates revisions based on kind_name (not kind_id) to match
        the unique constraint: unique_annotations_file_kind_name_rev

        Args:
            requests: List of annotation requests (guaranteed unique by caller)
            conn: Database connection

        Returns:
            dict: Mapping from (entity_id, kind_id, is_song) to next revision number
        """
        if not requests:
            return {}

        # Group requests by (kind_id, is_song) for efficient querying
        # BUT we'll need to get kind_names for proper revision calculation
        groups: dict[tuple[UUID, bool], list[UUID]] = {}
        unique_keys: set[tuple[UUID, UUID, bool]] = set()
        kind_id_to_name: dict[UUID, str] = {}

        for req in requests:
            if req.song_id is not None:
                entity_id = req.song_id
                is_song = True
            elif req.file_id is not None:
                entity_id = req.file_id
                is_song = False
            else:
                msg = f"AnnotationRequest must have either song_id or file_id set: {req}"
                raise ValueError(msg)

            # Group for efficient querying
            group_key = (req.kind_id, is_song)
            if group_key not in groups:
                groups[group_key] = []
            groups[group_key].append(entity_id)

            # Track unique keys for final result
            unique_keys.add((entity_id, req.kind_id, is_song))

        # Get kind names for all kind_ids involved
        if groups:
            all_kind_ids = {kind_id for kind_id, _ in groups}
            kind_name_stmt = select(self.t.annotation_kinds.c.id, self.t.annotation_kinds.c.kind).where(
                self.t.annotation_kinds.c.id.in_(all_kind_ids)
            )
            kind_results = self._safe_execute(conn, kind_name_stmt).fetchall()
            kind_id_to_name = {row.id: row.kind for row in kind_results}

        # Execute optimized queries for each group
        # BUT use kind_name in the WHERE clause to match the constraint
        existing_max: dict[tuple[UUID, UUID, bool], int] = {}

        for (kind_id, is_song), entity_ids in groups.items():
            kind_name = kind_id_to_name.get(kind_id)
            if not kind_name:
                logger.warning(f"Kind name not found for kind_id {kind_id}, skipping revision calculation")
                continue

            if is_song:
                # Use functional index on get_kind_name_for_annotation for optimal performance
                stmt = text(
                    """
                    SELECT
                        song_id,
                        MAX(revision) as max_revision
                    FROM annotations
                    WHERE song_id = ANY(:entity_ids)
                        AND get_kind_name_for_annotation(kind_id) = :kind_name
                    GROUP BY song_id
                    """
                )
            else:
                # Use functional index on get_kind_name_for_annotation for optimal performance
                stmt = text(
                    """
                    SELECT
                        file_id,
                        MAX(revision) as max_revision
                    FROM annotations
                    WHERE file_id = ANY(:entity_ids)
                        AND get_kind_name_for_annotation(kind_id) = :kind_name
                    GROUP BY file_id
                    """
                )

            results = self._safe_execute(conn, stmt, {"entity_ids": entity_ids, "kind_name": kind_name}).fetchall()

            # Map results to our format
            for row in results:
                entity_id = row.song_id if is_song else row.file_id
                key = (entity_id, kind_id, is_song)  # Still use kind_id as key for return mapping
                existing_max[key] = row.max_revision or 0

        # Calculate next revisions for all unique keys
        next_revisions: dict[tuple[UUID, UUID, bool], int] = {}
        for key in unique_keys:
            base_revision = existing_max.get(key, 0)
            next_revisions[key] = base_revision + 1

        return next_revisions
