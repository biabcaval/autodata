"""Repository manager for centralized database and repository access."""

from collections.abc import Iterator
from contextlib import contextmanager

from sqlalchemy import Connection

from musicdata.db.config import BigQueryConfig
from musicdata.db.db_core import CatalogDatabase
from musicdata.db.repositories.annotation_repository import AnnotationRepository
from musicdata.db.repositories.batch_repository import BatchRepository
from musicdata.db.repositories.bigquery_repository import BigQueryRepository
from musicdata.db.repositories.file_repository import FileRepository
from musicdata.db.repositories.song_repository import SongRepository


class RepositoryManager:
    """
    Centralized manager for all repository instances and database connections.

    Provides a single point of access to all repositories while managing
    the shared database connection. This ensures consistent connection
    management across all repositories.

    Example usage:
        db = CatalogDatabase(...)
        repos = RepositoryManager(db)

        # Connection management
        with repos.connection() as conn:
            annotation = repos.annotation.get_latest_file_annotation(file_id, kind_name, conn)

        # Transaction management
        with repos.transaction() as conn:
            repos.file.insert_file_if_not_exists(conn, file)
            repos.annotation.insert_annotation(conn, annotation)
    """

    def __init__(self, db: CatalogDatabase, bigquery_config: BigQueryConfig | None = None) -> None:
        """
        Initialize the repository manager with a database connection.

        Args:
            db: The catalog database instance
            bigquery_config: Optional BigQuery configuration for BigQuery operations
        """
        self.db = db
        self.t = db.t  # Tables shortcut
        self.v = db.v  # Views shortcut

        # Initialize all repositories with the shared database
        self.annotation = AnnotationRepository(db)
        self.batch = BatchRepository(db)
        self.file = FileRepository(db)
        self.song = SongRepository(db)

        # BigQuery repository doesn't need the database
        self.bigquery = BigQueryRepository(config=bigquery_config)

    @contextmanager
    def connection(self) -> Iterator[Connection]:
        """
        Get a read-only database connection.

        This is the single point for obtaining database connections across all repositories.
        Use this for read operations that don't need transaction control.
        """
        with self.db.engine.connect() as conn:
            yield conn

    @contextmanager
    def transaction(self) -> Iterator[Connection]:
        """
        Get a transactional database connection.

        This is the single point for transaction management across all repositories.
        Use this for write operations that need transaction control.
        """
        with self.db.engine.begin() as conn:
            yield conn

    def close(self) -> None:
        """Clean up resources if needed."""
        # Note: Database connection cleanup is handled by the CatalogDatabase instance
        # which should be managed by the calling code
