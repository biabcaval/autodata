"""Base repository class with common database operations."""

from abc import ABC
from typing import Any

from loguru import logger
from sqlalchemy import Connection

from musicdata.db.db_core import CatalogDatabase
from musicdata.db.exceptions import DatabaseError


class BaseRepository(ABC):  # noqa: B024
    """
    Base repository class with common database operations.

    Repositories should receive database connections as parameters rather than
    managing connections themselves. Connection management is centralized in
    the RepositoryManager.
    """

    def __init__(self, db: CatalogDatabase) -> None:
        self.db = db
        self.t = db.t  # Tables shortcut
        self.v = db.v  # Views shortcut

    def _safe_execute(self, conn: Connection, stmt: Any, params: dict[str, Any] | None = None) -> Any:
        """Safely execute a statement with error handling."""
        try:
            if params:
                return conn.execute(stmt, params)
            return conn.execute(stmt)
        except Exception as e:
            logger.error(f"Query execution error: {e}")
            msg = f"Failed to execute query: {e}"
            raise DatabaseError(msg) from e
