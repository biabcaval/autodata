"""
This script generates versioned schemas for each model.
Each generated version has the following filename format: {model_name}_v{revision}.json
The script checks if there are any differences and only generates/updates a json schema if there are differences.

It finds all models that have names ending with 'Schema' and generates schemas for them.
Then, it uses the difflib library to compare the schemas and only generates a new version if there are differences.
It also includes constraints JSON files alongside the generated schema files if they exist.
"""

import difflib
import importlib
import inspect
import pkgutil
import sys
from pathlib import Path
from typing import Any

import orjson
from loguru import logger
from pydantic import BaseModel


def get_schema_classes() -> dict[str, type[BaseModel]]:
    """
    Get all schema classes (classes ending with 'Schema').

    Returns:
        Dict[str, Type[BaseModel]]: Dictionary of schema class names and classes
    """
    # Get the annotation package
    package_name = "musicdata.annotations.models"
    annotation_package = sys.modules[package_name]
    annotation_path = None
    if annotation_package.__file__ is not None:
        annotation_path = Path(annotation_package.__file__).parent
    if annotation_path is None:
        msg = "Could not determine annotation package path"
        raise ValueError(msg)

    # Iterate through all modules in the annotation package
    schemas = {}
    current_module = Path(__file__).stem
    for _, module_name, _ in pkgutil.iter_modules([str(annotation_path)]):
        # Skip the current module to avoid circular imports
        if module_name == current_module:
            continue

        try:
            module = importlib.import_module(f"{package_name}.{module_name}")

            # Find all classes that end with 'Schema'
            for name, obj in inspect.getmembers(module):
                if inspect.isclass(obj) and name.endswith("Schema"):
                    schemas[name] = obj  # noqa: PERF403
        except (ImportError, AttributeError):
            logger.warning(f"Could not import {module_name}, skipping")
            continue

    return schemas


def get_revision(schema_class: type[BaseModel]) -> int:
    """
    Get the schema revision for a model.

    Args:
        schema_class: The schema class to get revision for

    Returns:
        int: Schema revision (defaults to 1)
    """
    # If the schema class has a revision field, use it
    if hasattr(schema_class, "_revision"):
        # Get the default value from the field
        revision_field = getattr(schema_class, "_revision")  # noqa: B009
        if hasattr(revision_field, "default") and revision_field.default is not None:
            logger.debug(f"Using revision {revision_field.default} from {schema_class.__name__} class")
            return revision_field.default

    msg = (
        f"No revision found for {schema_class.__name__}. "
        "Check that the class has a _revision field with a default value."
    )
    raise ValueError(msg)


def get_description(schema_class: type[BaseModel]) -> str | None:
    """
    Get the description from the model class or property name.
    """
    # If the schema class has a description field, use it
    if hasattr(schema_class, "_description"):
        description_field = getattr(schema_class, "_description")  # noqa: B009
        if hasattr(description_field, "default") and description_field.default is not None:
            logger.debug(f"Using description '{description_field.default}' from {schema_class.__name__} class")
            return description_field.default

    return None


def get_kind(schema_class: type[BaseModel]) -> str | None:
    """
    Get the kind from the model class or property name.

    Args:
        schema_class: Model class to get kind from

    Returns:
        Optional[str]: Kind, or None if not defined
    """
    model_config = getattr(schema_class, "model_config", {})
    json_schema_extra = model_config.get("json_schema_extra", {})
    return json_schema_extra.get("kind")


def find_constraints(kind: str, constraints_dir: Path) -> dict[str, Any] | None:
    """
    Find a constraints file for the given kind.

    Args:
        kind: Kind to find constraints for
        constraints_dir: Directory to search for constraints files

    Returns:
        Optional[Dict[str, Any]]: Constraints, or None if not found
    """
    # Check if the constraints directory exists
    if not constraints_dir.exists():
        return None

    # Look for a constraints file with the kind name
    constraints_files = list(constraints_dir.glob(f"{kind}_constraints.json"))
    if not constraints_files:
        # Try alternative naming patterns
        constraints_files = list(constraints_dir.glob(f"*{kind}*.json"))

    # If we found any constraints files, load the first one
    if constraints_files:
        try:
            with open(constraints_files[0], "rb") as f:
                constraints_data = orjson.loads(f.read())

            # Check if the constraints has the correct kind
            if constraints_data.get("kind") == kind:
                return constraints_data
        except (orjson.JSONDecodeError, KeyError):
            msg = f"Invalid constraints file {constraints_files[0]}"
            raise ValueError(msg)  # noqa: B904

    return None


def schemas_are_different(schema1: dict, schema2: dict) -> bool:
    """
    Compare two schemas to see if they are different.

    Args:
        schema1: First schema
        schema2: Second schema

    Returns:
        bool: True if schemas are different, False otherwise
    """
    # Convert schemas to strings for comparison
    schema1_str = orjson.dumps(schema1, option=orjson.OPT_SORT_KEYS | orjson.OPT_INDENT_2).decode()
    schema2_str = orjson.dumps(schema2, option=orjson.OPT_SORT_KEYS | orjson.OPT_INDENT_2).decode()

    # Compare the schemas
    diff = list(difflib.unified_diff(schema1_str.splitlines(), schema2_str.splitlines(), n=0))

    return len(diff) > 0


def generate_schema(schema_class: type[BaseModel], schema_dir: Path, constraints_dir: Path) -> None:
    """
    Generate a schema for a model class.

    Args:
        schema_class: Model class to generate schema for
        schema_dir: Directory to save schema to
        constraints_dir: Directory to look for constraints
    """
    model_name = schema_class.__name__

    schema_dir.mkdir(parents=True, exist_ok=True)

    revision = get_revision(schema_class)
    description = get_description(schema_class)
    kind = get_kind(schema_class)
    if kind is None:
        logger.warning(f"Could not determine kind for {model_name}, skipping")
        return

    # Generate the schema
    json_schema = schema_class.model_json_schema()

    # Find constraints for this kind
    constraints_data = find_constraints(kind, constraints_dir)

    # Create the final schema structure with separate json_schema and constraints
    new_schema = {
        "kind": kind,
        "revision": revision,
        "description": description,
        "json_schema": json_schema,
        "constraints": constraints_data,
    }

    # Define the schema path
    schema_path = schema_dir / f"{model_name}_v{revision}.json"

    # Check if the schema file already exists
    schema_updated = False
    if schema_path.exists():
        # Load the existing schema
        try:
            with open(schema_path, "rb") as f:
                existing_schema = orjson.loads(f.read())

            # Compare the schemas
            if schemas_are_different(existing_schema, new_schema):
                # Update the schema file
                with open(schema_path, "wb") as f:
                    f.write(orjson.dumps(new_schema, option=orjson.OPT_INDENT_2))
                logger.info(f"Updated {schema_path} (schema has changed)")
                schema_updated = True
            else:
                logger.debug(f"No changes detected for {model_name}_v{revision}")
        except orjson.JSONDecodeError:
            # If the existing file is not valid JSON, overwrite it
            logger.warning(f"Existing schema file {schema_path} is not valid JSON, overwriting")
            with open(schema_path, "wb") as f:
                f.write(orjson.dumps(new_schema, option=orjson.OPT_INDENT_2))
            logger.info(f"Updated {schema_path} (invalid JSON)")
            schema_updated = True
    else:
        # Create a new schema file
        with open(schema_path, "wb") as f:
            f.write(orjson.dumps(new_schema, option=orjson.OPT_INDENT_2))
        logger.info(f"Generated {schema_path}")
        schema_updated = True

    if not constraints_data and schema_updated:
        # If we updated the schema but couldn't find constraints, log a warning
        logger.warning(f"No constraints found for {kind}")


def main() -> None:
    """Main function to generate schemas for all models."""
    logger.remove()
    logger.add(sys.stderr, level="INFO")

    # Get the directory where schemas will be stored
    script_dir = Path(__file__).parent
    schema_dir = script_dir / "generated"
    constraints_dir = script_dir.parent / "constraints"

    # Get all schema classes
    schema_classes = get_schema_classes()

    if not schema_classes:
        logger.info("No schema classes found.")
        return

    logger.info(f"Found {len(schema_classes)} schema classes: {', '.join(schema_classes.keys())}")

    # Generate schemas for each class
    for schema_class in schema_classes.values():
        generate_schema(schema_class, schema_dir, constraints_dir)

    logger.info("Done")


if __name__ == "__main__":
    main()
