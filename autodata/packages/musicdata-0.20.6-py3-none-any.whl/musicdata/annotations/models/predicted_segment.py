from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import AnnotationObjectBase, create_model_config
from musicdata.db.models.base import NonEmptyDict, NonEmptyList, NonEmptyString

from .segment import Segment


# The SegmentSchema is using the SegmentVersion class, and this was not updated to the new format.
class PredictedSegmentSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="predicted_segment")

    versions: NonEmptyDict[NonEmptyString, NonEmptyList[Segment]] = Field(
        ...,
        description="A dictionary of versions and their corresponding segment annotations.",
        json_schema_extra={"minItems": 1, "uniqueItems": True},
    )

    _description: str = PrivateAttr(default="Defines the segments for the file.")
    _revision: int = PrivateAttr(default=1)
