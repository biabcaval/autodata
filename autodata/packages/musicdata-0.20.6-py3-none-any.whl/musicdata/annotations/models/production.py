from enum import Enum

from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    PropertyBase,
    create_model_config,
)
from musicdata.db.models.base import NonEmptyString


class VocalMode(str, Enum):
    SINGING = "singing"
    SPEAKING = "speaking"
    WARMING_UP = "warming_up"


class RecordingType(str, Enum):
    SANG = "sang"
    SPOKEN = "spoken"
    WARM_UPS = "warm-ups"
    MUSIC = "music"
    PODCAST = "podcast"
    MUSIC_SPOKEN = "music:spoken"


class MicType(str, Enum):
    RIBBON = "ribbon"
    CONDENSER_LARGE_DIAPHRAGM = "condenser-large-diaphragm"
    CONDENSER = "condenser"
    DYNAMIC = "dynamic"


class Gender(str, Enum):
    MALE = "male"
    FEMALE = "female"
    OTHER = "other"


class VocalRange(str, Enum):
    SOPRANO = "soprano"
    MEZZO_SOPRANO = "mezzo-soprano"
    ALTO = "alto"
    TENOR = "tenor"
    BARITONE = "baritone"
    BASS = "bass"


class Recording(PropertyBase):
    recording_type: RecordingType | None = Field(None, description="The type of recording used.")
    language: NonEmptyString | None = Field(None, description="The language of the production.")
    engineered_by: NonEmptyString | None = Field(None, description="The person who engineered the production.")
    mic_type: MicType | None = Field(None, description="The type of microphone used.")
    mic_model: NonEmptyString | None = Field(None, description="The model of microphone used.")
    mic_min_freq_hz: int | None = Field(None, description="The minimum frequency of the microphone used in Hz.")
    mic_max_freq_khz: int | None = Field(None, description="The maximum frequency of the microphone used in kHz.")
    upload_recording_id: NonEmptyString | None = Field(None, description="The ID of the uploaded record.")


class Artist(PropertyBase):
    name: NonEmptyString = Field(..., description="The name of the artist.")
    age: int | None = Field(None, description="The age of the artist.")
    gender: Gender | None = Field(None, description="The gender of the artist.")
    accent: NonEmptyString | None = Field(None, description="The accent of the artist.")
    vocal_range: VocalRange | None = Field(None, description="The vocal range of the artist.")


class ProductionSchema(AnnotationObjectBase):
    model_config = create_model_config(
        kind="production",
        extra=None,
        additional_json_schema={"minItems": 1, "uniqueItems": True},
    )

    music_tonality: NonEmptyString | None = Field(None, description="The music tonality.")
    warm_up: NonEmptyString | None = Field(None, description="The performed warm up.")
    recording: Recording | None = Field(None, description="The recording details of the production.")
    artist: Artist | None = Field(None, description="The artist details of the production.")
    vocal_mode: VocalMode | None = Field(None, description="The type of vocalization in the audio file.")
    is_direct_input: bool | None = Field(None, description="Whether the audio file is a direct input or not.")

    _description: str = PrivateAttr(default="Defines the production details of the file.")
    _revision: int = PrivateAttr(default=1)
