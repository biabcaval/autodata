from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    PropertyBase,
    create_model_config,
)
from musicdata.db.models.base import NonEmptyDict, NonEmptyList, NonEmptyString


class Tempo(PropertyBase):
    start: float = Field(..., description="The start time of the bpm in seconds.")
    end: float = Field(..., description="The end time of the bpm in seconds.")
    bpm: float = Field(..., description="The bpm in this segment.")


class TempoVersion(PropertyBase):
    value: NonEmptyList[Tempo] = Field(..., description="The tempo for this version.")
    dataset_name: NonEmptyString | None = Field(None, description="The dataset of the annotation.")


class TempoSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="tempo")

    versions: NonEmptyDict[NonEmptyString, TempoVersion] = Field(
        ...,
        description="A dictionary of versions and their corresponding tempo annotations.",
        json_schema_extra={"minItems": 1, "uniqueItems": True},
    )

    _description: str = PrivateAttr(default="Defines the tempo for the file.")
    _revision: int = PrivateAttr(default=2)
