from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    PropertyBase,
    create_model_config,
)
from musicdata.db.models.base import NonEmptyDict, NonEmptyList, NonEmptyString


class Chord(PropertyBase):
    start: float = Field(..., description="The start time of the chord in seconds.")
    end: float = Field(..., description="The end time of the chord in seconds.")
    chord: NonEmptyString = Field(..., description="The chord in this section.")


class ChordVersion(PropertyBase):
    value: NonEmptyList[Chord] = Field(..., description="The chord for this version.")
    dataset_name: NonEmptyString | None = Field(None, description="The dataset of the annotation.")


class ChordSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="chord")

    versions: NonEmptyDict[NonEmptyString, ChordVersion] = Field(
        ...,
        description="A dictionary of versions and their corresponding chord annotations.",
        json_schema_extra={"minItems": 1, "uniqueItems": True},
    )

    _description: str = PrivateAttr(default="Defines the chords for the file.")
    _revision: int = PrivateAttr(default=2)
