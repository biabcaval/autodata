from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    PropertyBase,
    create_model_config,
)
from musicdata.db.models.base import NonEmptyDict, NonEmptyList, NonEmptyString


class Segment(PropertyBase):
    start: float = Field(..., description="The start time of the segment in seconds.")
    end: float = Field(..., description="The end time of the segment in seconds.")
    segment: NonEmptyString = Field(..., description="The segment type.")


class SegmentVersion(PropertyBase):
    value: NonEmptyList[Segment] = Field(..., description="The segment for this version.")
    dataset_name: NonEmptyString | None = Field(None, description="The dataset of the annotation.")


class SegmentSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="segment")

    versions: NonEmptyDict[NonEmptyString, SegmentVersion] = Field(
        ...,
        description="A dictionary of versions and their corresponding segment annotations.",
        json_schema_extra={"minItems": 1, "uniqueItems": True},
    )

    _description: str = PrivateAttr(default="Defines the segments for the file.")
    _revision: int = PrivateAttr(default=2)
