from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    PropertyBase,
    create_model_config,
)
from musicdata.db.models.base import NonEmptyDict, NonEmptyList, NonEmptyString


class Meter(PropertyBase):
    numerator: int = Field(..., description="The numerator of the meter.")
    start: float | None = Field(None, description="The start time of the meter in seconds.")
    end: float | None = Field(None, description="The end time of the meter in seconds.")
    denominator: int | None = Field(None, description="The denominator of the meter.")
    subdivision: NonEmptyString | None = Field(None, description="The subdivision of the meter.")
    triplet: NonEmptyString | None = Field(None, description="The triplet of the meter.")


class MeterVersion(PropertyBase):
    value: NonEmptyList[Meter] = Field(..., description="The meter for this version.")
    dataset_name: NonEmptyString | None = Field(None, description="The dataset of the annotation.")


class MeterSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="meter")

    versions: NonEmptyDict[NonEmptyString, MeterVersion] = Field(
        ...,
        description="A dictionary of versions and their corresponding meter annotations.",
        json_schema_extra={"minItems": 1, "uniqueItems": True},
    )

    _description: str = PrivateAttr(default="Defines the meter found in the file.")
    _revision: int = PrivateAttr(default=2)
