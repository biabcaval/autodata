from typing import Annotated, Self
from uuid import UUID

from pydantic import BeforeValidator, Field, PrivateAttr, model_validator

from musicdata.annotations.models.base import AnnotationObjectBase, PropertyBase, create_model_config
from musicdata.annotations.models.stem_types import validate_stem_types_constraint
from musicdata.db.models.base import _validate_unique_items


class ProbabilityDict(PropertyBase):
    """Dictionary of instrument names to probability values."""

    bass: float = Field(..., ge=0.0, le=1.0, validation_alias="Bass", serialization_alias="Bass")
    drums: float = Field(..., ge=0.0, le=1.0, validation_alias="Drums", serialization_alias="Drums")
    guitars: float = Field(..., ge=0.0, le=1.0, validation_alias="Guitars", serialization_alias="Guitars")
    keys: float = Field(..., ge=0.0, le=1.0, validation_alias="Keys", serialization_alias="Keys")
    percussion: float = Field(..., ge=0.0, le=1.0, validation_alias="Percussion", serialization_alias="Percussion")
    strings: float = Field(..., ge=0.0, le=1.0, validation_alias="Strings", serialization_alias="Strings")
    vocals: float = Field(..., ge=0.0, le=1.0, validation_alias="Vocals", serialization_alias="Vocals")
    wind: float = Field(..., ge=0.0, le=1.0, validation_alias="Wind", serialization_alias="Wind")


class ThresholdDict(PropertyBase):
    """Dictionary of instrument names to threshold values."""

    bass: float = Field(..., ge=0.0, le=1.0, validation_alias="Bass", serialization_alias="Bass")
    drums: float = Field(..., ge=0.0, le=1.0, validation_alias="Drums", serialization_alias="Drums")
    guitars: float = Field(..., ge=0.0, le=1.0, validation_alias="Guitars", serialization_alias="Guitars")
    keys: float = Field(..., ge=0.0, le=1.0, validation_alias="Keys", serialization_alias="Keys")
    percussion: float = Field(..., ge=0.0, le=1.0, validation_alias="Percussion", serialization_alias="Percussion")
    strings: float = Field(..., ge=0.0, le=1.0, validation_alias="Strings", serialization_alias="Strings")
    vocals: float = Field(..., ge=0.0, le=1.0, validation_alias="Vocals", serialization_alias="Vocals")
    wind: float = Field(..., ge=0.0, le=1.0, validation_alias="Wind", serialization_alias="Wind")


class PredictedInfo(PropertyBase):
    probabilities: ProbabilityDict = Field(..., description="Probability scores for each stem type (0.0-1.0)")
    thresholds: ThresholdDict = Field(..., description="Decision thresholds for each stem type (0.0-1.0)")


class PredictedStemTypesSchema(AnnotationObjectBase):
    model_config = create_model_config(
        kind="predicted_stem_types", additional_config={"validate_by_name": True, "validate_by_alias": True}
    )

    stem_types: Annotated[list[UUID], BeforeValidator(_validate_unique_items)] | None = Field(
        None,
        description="An optional array of UUIDs representing stem types.",
        json_schema_extra={"minItems": 1, "uniqueItems": True},
    )
    has_leaks: bool | None = None

    predicted_info: PredictedInfo

    _description: str = PrivateAttr(default="Defines predicted stem types for the file.")
    _revision: int = PrivateAttr(default=1)

    @model_validator(mode="after")
    def _validate_stem_types(self) -> Self:
        """
        Ensure each stem type string is one of the allowed tags declared in
        the constraints JSON for the "stem_types" kind.

        The validation ignores hierarchy and performs a direct ID match.
        """
        if self.stem_types:
            validate_stem_types_constraint(self.stem_types, None)
        return self
