from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    create_model_config,
)

from .transcription import Transcription


class PredictedTranscriptionSchema(AnnotationObjectBase):
    model_config = create_model_config(
        kind="predicted_transcription",
    )

    transcription: list[Transcription] = Field(..., description="The predicted transcription of the audio file.")

    _description: str = PrivateAttr(default="Defines the predicted transcription of the audio file.")
    _revision: int = PrivateAttr(default=1)
