from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    PropertyBase,
    create_model_config,
)
from musicdata.db.models.base import NonEmptyDict, NonEmptyList, NonEmptyString


class Beat(PropertyBase):
    time: float = Field(..., description="The time of the beat in seconds.")
    beat_num: int = Field(
        ..., validation_alias="beatNum", serialization_alias="beatNum", description="The beat event number."
    )


class BeatVersion(PropertyBase):
    value: NonEmptyList[Beat] = Field(..., description="The beat for this version.")
    dataset_name: NonEmptyString | None = Field(None, description="The dataset of the annotation.")


class BeatSchema(AnnotationObjectBase):
    model_config = create_model_config(
        kind="beat",
        additional_config={"validate_by_name": True, "validate_by_alias": True},
    )

    versions: NonEmptyDict[NonEmptyString, BeatVersion] = Field(
        ...,
        description="A dictionary of versions and their corresponding beat annotations.",
        json_schema_extra={"minItems": 1, "uniqueItems": True},
    )

    _description: str = PrivateAttr(default="Defines the beat found in the file.")
    _revision: int = PrivateAttr(default=2)
