from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import AnnotationObjectBase, create_model_config
from musicdata.db.models.base import NonEmptyString


class AdditionalDataSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="additional_data")

    jwe_json: NonEmptyString = Field(..., description="The JWE JSON for the additional data.")

    _description: str = PrivateAttr(default="Defines the additional data found in the file.")
    _revision: int = PrivateAttr(default=2)
