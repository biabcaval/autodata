from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    create_model_config,
)
from musicdata.db.models.base import NonEmptyString


class PostProductionSchema(AnnotationObjectBase):
    model_config = create_model_config(
        kind="post_production",
        extra=None,
        additional_json_schema={"minItems": 1, "uniqueItems": True},
    )

    is_dry: bool | None = Field(None, description="Whether the file is dry or not.")
    dry_versions: list[NonEmptyString] | None = Field(
        None, description="The file IDs of the dry versions of this file."
    )

    _description: str = PrivateAttr(default="Defines the post production details of the file.")
    _revision: int = PrivateAttr(default=1)
