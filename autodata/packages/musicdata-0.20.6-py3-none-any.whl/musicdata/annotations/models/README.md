# Annotation Models Guide

This guide explains how to create new annotation kinds and extend the annotation system.

## Quick Start: Adding a New Annotation Kind

### 1. Create a New Module

Create a new file: `src/musicdata/annotations/models/your_kind.py`

### 2. Choose Your Base Class

**For object-based annotations** (JSON objects with named fields):

```python
from musicdata.annotations.models.base import AnnotationObjectBase
```

**For array-based annotations** (JSON arrays of items):

```python
from musicdata.annotations.models.base import AnnotationArrayBase
```

### 3. Follow the Naming Convention

- **Schema class name MUST end with "Schema"** (e.g., `ChordSchema`, `LyricsSchema`)
- This is how the schema generator automatically discovers your schemas

### 4. Implementation Templates

#### Object-Based Schema Template

```python
from pydantic import Field, PrivateAttr
from musicdata.annotations.models.base import AnnotationObjectBase, PropertyBase, create_model_config

class YourKindSchema(AnnotationObjectBase):
    # Required: model configuration
    model_config = create_model_config(kind="your_kind")

    # Your fields here
    field1: str = Field(..., description="Description of field1")
    field2: int = Field(default=0, description="Description of field2")

    # Required: metadata fields
    _description: str = PrivateAttr(default="Your schema description.")
    _revision: int = PrivateAttr(default=1)
```

#### Array-Based Schema Template

```python
from pydantic import Field, PrivateAttr, model_validator
from typing import Self
from musicdata.annotations.models.base import AnnotationArrayBase, PropertyBase, create_model_config

class YourItem(PropertyBase):
    """Define the structure of individual array items."""
    field1: float = Field(..., description="Description of field1")
    field2: str = Field(..., description="Description of field2")

class YourKindSchema(AnnotationArrayBase[YourItem]):
    # Required: model configuration with extra=None for RootModel
    model_config = create_model_config(kind="your_kind", extra=None)

    # Required: metadata fields
    _description: str = PrivateAttr(default="Your schema description.")
    _revision: int = PrivateAttr(default=1)
```

### 5. Add to AnnotationKindType Enum

Update [`src/musicdata/db/models/base.py`](../../db/models/base.py):

```python
class AnnotationKindType(str, Enum):
    """Valid annotation kinds."""

    ADDITIONAL_DATA = "additional_data"
    BEAT = "beat"
    FILE_DATA = "file_data"
    INSTRUMENT_TAGGING = "instrument_tagging"
    STEM_TYPES = "stem_types"
    YOUR_KIND = "your_kind"  # ← Add this line
```

### 6. Add Import to `__init__.py`

Update [`src/musicdata/annotations/models/__init__.py`](./__init__.py) to make your schema accessible:

```python
from .your_kind import YourKindSchema

__all__ = [
    "AdditionalDataSchema",
    "BeatSchema",
    # ... other schemas ...
    "YourKindSchema",  # ← Add this line
]
```

That's it! The wildcard import in `src/musicdata/annotations/__init__.py` will automatically make your schema available from the top-level annotations package without any additional changes needed.

### 7. Generate Schema

Run the schema generator to create the JSON schema:

```bash
generate-schemas
```

This will create: `src/musicdata/annotations/schema/generated/YourKindSchema_v1.json`

## Advanced Configuration

### Model Configuration Options

```python
model_config = create_model_config(
    kind="your_kind",                          # Required: annotation kind
    extra="forbid",                            # "forbid" (default) or None for RootModel
    additional_config={                        # Optional: extra Pydantic config
        "validate_by_name": True,
        "validate_by_alias": True
    },
    additional_json_schema={                   # Optional: extra JSON schema metadata
        "minItems": 1,
        "uniqueItems": True,
        "title": "Custom Title"
    },
    include_schema=True                        # True (default) for schemas, False for nested models
)
```

### Reusable List Validators

Use the composable validators from `src/musicdata/db/models/base.py`:

```python
from musicdata.db.models.base import NonEmptyList, UniqueList, UniqueNonEmptyList

class MySchema(AnnotationObjectBase):
    tags: NonEmptyList              # Must have ≥1 items
    categories: UniqueList          # No duplicates (can be empty)
    identifiers: UniqueNonEmptyList # Both constraints
```

### Custom Validation

For complex validation logic:

```python
from pydantic import model_validator, field_validator

class MySchema(AnnotationObjectBase):
    # Field-level validation
    @field_validator('my_field')
    @classmethod
    def validate_my_field(cls, v):
        if some_condition:
            raise ValueError("Custom error message")
        return v

    # Model-level validation
    @model_validator(mode='after')
    def validate_model(self):
        # Cross-field validation logic
        return self
```

## Base Classes Explained

### AnnotationObjectBase

- **Use for**: Object-based JSON structures with named fields
- **Inherits**: Enhanced serialization (aliases, None exclusion, UUID conversion)
- **Example JSON**: `{"field1": "value", "field2": 123}`

### AnnotationArrayBase[T]

- **Use for**: Array-based JSON structures
- **Inherits**: Enhanced serialization + RootModel for array validation
- **Example JSON**: `[{"item1": "value"}, {"item2": "value"}]`
- **Important**: Always use `extra=None` in model_config

### PropertyBase

- **Use for**: Nested objects within schemas (not top-level schemas)
- **Inherits**: Enhanced serialization only
- **Configuration**: `create_model_config(extra="forbid", include_schema=False)`

## Required Fields

Every schema MUST define:

1. **`model_config`**: Using `create_model_config()` with appropriate parameters
2. **`_description`**: Human-readable description of the schema
3. **`_revision`**: Version number for schema evolution

## Schema Discovery

The schema generator automatically finds classes by:

- ✅ **Class name ends with "Schema"**
- ✅ **Located in `src/musicdata/annotations/models/`**
- ✅ **Inherits from `AnnotationObjectBase` or `AnnotationArrayBase`**

## Best Practices

1. **Follow naming conventions**: `YourKindSchema`
2. **Use descriptive field descriptions**: Help users understand the data
3. **Start with revision 1**: Increment for breaking changes
4. **Use appropriate base class**: Object vs Array based on JSON structure
5. **Add validation**: Use field validators for business logic
6. **Test your schema**: Validate against real data before deploying
7. **Document breaking changes**: Update revision number and description
