from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    create_model_config,
)
from musicdata.db.models.base import NonEmptyList, NonEmptyString


class GuitarChordSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="guitar_chord")

    key: NonEmptyString | None = Field(default=None, description="The key of the chord.")
    tuning: NonEmptyString | None = Field(default=None, description="The tunning of the guitar.")
    capo: NonEmptyString | None = Field(default=None, description="The capo of the guitar.")
    difficulty: NonEmptyString = Field(..., description="The difficulty of the chord.")
    sequence: NonEmptyList[NonEmptyString] | None = Field(None, description="The sequence of chords.")
    chords_with_lyrics: NonEmptyList[str] = Field(..., description="The chords with lyrics.")

    _description: str = PrivateAttr(default="Defines the guitar chords for the file.")
    _revision: int = PrivateAttr(default=1)
