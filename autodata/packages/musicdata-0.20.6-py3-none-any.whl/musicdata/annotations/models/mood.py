from typing import Annotated, Self

from pydantic import BeforeValidator, PrivateAttr, model_validator

from musicdata.annotations.constraints.runtime import get_flat_allowed_values
from musicdata.annotations.models.base import AnnotationArrayBase, create_model_config
from musicdata.db.models.base import enforce_unique_items


class MoodSchema(AnnotationArrayBase[str]):
    model_config = create_model_config(
        kind="mood", extra=None, additional_json_schema={"minItems": 1, "uniqueItems": True}
    )

    # Override root to add unique enforcement validator
    root: Annotated[list[str], BeforeValidator(enforce_unique_items)]

    _description: str = PrivateAttr(default="Defines the moods found in the file.")
    _revision: int = PrivateAttr(default=1)

    @model_validator(mode="after")
    def _validate_mood_tags(self) -> Self:
        """
        Ensure each mood string is one of the allowed tags declared in
        the constraints JSON for the "mood" kind.

        The validation ignores hierarchy and performs a direct name match.
        If constraints for this kind are missing or invalid, an error is raised.
        """
        # Check for empty array (minItems: 1)
        if not self.root:
            msg = "List must have at least 1 item"
            raise ValueError(msg)

        allowed = get_flat_allowed_values("mood", key="tag", revision=self._revision)
        if not allowed:
            return self

        invalid = [value for value in self.root if value not in allowed]
        if invalid:
            msg = (
                "Invalid mood tag(s): "
                + ", ".join(sorted(set(invalid)))
                + ". Allowed tags are defined in the mood constraints."
            )
            raise ValueError(msg)
        return self


if __name__ == "__main__":
    from musicdata.catalog import CatalogService

    catalog = CatalogService.create()
    mood = MoodSchema(root=["Angry", "Passionate", "Angry"])
    print(mood)
