from typing import Any, Generic, TypeVar
from uuid import UUID

from pydantic import BaseModel, ConfigDict, RootModel
from pydantic.json_schema import JsonSchemaMode


def create_model_config(
    *,
    kind: str | None = None,
    extra: str | None = "forbid",
    additional_json_schema: dict[str, Any] | None = None,
    additional_config: dict[str, Any] | None = None,
    include_schema: bool = True,
) -> ConfigDict:
    """
    Create a model configuration with consistent defaults.

    Args:
        kind: The annotation kind (e.g., 'beat', 'chords', etc.). If provided,
              adds kind to json_schema_extra.
        extra: Pydantic extra validation mode. Use "forbid" for regular models,
               or None for RootModel-based schemas (which don't support extra validation).
        additional_json_schema: Additional JSON schema properties to merge.
        additional_config: Additional ConfigDict properties to merge
                          (e.g., {"validate_by_name": True}).
        include_schema: Whether to include the $schema in json_schema_extra.
                       Set to False for nested objects (PropertyBase).

    Returns:
        ConfigDict: Model configuration

    Examples:
        # For AnnotationObjectBase (object-based schemas)
        create_model_config(kind="beat", extra="forbid")

        # For AnnotationArrayBase (RootModel-based schemas)
        create_model_config(kind="beat", extra=None)  # Explicit: no extra validation

        # For PropertyBase (simple property models - no $schema)
        create_model_config(extra="forbid", include_schema=False)

        # With additional config options
        create_model_config(
            kind="instrument_tagging",
            additional_config={"validate_by_name": True, "validate_by_alias": True}
        )
    """
    json_schema_extra: dict[str, Any] = {
        "additionalProperties": False,
    }

    # Only include $schema for root-level schemas, not nested objects
    if include_schema:
        json_schema_extra["$schema"] = "https://json-schema.org/draft/2020-12/schema"

    if kind:
        json_schema_extra["kind"] = kind

    if additional_json_schema:
        json_schema_extra.update(additional_json_schema)

    config = {
        "validate_assignment": True,
        "json_schema_extra": json_schema_extra,
    }

    # Only add extra if explicitly provided (None means no extra validation)
    if extra is not None:
        config["extra"] = extra

    # Add any additional config options
    if additional_config:
        config.update(additional_config)

    return ConfigDict(**config)


T = TypeVar("T")


def remove_none_and_empty_collections_from_dict(
    obj: Any,  # noqa: ANN401
    *,
    exclude_none: bool = True,
    exclude_empty_collections: bool = True,
) -> Any:  # noqa: ANN401
    """
    Efficiently remove None values and empty collections in a single pass.

    Args:
        obj: The object to process
        exclude_none: Whether to remove None values
        exclude_empty_collections: Whether to remove empty collections

    Returns:
        The processed object with unwanted values removed
    """
    if isinstance(obj, dict):
        result = {}
        for k, v in obj.items():
            # Skip None values if requested
            if exclude_none and v is None:
                continue
            # Skip empty collections if requested
            if exclude_empty_collections and isinstance(v, (list, dict, set, tuple)) and not v:
                continue
            # Recursively process the value
            result[k] = remove_none_and_empty_collections_from_dict(
                v, exclude_none=exclude_none, exclude_empty_collections=exclude_empty_collections
            )
        return result
    if isinstance(obj, list):
        return [
            remove_none_and_empty_collections_from_dict(
                item, exclude_none=exclude_none, exclude_empty_collections=exclude_empty_collections
            )
            for item in obj
        ]
    if isinstance(obj, set):
        return {
            remove_none_and_empty_collections_from_dict(
                item, exclude_none=exclude_none, exclude_empty_collections=exclude_empty_collections
            )
            for item in obj
        }
    if isinstance(obj, tuple):
        return tuple(
            remove_none_and_empty_collections_from_dict(
                item, exclude_none=exclude_none, exclude_empty_collections=exclude_empty_collections
            )
            for item in obj
        )
    return obj


def _process_uuids_to_strings(obj: Any) -> Any:  # noqa: ANN401
    """
    Recursively process an object to convert UUIDs to strings.

    Args:
        obj: The object to process

    Returns:
        The processed object with UUIDs converted to strings
    """
    if isinstance(obj, dict):
        return {k: _process_uuids_to_strings(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_process_uuids_to_strings(item) for item in obj]
    if isinstance(obj, set):
        return {_process_uuids_to_strings(item) for item in obj}
    if isinstance(obj, tuple):
        return tuple(_process_uuids_to_strings(item) for item in obj)
    if isinstance(obj, UUID):
        return str(obj)
    return obj


class JsonSchemaNoNullMixin(BaseModel):
    """
    Mixin that post-processes the JSON Schema generated by Pydantic.

    This mixin modifies the JSON Schema to enforce stricter null handling:
    1. Removes "default": null entries when a field is marked as non-nullable
    2. Simplifies "anyOf" arrays by removing null branches and collapsing single-branch cases
    3. Cleans up schema structure for better readability
    """

    @classmethod
    def model_json_schema(cls, *, mode: JsonSchemaMode = "validation", **kwargs) -> dict[str, Any]:
        """
        Generate and clean the JSON schema for this model.

        Args:
            mode: The schema generation mode (defaults to "validation")
            **kwargs: Additional arguments passed to the parent's model_json_schema

        Returns:
            Dict[str, Any]: The cleaned JSON schema
        """
        schema = super().model_json_schema(mode=mode, **kwargs)
        cls._clean_schema(schema)
        return schema

    @classmethod
    def _clean_schema(cls, obj: Any) -> None:  # noqa: ANN401
        """
        Recursively clean the schema object.

        Args:
            obj: The schema object to clean
        """
        if isinstance(obj, dict):
            cls._clean_dict_schema(obj)
            # Recurse into all dictionary values
            for value in list(obj.values()):
                cls._clean_schema(value)
        elif isinstance(obj, list):
            for item in obj:
                cls._clean_schema(item)

    @classmethod
    def _clean_dict_schema(cls, obj: dict[str, Any]) -> None:
        """
        Clean a dictionary schema node.

        Args:
            obj: The dictionary schema node to clean
        """
        cls._remove_null_defaults(obj)
        cls._process_anyof_entries(obj)

    @staticmethod
    def _remove_null_defaults(obj: dict[str, Any]) -> None:
        """
        Remove "default": null when "nullable": false.

        Args:
            obj: The schema object to clean
        """
        if obj.get("nullable") is False and obj.get("default") is None:
            obj.pop("default")

    @classmethod
    def _process_anyof_entries(cls, obj: dict[str, Any]) -> None:
        """
        Process "anyOf" entries for nodes flagged as non-nullable.

        Args:
            obj: The schema object to process
        """
        if "anyOf" not in obj or obj.get("nullable") is not False:
            return

        anyof_value = obj["anyOf"]
        if isinstance(anyof_value, dict):
            return  # Already collapsed; nothing to do

        if not isinstance(anyof_value, list):
            return

        cls._handle_anyof_list(obj, anyof_value)

    @classmethod
    def _handle_anyof_list(cls, obj: dict[str, Any], anyof_value: list[Any]) -> None:
        """
        Handle the processing of an anyOf list value.

        Args:
            obj: The parent schema object
            anyof_value: The list of anyOf branches
        """
        new_anyof = [
            branch for branch in anyof_value if not (isinstance(branch, dict) and branch.get("type") == "null")
        ]

        if not new_anyof:
            obj.pop("anyOf", None)
            return

        if len(new_anyof) == 1:
            cls._handle_single_branch_anyof(obj, new_anyof[0])
        else:
            obj["anyOf"] = new_anyof

    @classmethod
    def _handle_single_branch_anyof(cls, obj: dict[str, Any], branch: Any) -> None:  # noqa: ANN401
        """
        Handle cases where anyOf has been reduced to a single branch.

        Args:
            obj: The parent schema object
            branch: The single remaining branch
        """
        other_keys = set(obj.keys()) - {"anyOf", "nullable", "default"}

        # Remove the anyOf key and nullable flag
        obj.pop("anyOf", None)
        obj.pop("nullable", None)

        # If there are no other keys (aside from our helper keys) then we can replace the entire object
        # Otherwise, we need to merge the branch with the existing object
        if not other_keys:
            obj.clear()

        # Update the object with the branch content
        if isinstance(branch, dict):
            obj.update(branch)
        else:
            obj["$ref"] = branch


class UUIDStringOnDumpMixin(BaseModel):
    """Provides UUID to String conversion on dump."""

    def model_dump(self, **kwargs) -> dict[str, Any]:
        # Always call super() to chain behavior with other mixins/bases
        data = super().model_dump(**kwargs)
        return _process_uuids_to_strings(data)


class ExcludeNoneAndEmptyCollectionsOnDumpMixin(BaseModel):
    """Efficiently provides exclusion of None values and empty collections in a single pass."""

    def model_dump(self, **kwargs) -> dict[str, Any]:
        # Extract our custom parameters with defaults
        exclude_none = kwargs.pop("exclude_none", True)
        exclude_empty_collections = kwargs.pop("exclude_empty_collections", True)

        # Call super() to continue the chain
        data = super().model_dump(**kwargs)

        # If neither exclusion is needed, return as-is
        if not exclude_none and not exclude_empty_collections:
            return data

        # Single-pass removal for efficiency
        return remove_none_and_empty_collections_from_dict(
            data, exclude_none=exclude_none, exclude_empty_collections=exclude_empty_collections
        )


class AliasOnDumpMixin(BaseModel):
    """Handles the by_alias default (a very small but useful capability)."""

    def model_dump(self, **kwargs) -> dict[str, Any]:
        if "by_alias" not in kwargs:
            kwargs["by_alias"] = True
        return super().model_dump(**kwargs)

    def model_dump_json(self, **kwargs) -> str:
        if "by_alias" not in kwargs:
            kwargs["by_alias"] = True
        return super().model_dump_json(**kwargs)


def _clean_optional_schemas(schema: dict) -> dict:  # noqa: C901, PLR0912
    """
    Clean up JSON schemas by removing null branches from all optional types.

    Transforms any T | None from anyOf[T, null] to just T, where T can be:
    - Scalar types: boolean, number, integer, string
    - Collection types: array, object
    - Any other type

    This allows clean syntax like `field: T | None` while generating
    clean schemas without null branches.
    """
    if not isinstance(schema, dict):
        return schema

    # Process nested schemas recursively
    cleaned = {}
    for key, value in schema.items():
        if key == "properties" and isinstance(value, dict):
            # Process each property
            cleaned[key] = {prop_name: _clean_optional_schemas(prop_schema) for prop_name, prop_schema in value.items()}
        elif key == "anyOf" and isinstance(value, list) and len(value) == 2:  # noqa: PLR2004
            # Check if this is a type + null union pattern
            type_schema = None
            has_null = False

            for item in value:
                if isinstance(item, dict):
                    item_type = item.get("type")
                    if item_type and item_type != "null":
                        type_schema = item
                    elif item_type == "null":
                        has_null = True

            # If we found type + null pattern, replace with just the type
            if type_schema is not None and has_null:
                # Merge any extra properties from the original schema into the type schema
                cleaned_type = _clean_optional_schemas(type_schema.copy())

                # Preserve any additional properties from the original schema (like title, description, etc.)
                for schema_key, schema_value in schema.items():
                    if schema_key not in ("anyOf", "default") and schema_key not in cleaned_type:
                        cleaned_type[schema_key] = schema_value

                return cleaned_type
            # Not our target pattern, process recursively
            cleaned[key] = [_clean_optional_schemas(item) for item in value]
        elif isinstance(value, dict):
            cleaned[key] = _clean_optional_schemas(value)
        elif isinstance(value, list):
            cleaned[key] = [_clean_optional_schemas(item) for item in value]
        else:
            cleaned[key] = value

    # Remove default: null for cleaned schemas since the field won't be in schema if None
    if "anyOf" not in cleaned and cleaned.get("default") is None:
        cleaned.pop("default", None)

    return cleaned


class CleanOptionalSchemasMixin(BaseModel):
    """
    Mixin that automatically cleans JSON schemas to remove null branches from all optional types.

    This allows clean syntax like `field: T | None` while generating schemas without null branches.
    Transforms patterns like:
    - bool | None: anyOf[boolean, null] → boolean
    - int | None: anyOf[integer, null] → integer
    - str | None: anyOf[string, null] → string
    - list[T] | None: anyOf[array, null] → array
    - dict[K, V] | None: anyOf[object, null] → object

    All other schema patterns are preserved unchanged.
    """

    @classmethod
    def model_json_schema(cls, by_alias: bool = True, ref_template: str = "#/$defs/{model}") -> dict:  # noqa: FBT001, FBT002
        """Generate JSON schema with cleaned optional types."""
        schema = super().model_json_schema(by_alias=by_alias, ref_template=ref_template)
        return _clean_optional_schemas(schema)


class EnhancedSerializationModel(
    CleanOptionalSchemasMixin,  # First, clean optional schemas (all types)
    JsonSchemaNoNullMixin,  # Then, apply JSON schema null cleanup
    AliasOnDumpMixin,  # Then, set the alias default
    ExcludeNoneAndEmptyCollectionsOnDumpMixin,  # Then, exclude both None and empty collections in one pass
    UUIDStringOnDumpMixin,  # Finally, convert UUIDs
):
    """
    Base model with enhanced serialization using efficient single-pass exclusion.

    The mixins are applied in a specific order (right to left in MRO):
    1. CleanOptionalSchemasMixin removes null branches from all optional type schemas (schema generation)
    2. JsonSchemaNoNullMixin cleans the JSON schema output (schema generation)
    3. AliasOnDumpMixin sets default by_alias=True (serialization)
    4. ExcludeNoneAndEmptyCollectionsOnDumpMixin removes None values and empty collections in one pass (serialization)
    5. UUIDStringOnDumpMixin converts all UUID instances to strings (serialization)

    This model efficiently combines None and empty collection removal into a single tree traversal
    for optimal performance, while providing the cleanest possible syntax for all optional types.
    """


class PropertyBase(EnhancedSerializationModel):
    """Base class for property-level schema models."""

    model_config = create_model_config(include_schema=False)


class AnnotationObjectBase(EnhancedSerializationModel):
    """
    Base class for annotation schema models that validate objects with named fields.

    Use this when your JSON structure is an object containing multiple fields:
    ```json
    {
        "beat": [...],
        "tempo": 120,
        "metadata": "value"
    }
    ```

    Subclasses must define:
    1. model_config = create_model_config(kind="your_kind")
    2. _description: str = PrivateAttr(default="Your description")
    3. _revision: int = PrivateAttr(default=N)

    Example:
        class BeatSchema(AnnotationObjectBase):
            model_config = create_model_config(kind="beat")

            beat: list[Beat] = Field(...)
            tempo: Optional[float] = Field(None)

            _description: str = PrivateAttr(default="Beat annotations with metadata.")
            _revision: int = PrivateAttr(default=1)
    """


class AnnotationArrayBase(EnhancedSerializationModel, RootModel[list[T]], Generic[T]):
    """
    Base class for annotation schema models that validate arrays directly.

    Use this when your JSON structure is a simple array of annotation items:
    ```json
    [
        {"time": 1.0, "beatNum": 1},
        {"time": 2.0, "beatNum": 2}
    ]
    ```

    This class combines enhanced serialization capabilities with RootModel
    to create annotation schemas that can validate JSON arrays directly.

    Subclasses must define:
    1. Element type in the class declaration (e.g., AnnotationArrayBase[Beat])
    2. model_config = create_model_config(kind="your_kind", extra=None)
    3. _description: str = PrivateAttr(default="Your description")
    4. _revision: int = PrivateAttr(default=N)

    Example:
        class BeatSchema(AnnotationArrayBase[Beat]):
            model_config = create_model_config(kind="beat", extra=None)
            _description: str = PrivateAttr(default="Defines the beat found in the file.")
            _revision: int = PrivateAttr(default=1)
    """
