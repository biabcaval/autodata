from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import AnnotationObjectBase, create_model_config
from musicdata.db.models.base import NonEmptyString


class MediaMetadataSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="media_metadata")

    jwe_json: NonEmptyString = Field(..., description="The JWE JSON for the media metadata.")

    _description: str = PrivateAttr(default="Defines the media metadata for a file.")
    _revision: int = PrivateAttr(default=1)
