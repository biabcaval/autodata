from typing import Annotated

from pydantic import BeforeValidator, Field, PrivateAttr
from pydantic_core import PydanticCustomError

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    PropertyBase,
    create_model_config,
)

ALLOWED_LANGUAGES = frozenset(
    [
        "abkhazian",
        "afar",
        "afrikaans",
        "akan",
        "albanian",
        "amharic",
        "arabic",
        "aragonese",
        "armenian",
        "assamese",
        "avaric",
        "aymara",
        "azerbaijani",
        "bambara",
        "bashkir",
        "basque",
        "belarusian",
        "bengali",
        "bihari",
        "bislama",
        "bosnian",
        "breton",
        "bulgarian",
        "catalan",
        "chechen",
        "chichewa",
        "chinese",
        "church slavonic",
        "chuvash",
        "cornish",
        "corsican",
        "cree",
        "croatian",
        "czech",
        "danish",
        "divehi",
        "dutch",
        "dzongkha",
        "english",
        "esperanto",
        "estonian",
        "ewe",
        "faroese",
        "fijian",
        "finnish",
        "french",
        "fulah",
        "galician",
        "georgian",
        "german",
        "greek",
        "guarani",
        "gujarati",
        "haitian creole",
        "hausa",
        "hawaiian",
        "hebrew",
        "hindi",
        "hungarian",
        "icelandic",
        "igbo",
        "indonesian",
        "interlingua",
        "interlingue",
        "inuktitut",
        "irish",
        "italian",
        "japanese",
        "javanese",
        "javanese",
        "kalaallisut",
        "kannada",
        "kanuri",
        "kashmiri",
        "kazakh",
        "khmer",
        "kikuyu",
        "kinyarwanda",
        "kirundi",
        "komi",
        "kongo",
        "korean",
        "kuanyama",
        "kurdish",
        "kyrgyz",
        "lao",
        "latin",
        "latvian",
        "limburgish",
        "lingala",
        "lithuanian",
        "luba-katanga",
        "luganda",
        "luxembourgish",
        "macedonian",
        "malagasy",
        "malay",
        "malayalam",
        "maltese",
        "maori",
        "marathi",
        "mongolian",
        "myanmar",
        "nauru",
        "navajo",
        "nepali",
        "northern ndebele",
        "northern sami",
        "norwegian bokmål",
        "norwegian",
        "nynorsk",
        "occitan",
        "odia",
        "oromo",
        "ossetian",
        "pali",
        "pashto",
        "persian",
        "polish",
        "portuguese",
        "punjabi",
        "quechua",
        "romanian",
        "romansh",
        "russian",
        "samoan",
        "sango",
        "sanskrit",
        "sardinian",
        "scottish gaelic",
        "serbian",
        "shona",
        "sindhi",
        "sinhala",
        "slovak",
        "slovenian",
        "somali",
        "southern ndebele",
        "southern sotho",
        "spanish",
        "sundanese",
        "swahili",
        "swati",
        "swedish",
        "tagalog",
        "tahitian",
        "tajik",
        "tamil",
        "tatar",
        "telugu",
        "thai",
        "tibetan",
        "tigrinya",
        "tongan",
        "tsonga",
        "tswana",
        "turkish",
        "turkmen",
        "twi",
        "ukrainian",
        "unknown",
        "urdu",
        "uyghur",
        "uzbek",
        "venda",
        "vietnamese",
        "volapük",
        "walloon",
        "welsh",
        "western frisian",
        "wolof",
        "xhosa",
        "yiddish",
        "yoruba",
        "zulu",
    ]
)


def _validate_language(value: str) -> str:
    if not isinstance(value, str) or value not in ALLOWED_LANGUAGES:
        allowed = ", ".join(sorted(ALLOWED_LANGUAGES))
        message = "language must be one of: {allowed}"
        error = PydanticCustomError("invalid_language", message, {"allowed": allowed})
        raise error
    return value


class TranscriptionSyllable(PropertyBase):
    syllable: str = Field(..., description="The syllable text.")
    start: float | None = Field(None, description="The start time of the syllable in seconds.")
    end: float | None = Field(None, description="The end time of the syllable in seconds.")


class TranscriptionWord(PropertyBase):
    word: str = Field(..., description="The transcribed word.")
    start: float | None = Field(None, description="The start time of the word in seconds.")
    end: float | None = Field(None, description="The end time of the word in seconds.")
    score: float | None = Field(None, description="The score of the transcribed word.")
    syllables: list[TranscriptionSyllable] | None = None


class Transcription(PropertyBase):
    text: str = Field(..., description="The transcription text.")
    start: float | None = Field(None, description="The start time of the transcription in seconds.")
    end: float | None = Field(None, description="The end time of the transcription in seconds.")
    language: Annotated[str, BeforeValidator(_validate_language)] | None = Field(
        None,
        description="The language of the transcription (lowercase).",
        json_schema_extra={"enum": list(sorted(ALLOWED_LANGUAGES))},  # noqa: C413
    )
    words: list[TranscriptionWord] | None = None


class TranscriptionSchema(AnnotationObjectBase):
    model_config = create_model_config(
        kind="transcription",
    )

    transcription: list[Transcription] = Field(..., description="The transcription of the audio file.")

    _description: str = PrivateAttr(default="Defines the transcription of the audio file.")
    _revision: int = PrivateAttr(default=1)
