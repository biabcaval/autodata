from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    PropertyBase,
    create_model_config,
)
from musicdata.db.models.base import NonEmptyDict, NonEmptyList, NonEmptyString


class Key(PropertyBase):
    start: float = Field(..., description="The start time of the key in seconds.")
    end: float = Field(..., description="The end time of the key in seconds.")
    key: NonEmptyString = Field(..., description="The key in this segment.")


class KeyVersion(PropertyBase):
    value: NonEmptyList[Key] = Field(..., description="The key for this version.")
    dataset_name: NonEmptyString | None = Field(None, description="The dataset of the annotation.")


class KeySchema(AnnotationObjectBase):
    model_config = create_model_config(kind="key")

    versions: NonEmptyDict[NonEmptyString, KeyVersion] = Field(
        ...,
        description="A dictionary of versions and their corresponding key annotations.",
        json_schema_extra={"minItems": 1, "uniqueItems": True},
    )

    _description: str = PrivateAttr(default="Defines the keys for the file.")
    _revision: int = PrivateAttr(default=2)
