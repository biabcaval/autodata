from pydantic import PrivateAttr

from musicdata.annotations.models.base import AnnotationObjectBase, PropertyBase, create_model_config


class AudioMetadata(PropertyBase):
    lossless: bool
    duration_in_secs: float | None = None
    size_in_bytes: float | None = None
    format: str | None = None
    codec: str | None = None
    bit_rate: float | None = None
    channels: float | None = None
    channel_layout: str | None = None
    sample_rate: float | None = None


class FileDataSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="file_data")

    audio_metadata: AudioMetadata

    _description: str = PrivateAttr(default="Defines the audio metadata for a file.")
    _revision: int = PrivateAttr(default=1)
