from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    PropertyBase,
    create_model_config,
)
from musicdata.db.models.base import NonEmptyDict, NonEmptyList, NonEmptyString


class TagScoreVersion(PropertyBase):
    value: NonEmptyList[dict[NonEmptyString, float]] = Field(..., description="The tag score for this version.")
    dataset_name: NonEmptyString | None = Field(None, description="The dataset of the annotation.")


class TagScoreSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="tag_score")

    versions: NonEmptyDict[NonEmptyString, TagScoreVersion] = Field(
        ...,
        description="A dictionary of versions mapping tag names to confidence scores (0.0-1.0).",
        json_schema_extra={"minProperties": 1},
    )

    _description: str = PrivateAttr(default="Defines the tags for the file.")
    _revision: int = PrivateAttr(default=2)


if __name__ == "__main__":
    tag_score_version = TagScoreVersion(value=[{"tag1": 0.5, "tag2": 0.6}], dataset_name=None)
    tag_schema = TagScoreSchema(versions={"v1": [tag_score_version]})
    print(tag_schema.model_dump())
