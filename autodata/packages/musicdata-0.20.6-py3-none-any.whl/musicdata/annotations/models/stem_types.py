from collections.abc import Collection
from typing import Self
from uuid import UUID

from pydantic import Field, PrivateAttr, model_validator

from musicdata.annotations.constraints.runtime import assert_no_duplicate_values, get_flat_allowed_values
from musicdata.annotations.models.base import AnnotationObjectBase, create_model_config
from musicdata.db.models.base import NonEmptyUUIDs, UniqueList


def validate_stem_types_constraint(stem_types: Collection[UUID], revision: int | None = None) -> None:
    """
    Validate that stem type UUIDs are allowed according to the constraints JSON.

    Args:
        stem_types: Collection of UUID stem types to validate
        revision: The revision number to use for constraints validation

    Raises:
        ValueError: If any stem type ID is not in the allowed list
    """
    # Ensure no duplicate tag names exist in constraints for stem_types
    assert_no_duplicate_values("stem_types", key="tag", revision=revision)

    allowed = get_flat_allowed_values("stem_types", key="id", revision=revision)
    if not allowed:
        return

    # Values in stem_types are UUIDs; compare their string form to the JSON "id" strings
    invalid_ids = [str(value) for value in stem_types if str(value) not in allowed]
    if invalid_ids:
        msg = (
            "Invalid stem type id(s): "
            + ", ".join(sorted(set(invalid_ids)))
            + ". Allowed ids are defined in the stem_types constraints."
        )
        raise ValueError(msg)


class StemTypesSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="stem_types")

    stem_types: NonEmptyUUIDs = Field(
        ...,
        description="A required array of UUIDs representing stem types.",
        json_schema_extra={"minItems": 1, "uniqueItems": True},
    )
    has_leaks: bool | None = None
    mlab_result_ids: UniqueList[UUID] | None = Field(
        default=None,
        description="An array of UUIDs representing the annotation ids of the musiclab annotations.",
        json_schema_extra={"minItems": 1, "uniqueItems": True},
    )

    _description: str = PrivateAttr(default="Defines the stem types found in the file.")
    _revision: int = PrivateAttr(default=2)

    @model_validator(mode="after")
    def _validate_stem_types(self) -> Self:
        """
        Ensure each stem type string is one of the allowed tags declared in
        the constraints JSON for the "stem_types" kind.

        The validation ignores hierarchy and performs a direct ID match.
        """
        validate_stem_types_constraint(self.stem_types, self._revision)
        return self


if __name__ == "__main__":
    from uuid import uuid4

    stem_types = StemTypesSchema(stem_types=[uuid4(), uuid4(), uuid4()])
    print(stem_types)
