from pydantic import Field, PrivateAttr

from musicdata.annotations.models.base import (
    AnnotationObjectBase,
    create_model_config,
)


class PredictedOffsetSchema(AnnotationObjectBase):
    model_config = create_model_config(kind="predicted_offset")

    offset_ms: float = Field(..., description="The offset in milliseconds.")

    _description: str = PrivateAttr(default="Defines the predicted offset of the audio file.")
    _revision: int = PrivateAttr(default=1)


if __name__ == "__main__":
    from musicdata.catalog import CatalogService

    catalog = CatalogService.create()
    predicted_offset = PredictedOffsetSchema(offset_ms=1000)
    print(predicted_offset.model_dump_json(indent=2))
