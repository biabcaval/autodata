from __future__ import annotations

from functools import cache
from typing import TYPE_CHECKING, Any

from loguru import logger

from musicdata.annotations.validators import KindRegistry

if TYPE_CHECKING:
    from collections.abc import Iterable


def _iter_values_for_key(node: Any, key: str) -> Iterable[str]:  # noqa: ANN401
    """
    Recursively yield all string values for a given key from a constraints
    node structure.

    The expected structure is a dict with optional arbitrary key (str) and
    optional "subtags" (list) containing the same shape recursively.
    """
    if isinstance(node, dict):
        value = node.get(key)
        if isinstance(value, str):
            yield value
        for child in node.get("subtags", []) or []:
            yield from _iter_values_for_key(child, key)
    elif isinstance(node, list):
        for item in node:
            yield from _iter_values_for_key(item, key)


@cache
def _load_constraints_for_kind(kind: str, revision: int | None = None) -> dict[str, Any] | None:
    """
    Load the constraints object for a given annotation kind from the database via
    the KindRegistry cache. Returns None if not found or invalid.

    When revision is None, the latest revision is used. Results are cached per
    (kind, revision) tuple.
    """
    # Prefer DB-backed constraints via KindRegistry; require cache population by caller
    compiled = KindRegistry.get_kind_by_name(kind, revision)
    constraints_obj = getattr(compiled, "constraints", None)
    if isinstance(constraints_obj, dict):
        return constraints_obj
    # If we reach here, constraints are missing for a kind that requires checks
    rev_msg = " (revision=" + str(compiled.revision) + ")" if hasattr(compiled, "revision") else ""
    msg = "Constraints not found or invalid for kind '" + str(kind) + "'" + rev_msg
    raise ValueError(msg)


@cache
def get_flat_allowed_values(kind: str, *, key: str = "tag", revision: int | None = None) -> frozenset[str]:
    """
    Return a cached frozenset of all allowed string values for the provided
    key within the tag hierarchy of a given kind.

    The function flattens the hierarchy under "constraints.tags", returning
    every value found for the provided key (e.g., "tag", "id"). If constraints
    are missing or invalid, raises a ValueError to avoid silent failures.
    """
    constraints_obj = _load_constraints_for_kind(kind, revision)
    if not constraints_obj:
        raise ValueError("Constraints for kind '" + kind + "' not found or invalid")
    tags_section = constraints_obj.get("tags", [])
    return _unique_values_or_error(_iter_values_for_key(tags_section, key), kind=kind, key=key)


@cache
def assert_no_duplicate_values(kind: str, *, key: str = "tag", revision: int | None = None) -> None:
    """
    Assert that there are no duplicate values for the given key in the
    constraints tree of the specified kind. Raises ValueError on duplicates.
    """
    constraints_obj = _load_constraints_for_kind(kind, revision)
    if not constraints_obj:
        raise ValueError("Constraints for kind '" + kind + "' not found or invalid")
    tags_section = constraints_obj.get("tags", [])
    # Reuse the same uniqueness check; discard the returned set
    _unique_values_or_error(_iter_values_for_key(tags_section, key), kind=kind, key=key)


def _unique_values_or_error(values: Iterable[str], *, kind: str, key: str) -> frozenset[str]:
    """
    Ensure the provided values are unique; return a frozenset of unique values
    or raise ValueError if duplicates are found.
    """
    seen: set[str] = set()
    duplicates: set[str] = set()
    for value in values:
        if value in seen:
            duplicates.add(value)
        else:
            seen.add(value)

    if duplicates:
        logger.warning(f"Duplicate {key} values found in '{kind}' constraints: {', '.join(sorted(duplicates))}")
        raise ValueError("Duplicate " + key + " values in '" + kind + "' constraints: " + ", ".join(sorted(duplicates)))

    return frozenset(seen)
