def migrate_stem_types_v1_to_v2(data_v1: dict) -> dict:
    """
    Migrates StemTypes data from schema revision 1 to revision 2.
    """
    data_v2 = data_v1
    return data_v2


if __name__ == "__main__":
    sample_v1_data = {
        "stem_types": [
            "8cab6442-1315-44ad-b0c6-c695b3a8d847",
            "485d099b-000c-417f-8605-ea3d6eb68a84",
            "2483d28c-0fed-4bf6-9652-73753aac59be",
        ]
    }
    migrated_data = migrate_stem_types_v1_to_v2(sample_v1_data)
    print("Migrated data (v2 format):")
    import orjson

    print(orjson.dumps(migrated_data, option=orjson.OPT_INDENT_2).decode())

    from musicdata.annotations.models.stem_types import StemTypesSchema

    try:
        stem_types_v2_object = StemTypesSchema.model_validate(migrated_data)
        print("\nSuccessfully validated with Pydantic v2 model:")
        print(stem_types_v2_object.model_dump_json(indent=2))
    except Exception as e:
        print(f"\nError validating with Pydantic v2 model: {e}")
