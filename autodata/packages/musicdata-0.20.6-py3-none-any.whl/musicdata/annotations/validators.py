import threading
from collections.abc import Collection
from pathlib import Path
from typing import Any, ClassVar, cast
from uuid import UUID

import orjson
from jsonschema import Draft202012Validator, ValidationError
from jsonschema.protocols import Validator
from loguru import logger
from pydantic import ConfigDict
from pydantic import ValidationError as PydanticValidationError
from referencing import Registry
from sqlalchemy import text
from sqlalchemy.engine import Connectable
from sqlalchemy.exc import SQLAlchemyError

from musicdata.db.db_core import execute_statement
from musicdata.db.models.base import AnnotationKind, AnnotationKindType


class ValidationBaseError(ValueError):
    """Base exception class for all validation-related errors."""


class SchemaValidationError(ValidationBaseError):
    """Exception raised for schema validation errors."""


class KindNotFoundError(ValidationBaseError):
    """Exception raised when a schema cannot be found."""


class UnsupportedSchemaError(ValidationBaseError):
    """Exception raised when a schema version is not supported."""


class CompiledKindSchema(AnnotationKind):
    """
    A wrapper that holds an AnnotationKind instance along with its compiled validator.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)
    validator: Validator


class KindRegistry:
    """
    Manages JSON schema validation of kind schemas for annotations.

    This class handles the compilation, caching, and validation of annotation kinds.
    It provides methods to validate JSON values against a kind's schema, retrieve kinds by ID
    or name, and manage the kind cache.

    Usage:
        # Initialize once with a database connection
        KindRegistry.initialize(engine)

        # Then use any method - cache is populated automatically on first access
        kind = KindRegistry.get_kind_by_name("stem_types")

    The kind cache is shared across all instances of this class.
    Most methods are class methods since they operate on the shared cache.

    THREAD SAFETY NOTE:
    This implementation is optimized for a "populate once, read many" pattern:
    1. Call initialize() from the main thread with a database connection
    2. Cache is populated lazily on first access
    3. After population, the cache becomes effectively read-only
    4. Multiple threads can safely read from the cache concurrently
    """

    # Class-level cache shared across all instances
    _compiled_validators: ClassVar[dict[UUID, CompiledKindSchema]] = {}

    # Name-based cache for O(1) lookups by kind type and revision
    _kinds_by_name: ClassVar[dict[str, dict[int, CompiledKindSchema]]] = {}

    # Flag to indicate if the cache has been populated
    _cache_populated: ClassVar[bool] = False

    # Minimal lock used only during cache population
    _init_lock: ClassVar[threading.RLock] = threading.RLock()

    # Database connection for lazy loading
    _connectable: ClassVar[Connectable | None] = None

    @classmethod
    def initialize(cls, connectable: Connectable) -> None:
        """
        Initialize the registry with a database connection.

        This method stores the connection for lazy cache population. The cache
        will be populated automatically on first access to any query method.

        Args:
            connectable: The database engine or connection.
        """
        cls._connectable = connectable

    @classmethod
    def _ensure_loaded(cls) -> None:
        """
        Ensure the cache is populated, loading from database if necessary.

        Raises:
            KindNotFoundError: If initialize() has not been called.
        """
        if cls._cache_populated:
            return

        if cls._connectable is None:
            msg = "KindRegistry not initialized. Call KindRegistry.initialize(connectable) first."
            raise KindNotFoundError(msg)

        cls._populate_cache(cls._connectable)

    @staticmethod
    def _detect_validator_from_schema(json_schema: dict[str, Any]) -> type[Validator]:
        """
        Automatically detect the appropriate validator subclass from the "$schema" keyword
        in the json_schema definition.

        Args:
            json_schema: The JSON schema dictionary.

        Returns:
            A validator subclass.

        Raises:
            UnsupportedSchemaError: If the schema version is not supported.
        """
        schema_url = json_schema.get("$schema", "")
        if "2020-12" in schema_url:
            return cast("type[Validator]", Draft202012Validator)

        error_msg = f"Unsupported JSON Schema draft: {schema_url}"
        raise UnsupportedSchemaError(error_msg)

    @classmethod
    def _compile_validator(cls, json_schema: dict[str, Any]) -> Validator:
        """
        Given a json_schema, select and compile the correct validator.

        This implementation first attempts to auto-detect the JSON Schema draft version
        from the JSON itself via the "$schema" field.

        Args:
            json_schema: The JSON schema dictionary.

        Returns:
            A compiled instance of the validator.
        """
        validator_cls = cls._detect_validator_from_schema(json_schema)
        return validator_cls(json_schema, registry=Registry())

    @classmethod
    def _get_schema(cls, kind_id: UUID) -> CompiledKindSchema:
        """
        Retrieve the compiled kind schema for a given kind_id.

        This method checks the cache for the kind; if not found, it raises an error.
        Thread-safe for concurrent reads after cache population.

        Args:
            kind_id: The UUID of the desired annotation kind.

        Returns:
            A CompiledKindSchema object.

        Raises:
            KindNotFoundError: If no kind is found for the given ID.
        """
        cls._ensure_loaded()

        if kind_id in cls._compiled_validators:
            return cls._compiled_validators[kind_id]

        error_msg = f"No kind found for kind_id: {kind_id}"
        raise KindNotFoundError(error_msg)

    @classmethod
    def validate_value(cls, value: dict[str, Any] | list[Any], kind_id: UUID) -> dict[str, Any] | list[Any]:
        """
        Validate a JSON value against the schema of the annotation kind identified by kind_id.

        The method retrieves the compiled validator from the cache and applies it
        on the provided value. Thread-safe for concurrent validations.

        Args:
            value: The JSON value to validate.
            kind_id: The UUID of the annotation kind to use.

        Returns:
            The original value if validation passes.

        Raises:
            SchemaNotFoundError: If no schema is found for the given ID.
            SchemaValidationError: If the value fails validation.
        """
        compiled_kind_schema = cls._get_schema(kind_id)

        try:
            compiled_kind_schema.validator.validate(value)
        except ValidationError as e:
            error_msg = cls._format_validation_error(e)
            raise SchemaValidationError(error_msg) from e

        return value

    @classmethod
    def _format_validation_error(cls, error: ValidationError) -> str:
        """
        Format a jsonschema ValidationError into a concise, readable message.

        The default string representation of ValidationError includes the entire JSON schema,
        which can be extremely verbose. This method extracts just the essential error information:
        the message and the path to the failing property.

        Args:
            error: The jsonschema ValidationError to format.

        Returns:
            A concise error message without the full schema.
        """
        # The error.message already contains a human-readable description
        message = error.message

        # Add path context if available (helps locate the issue in nested structures)
        if error.path:
            path = ".".join(str(p) for p in error.path)
            return f"{message} (at path: {path})"

        # For root-level errors, just return the message
        return message

    @classmethod
    def _register_kind(cls, annotation_kind: AnnotationKind) -> None:
        """
        Register an annotation kind (and its cached validator) into memory.

        This method should only be called during initial cache population.
        Not thread-safe for concurrent modifications.

        Args:
            annotation_kind: An object representing the annotation kind with attributes
                              'id', 'json_schema', and 'revision'.

        Warning:
            This method is not thread-safe. It should only be called from the main thread
            during initial cache population, before any worker threads are started.
        """
        if cls._cache_populated:
            logger.warning(
                "Adding to cache after it has been marked as populated. "
                "This may cause thread safety issues if other threads are reading from the cache."
            )

        # Cast NonEmptyJson to dict - annotation schemas are always dictionaries, never lists
        json_schema = cast("dict[str, Any]", annotation_kind.json_schema)
        validator = cls._compile_validator(json_schema)
        compiled_kind_schema = CompiledKindSchema(
            **annotation_kind.model_dump(),
            validator=validator,
        )
        # Populate UUID-based cache
        cls._compiled_validators[annotation_kind.id] = compiled_kind_schema

        # Populate name-based cache
        kind_type = annotation_kind.kind
        if kind_type not in cls._kinds_by_name:
            cls._kinds_by_name[kind_type] = {}
        cls._kinds_by_name[kind_type][annotation_kind.revision] = compiled_kind_schema

    @staticmethod
    def _fetch_all_kinds_from_db(connectable: Connectable) -> list[Any]:
        """
        Fetch all annotation kinds from the database using the provided engine or connection.

        Args:
            connectable: The database engine or connection.

        Returns:
            A list of annotation kind objects.

        Raises:
            SQLAlchemyError: If there's an error fetching kinds from the database.
        """
        try:
            results = list(execute_statement(connectable, text("SELECT * FROM annotation_kinds")))
            if not results:
                logger.warning("No annotation kinds found in the database")
        except SQLAlchemyError:
            logger.exception("Database error while fetching annotation kinds")
            raise

        return results

    @classmethod
    def _populate_cache(cls, connectable: Connectable) -> None:
        """
        Fetch all annotation kinds and cache their compiled validators.

        Internal method called automatically on first access. Thread-safe.

        Args:
            connectable: The database engine or connection.
        """
        # Use a lock to ensure only one thread populates the cache
        with cls._init_lock:
            # Check if cache is already populated
            if cls._cache_populated:
                logger.debug("Cache already populated, skipping")
                return

            # Fetch kinds
            kinds = cls._fetch_all_kinds_from_db(connectable)

            # Clear any existing entries (just in case)
            cls._compiled_validators.clear()
            cls._kinds_by_name.clear()

            # Compile validators and populate caches
            for annotation_kind in kinds:
                try:
                    json_schema: dict[str, Any] = annotation_kind.json_schema
                    validator = cls._compile_validator(json_schema)
                    compiled_kind_schema = CompiledKindSchema(**annotation_kind._asdict(), validator=validator)

                    # Populate UUID-based cache
                    cls._compiled_validators[annotation_kind.id] = compiled_kind_schema

                    # Populate name-based cache
                    kind_type = annotation_kind.kind
                    if kind_type not in cls._kinds_by_name:
                        cls._kinds_by_name[kind_type] = {}
                    cls._kinds_by_name[kind_type][annotation_kind.revision] = compiled_kind_schema

                except PydanticValidationError:
                    logger.warning(
                        f"Skipping an unsupported annotation kind from the database "
                        f"(kind={getattr(annotation_kind, 'kind', 'N/A')}, "
                        f"revision={getattr(annotation_kind, 'revision', 'N/A')})"
                    )

            # Mark cache as populated - after this point, the cache is effectively read-only
            cls._cache_populated = True
            logger.info(f"Kind cache populated with {len(cls._compiled_validators)} kinds")

    @classmethod
    def get_kind_by_id(cls, kind_id: UUID) -> CompiledKindSchema:
        """
        Retrieve the compiled annotation kind for a given kind id.
        """
        cls._ensure_loaded()
        return cls._compiled_validators[kind_id]

    @classmethod
    def get_kind_by_name(
        cls,
        kind_name: AnnotationKindType | str,
        revision: int | None = None,
    ) -> CompiledKindSchema:
        """
        Retrieve the compiled annotation kind for a given kind name.

        By default, the latest revision is returned. This method uses an O(1)
        name-based cache for efficient lookups.

        Args:
            kind_name: The annotation kind to retrieve (can be an AnnotationKindType enum or a string).
            revision: Optional specific revision to retrieve. If None, returns the latest.

        Returns:
            The requested annotation kind.

        Raises:
            KindNotFoundError: If no record is found for the given kind name.
            ValueError: If kind_name is a string and not a valid AnnotationKindType.
        """
        cls._ensure_loaded()

        actual_kind: AnnotationKindType
        if isinstance(kind_name, str):
            try:
                actual_kind = AnnotationKindType[kind_name.upper()]
            except KeyError:
                error_msg = (
                    f"Invalid kind_name string: '{kind_name}'. Valid values are: {[e.name for e in AnnotationKindType]}"
                )
                raise ValueError(error_msg) from None
        else:
            actual_kind = kind_name  # pyright: ignore[reportUnreachable]

        # Use O(1) name-based cache lookup
        revision_schemas = cls._kinds_by_name.get(actual_kind)

        if not revision_schemas:
            error_msg = f"No kind found in db with name '{actual_kind}'"
            raise KindNotFoundError(error_msg)

        # Return requested revision or latest
        if revision is not None:
            if revision not in revision_schemas:
                error_msg = f"No kind found with name '{actual_kind}' and revision {revision}"
                raise KindNotFoundError(error_msg)
            return revision_schemas[revision]

        return revision_schemas[max(revision_schemas.keys())]

    @classmethod
    def get_all_kind_names(cls) -> list[str]:
        """
        Get all annotation kind names that have cached schemas.

        Returns:
            List of kind name strings present in the cache.
        """
        cls._ensure_loaded()
        return list(cls._kinds_by_name.keys())

    @classmethod
    def _clear_cache(cls) -> None:
        """
        Clear the kind cache.

        Internal method for testing purposes.
        """
        cls._compiled_validators.clear()
        cls._kinds_by_name.clear()
        cls._cache_populated = False
        cls._connectable = None


class StemTypeRegistry:
    """Registry for stem type constraint data.

    This class manages loading and caching of stem type mappings from the
    stem_types_constraints.json constraint file. All methods are class methods since
    the functionality is stateless aside from caching.

    The registry loads stem type definitions from the local constraints file and provides
    methods to query and map stem type names to their UUID identifiers. It is
    completely standalone and requires no database connection.

    Cache population is handled automatically on first access - no manual initialization
    is required. Thread-safe for read operations.
    """

    # Class-level cache for stem type mapping (shared across all uses)
    _cache: ClassVar[dict[str, UUID] | None] = None
    _reverse_cache: ClassVar[dict[UUID, str] | None] = None

    @staticmethod
    def _get_constraints_file() -> Path:
        """Get the stem types constraints file path.

        Returns:
            Path to the stem_types_constraints.json file

        Raises:
            FileNotFoundError: If the constraints file is not found
        """
        # Get the constraints directory relative to this file
        # validators.py is in src/musicdata/annotations/
        # We need to go to src/musicdata/annotations/constraints/
        constraints_file = Path(__file__).parent / "constraints" / "stem_types_constraints.json"

        if not constraints_file.exists():
            msg = f"Stem types constraints file not found at {constraints_file}"
            raise FileNotFoundError(msg)

        logger.debug(f"Using stem types constraints file: {constraints_file}")
        return constraints_file

    @staticmethod
    def _extract_tags_recursively(tags_list: list[dict]) -> dict[str, UUID]:
        """Recursively extract all tags from the hierarchy into a flat dict.

        Args:
            tags_list: List of tag dictionaries with 'tag', 'id', and optional 'subtags'

        Returns:
            Dictionary mapping tag names to UUIDs
        """
        mapping = {}

        for tag_item in tags_list:
            tag_name = tag_item.get("tag")
            tag_id = tag_item.get("id")

            if tag_name and tag_id:
                # Add this tag to the mapping
                mapping[tag_name] = UUID(tag_id)

            # Recursively process subtags if they exist
            subtags = tag_item.get("subtags", [])
            if subtags:
                sub_mapping = StemTypeRegistry._extract_tags_recursively(subtags)
                mapping.update(sub_mapping)

        return mapping

    @classmethod
    def _ensure_loaded(cls) -> dict[str, UUID]:
        """Ensure the stem type cache is populated, loading if necessary.

        Returns:
            Dictionary mapping stem type names to their UUIDs

        Raises:
            FileNotFoundError: If the constraints file is not found
            ValueError: If the constraints file is malformed
        """
        if cls._cache is not None:
            return cls._cache

        constraints_file = cls._get_constraints_file()

        with constraints_file.open("rb") as f:
            constraints_data = orjson.loads(f.read())

        # Extract constraints.tags
        constraints = constraints_data.get("constraints", {})
        tags_list = constraints.get("tags", [])

        if not tags_list:
            msg = f"No tags found in constraints section of {constraints_file}"
            raise ValueError(msg)

        # Recursively extract all tags
        mapping = cls._extract_tags_recursively(tags_list)
        logger.info(f"Loaded {len(mapping)} stem types from {constraints_file.name}")

        # Cache the mapping and build reverse cache
        cls._cache = mapping
        cls._reverse_cache = {uuid: name for name, uuid in mapping.items()}

        return mapping

    @classmethod
    def get_all(cls) -> dict[str, UUID]:
        """Get all available stem types.

        Returns:
            Dictionary mapping stem type names to their UUIDs

        Example:
            >>> from musicdata.annotations.validators import StemTypeRegistry
            >>> all_types = StemTypeRegistry.get_all()
            >>> print(list(all_types.keys())[:5])
        """
        return cls._ensure_loaded()

    @classmethod
    def is_valid_stem_name(cls, stem_name: str) -> bool:
        """Check if a stem name is valid according to the registry.

        Args:
            stem_name: The stem name to validate

        Returns:
            True if the stem name exists in the registry, False otherwise

        Example:
            >>> from musicdata.annotations.validators import StemTypeRegistry
            >>> StemTypeRegistry.is_valid_stem_name('Drums')
            True
            >>> StemTypeRegistry.is_valid_stem_name('InvalidStem')
            False
        """
        return stem_name in cls._ensure_loaded()

    @classmethod
    def map_names_to_ids(cls, stem_names: Collection[str], *, strict: bool = True) -> set[UUID]:
        """Map stem names to their corresponding stem IDs.

        Args:
            stem_names: Collection of stem names to map
            strict: If True, raise exception for unknown stem names.
                   If False, log warning and skip unknown names.

        Returns:
            Set of stem IDs corresponding to the input stem names

        Raises:
            ValueError: If strict=True and unknown stem names are found

        Example:
            >>> from musicdata.annotations.validators import StemTypeRegistry
            >>> stem_ids = StemTypeRegistry.map_names_to_ids(['Drums', 'Vocals', 'Bass'])
            >>> print(f"Mapped to {len(stem_ids)} UUIDs")
        """
        stem_type_mapping = cls._ensure_loaded()
        stem_ids = set()
        unknown_stems = []

        for stem_name in stem_names:
            if stem_name in stem_type_mapping:
                stem_ids.add(stem_type_mapping[stem_name])
            else:
                unknown_stems.append(stem_name)

        if unknown_stems:
            if strict:
                msg = f"Unknown stem names found: {unknown_stems}"
                raise ValueError(msg)
            logger.warning(f"Skipping unknown stem names: {unknown_stems}")

        return stem_ids

    @classmethod
    def map_ids_to_names(cls, stem_ids: Collection[UUID], *, strict: bool = True) -> dict[UUID, str]:
        """Map stem IDs to their corresponding stem names.

        Args:
            stem_ids: Collection of stem UUIDs to map
            strict: If True, raise exception for unknown stem IDs.
                   If False, log warning and skip unknown IDs.

        Returns:
            Dictionary mapping stem IDs to their corresponding names

        Raises:
            ValueError: If strict=True and unknown stem IDs are found

        Example:
            >>> from musicdata.annotations.validators import StemTypeRegistry
            >>> from uuid import UUID
            >>> stem_names = StemTypeRegistry.map_ids_to_names([UUID('...')])
            >>> print(stem_names)
        """
        cls._ensure_loaded()

        if cls._reverse_cache is None:
            msg = "Reverse cache not initialized"
            raise RuntimeError(msg)

        result: dict[UUID, str] = {}
        unknown_ids: list[UUID] = []

        for stem_id in stem_ids:
            if stem_id in cls._reverse_cache:
                result[stem_id] = cls._reverse_cache[stem_id]
            else:
                unknown_ids.append(stem_id)

        if unknown_ids:
            if strict:
                msg = f"Unknown stem IDs found: {unknown_ids}"
                raise ValueError(msg)
            logger.warning(f"Skipping unknown stem IDs: {unknown_ids}")

        return result

    @classmethod
    def _clear_cache(cls) -> None:
        """Clear the class-level stem type cache.

        Internal method for testing purposes.
        """
        cls._cache = None
        cls._reverse_cache = None
