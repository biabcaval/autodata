from __future__ import annotations

import base64
import binascii
import os
from contextlib import contextmanager
from typing import TYPE_CHECKING
from urllib.parse import unquote

from google.api_core.exceptions import NotFound
from google.cloud.storage import Blob, Client
from joblib import Parallel, delayed
from loguru import logger

from musicdata.utils.concurrency import ParallelOperationType, get_max_workers

if TYPE_CHECKING:
    from collections.abc import Collection, Generator
    from pathlib import Path

    from google.cloud.storage.bucket import Bucket

_storage_client: Client | None = None


def _get_storage_client() -> Client:
    """Get or create the default storage client (lazy initialization)."""
    global _storage_client  # noqa: PLW0603
    if _storage_client is None:
        _storage_client = Client()
    return _storage_client


class BlobNotFoundError(Exception):
    """Raised when a blob does not exist."""


class BlobExt(Blob):
    """An extended version of the Blob class from the google-cloud-storage library."""

    def __init__(
        self,
        bucket_name: str,
        name: Path | str,
        client: Client | None = None,
    ) -> None:
        if client is None:
            client = _get_storage_client()
        super().__init__(str(name), client.bucket(bucket_name))

        if self.name is None or not isinstance(self.name, str):
            msg = "Blob name cannot be None."
            raise ValueError(msg)

        self.file_name = self.name.split("/")[-1]
        self.dir_path = self.name.rpartition("/")[0]
        self.uri_without_gs = f"{bucket_name}/{self.name}"
        self.uri = f"gs://{self.uri_without_gs}"

    @classmethod
    def from_uri(cls, uri: str) -> BlobExt:  # pyrefly: ignore[bad-override]
        """Creates a BlobExt object from a blob URI.

        Accepts URIs in the following formats:
            - `bucket-name/path/to/blob/file.txt`
            - `gs://bucket-name/path/to/blob/file.txt`
        """
        args = cls._parse_blob_uri(uri)
        return cls(*args)

    @classmethod
    def from_blob(cls, blob: Blob) -> BlobExt:
        """Creates a BlobExt object from a Blob object."""
        if blob.name is None:
            msg = "Blob name cannot be None."
            raise ValueError(msg)
        return cls(blob.bucket.name, blob.name)

    @staticmethod
    def _parse_blob_uri(blob_path: str) -> tuple[str, str]:
        """Parses a blob URI into its bucket name and blob name (path without bucket).

        :param blob_path: The URI of the blob, starting with the bucket. E.g.:
            - `bucket-name/path/to/blob/file.txt`
            - `gs://bucket-name/path/to/blob/file.txt`
        """
        if blob_path.startswith("gs://"):
            blob_path = blob_path.replace("gs://", "")
        split_path = blob_path.lstrip("/").split("/")
        bucket_name = split_path[0]
        blob_name = "/".join(split_path[1:])
        return bucket_name, blob_name

    @property
    def md5_hash_decoded(self) -> str:
        """Returns the MD5 hash of the blob."""
        if self.md5_hash is None:
            self.reload()
        if self.md5_hash is None:
            msg = f"MD5 hash not found for {self.uri}, check if blob exists."
            raise FileNotFoundError(msg)

        # Decode the base64-encoded MD5 hash to get the raw bytes
        md5_bytes = base64.b64decode(self.md5_hash)

        # Convert the raw bytes to a hexadecimal string
        return binascii.hexlify(md5_bytes).decode("utf-8")

    def __repr__(self) -> str:
        return f'<{self.__class__.__name__}("{self.bucket.name}", "{self.name}")>'


def get_sa_storage_client() -> Client:
    """Returns a storage client authenticated with a service account."""
    if sa_key_file := os.getenv("GOOGLE_APPLICATION_CREDENTIALS"):
        return Client.from_service_account_json(sa_key_file)  # pyrefly: ignore[bad-return]

    msg = "Env variable GOOGLE_APPLICATION_CREDENTIALS is not set."
    raise OSError(msg)


def upload_directory_to_bucket(
    bucket_name: str,
    local_directory_path: str,
    gcs_path: str,
) -> None:
    """Uploads a directory to the bucket."""
    for local_file in os.listdir(local_directory_path):
        if not os.path.isfile(os.path.join(local_directory_path, local_file)):
            upload_directory_to_bucket(
                bucket_name,
                os.path.join(local_directory_path, local_file),
                f"{gcs_path}/{local_file}",
            )
        else:
            local_file_path = os.path.join(local_directory_path, local_file)
            blob = f"{gcs_path}/{local_file}"

            BlobExt(bucket_name, blob).upload_from_filename(local_file_path)


def copy_between_buckets(source_blob_uri: str, bucket: str, name: str) -> BlobExt:
    """Copies a file from one bucket to another and returns the copied Blob.
    This is a server-side operation.
    """
    source_blob_info = BlobExt.from_uri(source_blob_uri)
    target_bucket = _get_storage_client().bucket(bucket)
    target_blob = target_bucket.copy_blob(source_blob_info, target_bucket, name)

    logger.debug("File {} copied to gs://{}/{}.", source_blob_uri, bucket, name)
    return BlobExt.from_blob(target_blob)


def list_blobs(
    bucket_name: str,
    prefix: str | None = None,
    *,
    ignore_folders: bool | None = True,
    **kwargs,
) -> list[Blob]:
    """Lists all the blobs in the bucket that begin with the prefix.

    Make sure to include a trailing slash in the prefix or use `list_blobs_in_folder()`
    if only interested in blobs that are inside the specified prefix, otherwise the
    API will also return partial matches.
    """
    blobs = list(_get_storage_client().list_blobs(bucket_name, prefix=prefix, **kwargs))
    if ignore_folders:
        blobs = [blob for blob in blobs if blob.name and not blob.name.endswith("/")]
    return blobs  # pyrefly: ignore[bad-return]


def list_blobs_in_folder(
    bucket_name: str,
    folder_path: str,
    *,
    ignore_folders: bool | None = True,
    **kwargs: dict,
) -> list[Blob]:
    """List all blobs inside a folder in a bucket.

    Use `delimiter="/"` to only list files within the specified folder.

    Wraps `list_blobs()` to make sure the path always includes a trailing '/'. This
    avoids mistakenly returning files with the same name pattern.
    """
    # Make sure the folder_name ends with a '/'
    if not folder_path.endswith("/"):
        folder_path += "/"
    return list_blobs(
        bucket_name,
        prefix=folder_path,
        ignore_folders=ignore_folders,
        **kwargs,
    )


def gcs_listdir(bucket_name: str, prefix: str = "") -> list[str]:
    """
    List all blobs and folders directly inside a GCS path.

    :param bucket_name: Name of the GCS bucket.
    :param prefix: Path within the bucket (without leading or trailing slash).
    :return: List of files and folders in the specified path.
    """
    bucket = _get_storage_client().bucket(bucket_name)

    # Ensure the prefix ends with a '/' if not empty and not already ending with '/'
    if prefix and not prefix.endswith("/"):
        prefix += "/"

    # List blobs with the given prefix and delimiter - this is like listing a directory
    iterator = bucket.list_blobs(prefix=prefix, delimiter="/")
    blobs = list(iterator)

    # Folders (prefixes) are provided in iterator.prefixes
    folders = list(iterator.prefixes)

    # Extract the names relative to the prefix
    files = [blob.name for blob in blobs if not blob.name.endswith("/")]

    return files + folders


def signed_url_to_blob_uri(signed_url: str) -> str:
    """Converts a signed URL to a blob URI.

    The signed URL is of the form: `https://storage.googleapis.com/my-bucket/my-object?...`

    Returns:
        A blob URI of the form: `gs://my-bucket/my-object`

    """
    # Remove query parameters
    url_without_query = signed_url.split("?")[0]

    # Split the URL into components
    components = url_without_query.split("/")

    # The bucket name is the 4th component
    bucket_name = components[3]

    # The object name is everything after the 4th component
    object_name = unquote("/".join(components[4:]))

    return f"gs://{bucket_name}/{object_name}"


def get_blobs_md5_bulk(file_paths: Collection[str], max_workers_override: int | None = None) -> dict[str, str]:
    """Fetch MD5 hashes for multiple blobs in parallel."""
    if not file_paths:
        return {}

    def _fetch_single_md5(path: str) -> tuple[str, str | None]:
        try:
            # BlobExt.md5_hash_decoded calls reload() if needed
            return path, BlobExt.from_uri(path).md5_hash_decoded
        except Exception as e:  # noqa: BLE001
            # Log at warning level; failure to fetch MD5 means we just assume it's changed/needs processing
            logger.warning(f"Failed to fetch MD5 for {path}: {e}")
            return path, None

    n_jobs = get_max_workers(
        ParallelOperationType.NETWORK_BOUND,
        item_count=len(file_paths),
        max_workers_override=max_workers_override,
    )
    logger.info(f"Fetching MD5s for {len(file_paths)} files with {n_jobs} workers")

    results = Parallel(n_jobs=n_jobs, backend="threading")(delayed(_fetch_single_md5)(path) for path in file_paths)

    md5_dict: dict[str, str] = {path: md5 for path, md5 in results if md5 is not None}  # pyrefly: ignore[not-iterable]
    failed_count = len(file_paths) - len(md5_dict)
    if failed_count > 0:
        logger.warning(f"Failed to fetch MD5 for {failed_count}/{len(file_paths)} files - these will be reprocessed")
    logger.info(f"Successfully fetched {len(md5_dict)}/{len(file_paths)} MD5 hashes")
    return md5_dict


@contextmanager
def blob_manager() -> Generator[list[Blob | BlobExt], None, None]:
    """Context manager that yields a list of blobs that will be automatically
    deleted if an exception is raised inside the context. For each blob you
    upload, append it to the list. For example:

        ```python
        with blob_manager() as blobs:
            blob = upload_blob("my-bucket", "local-file.txt", "path/to/remote-file.txt")
            blobs.append(blob)
        ```

    .. deprecated::
        Use :func:`transactional_blob_manager` instead, which also supports
        rollback of replaced blobs via GCS versioning.
    """
    blobs: list[Blob] = []
    try:
        yield blobs
    except BaseException:
        logger.info("An error occured, deleting blobs from GCS")
        for blob in blobs:
            blob.delete()
        raise


class TransactionalBlobTracker:
    """Tracks blobs for transactional rollback with auto-detection.

    This class handles two scenarios:
    - **New uploads**: Tracked blobs are deleted on rollback
    - **Replacements**: Previous version is restored using GCS versioning

    The tracker auto-detects whether a blob is new or a replacement by checking
    if it exists before the upload. For replacements, it captures the generation
    number to restore on rollback.

    Note:
        For replacement rollback to work, the bucket must have versioning enabled.
        If versioning is not enabled, a ``ValueError`` is raised when tracking
        an existing blob.
    """

    def __init__(self) -> None:
        self._new_blobs: list[Blob | BlobExt] = []
        self._replacements: dict[str, tuple[Blob | BlobExt, int]] = {}

    def track(self, blob: Blob | BlobExt) -> None:
        """Track a blob for rollback. Auto-detects new vs replacement.

        This method MUST be called BEFORE uploading/overwriting the blob.
        It checks if the blob already exists:
        - If it exists, captures the generation for restoration on rollback
        - If it doesn't exist, tracks it for deletion on rollback

        Args:
            blob: The blob to track. Must have bucket and name set.
        """
        uri = f"gs://{blob.bucket.name}/{blob.name}"
        try:
            blob.reload()
            # Blob exists -> replacement, capture generation for restoration
            generation = blob.generation
            if generation is None:
                msg = (
                    f"Blob {uri} exists but has no generation number. "
                    "This typically means bucket versioning is not enabled. "
                    "Versioning is required for safe rollback of replaced blobs. "
                    "Enable versioning on the bucket with: "
                    f"`gsutil versioning set on gs://{blob.bucket.name}`"
                )
                raise ValueError(msg)
            self._replacements[uri] = (blob, generation)
            logger.debug(f"Tracking replacement: {uri} (generation={generation})")
        except NotFound:
            # Blob doesn't exist -> new upload, track for deletion
            self._new_blobs.append(blob)
            logger.debug(f"Tracking new blob: {uri}")

    def rollback(self) -> None:
        """Rollback all tracked blob operations.

        - Deletes all new blobs that were uploaded
        - Restores replaced blobs to their previous version using GCS versioning
        """
        # Delete new blobs
        for blob in self._new_blobs:
            try:
                blob.delete()
                logger.debug(f"Deleted new blob: gs://{blob.bucket.name}/{blob.name}")
            except NotFound:
                pass  # Already gone

        # Restore replaced blobs from previous generation
        for uri, (blob, old_generation) in self._replacements.items():
            try:
                bucket: Bucket = blob.bucket
                bucket.copy_blob(blob, bucket, blob.name, source_generation=old_generation)
                logger.debug(f"Restored {uri} to generation {old_generation}")
            except NotFound:
                # Generation not found - versioning likely not enabled
                logger.warning(
                    f"Could not restore {uri} to generation {old_generation}. "
                    "Bucket versioning may not be enabled - previous version is lost."
                )


@contextmanager
def transactional_blob_manager() -> Generator[TransactionalBlobTracker, None, None]:
    """Context manager for transactional blob operations with rollback support.

    This context manager yields a :class:`TransactionalBlobTracker` that handles
    two scenarios on failure:
    - **New uploads**: Deletes the blob
    - **Replacements**: Restores previous version using GCS versioning

    Usage:
        ```python
        with transactional_blob_manager() as tracker:
            blob = BlobExt(bucket, name)
            tracker.track(blob)  # Auto-detects new vs replacement
            blob.upload_from_filename(local_file)
        ```

    Note:
        Bucket must have versioning enabled for replacement rollback to work.
        If versioning is not enabled, a ``ValueError`` is raised when tracking
        an existing blob.
    """
    tracker = TransactionalBlobTracker()
    try:
        yield tracker
    except BaseException:
        logger.info("Error occurred, rolling back blob operations")
        tracker.rollback()
        raise
