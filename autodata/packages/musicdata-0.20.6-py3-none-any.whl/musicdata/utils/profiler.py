"""Helper class to profile memory usage of a Python program.
Especially useful for finding memory leaks caused by lingering objects.
Can be used alongside the `scalene` package for more detailed profiling.
"""

import tracemalloc
from typing import ClassVar


class Profiler:
    # list to store memory snapshots
    snaps: ClassVar[list[tracemalloc.Snapshot]] = []

    @classmethod
    def start(cls, n_frames: int = 1) -> None:
        tracemalloc.start(n_frames)

    @classmethod
    def snapshot(cls) -> None:
        cls.snaps.append(tracemalloc.take_snapshot())

    @classmethod
    def stats_by_file(cls, index: int = 0) -> None:
        stats = cls.snaps[index].statistics("filename")
        print("\n*** Top 5 stats grouped by filename ***")
        for s in stats[:5]:
            print(s)

    @classmethod
    def stats_by_line(cls, index: int = 0) -> None:
        stats = cls.snaps[index].statistics("lineno")
        print("\n*** Top 5 stats grouped by line number ***")
        for s in stats[:5]:
            print(s)

    @classmethod
    def compare(cls) -> None:
        first = cls.snaps[0]
        for snapshot in cls.snaps[1:]:
            stats = snapshot.compare_to(first, "lineno")
            print("\n*** Top 10 stats ***")
            for s in stats[:10]:
                print(s)

    @classmethod
    def print_trace(cls, obj_index: int = 0, snap_index: int = -1) -> None:
        """Prints the traceback for the largest memory block in the last snapshot by
        default.

        Can also be used to print the traceback of any memory block in any snapshot."""
        # pick the last saved snapshot, filter noise
        snapshot = cls.snaps[snap_index].filter_traces(
            (
                tracemalloc.Filter(False, "<frozen importlib._bootstrap>"),
                tracemalloc.Filter(False, "<frozen importlib._bootstrap_external>"),
                tracemalloc.Filter(False, "<unknown>"),
            ),
        )
        mem_block_stat = snapshot.statistics("traceback")[obj_index]

        print(
            f"\n*** Trace for largest memory block - ({mem_block_stat.count} blocks, "
            f"{mem_block_stat.size / 1024} Kb) ***",
        )
        for line in mem_block_stat.traceback.format():
            print(line)
