import asyncio
import functools
import time
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

from musicdata.utils.files import find_project_root

if TYPE_CHECKING:
    from loguru import Logger


def configure_file_logger(logger: "Logger", file: str, **kwargs) -> Path:
    """
    Configures a file logger with the specified file path.

    It finds the root directory of the project and writes logs to a file in the 'output' directory at the project root.

    Args:
        logger: The logger to configure.
        file: The name of the file where logs should be written. Usually `__file__` and then only the file name is kept.
        **kwargs: Arbitrary keyword arguments passed to `logger.add()`. Common examples include `level="DEBUG"` or
        `level="INFO"`.

    Returns:
        Path: The path to the log file that was configured.
    """
    filepath = Path(file)

    # Find project root and create output directory if it doesn't exist
    project_root = find_project_root(filepath)
    output_dir = project_root / "output"
    output_dir.mkdir(exist_ok=True)

    enqueue = kwargs.pop("enqueue", True)

    log_path = output_dir / f"{filepath.stem}.log"

    logger.add(log_path, enqueue=enqueue, **kwargs)

    return log_path


def log_execution_time(func: Callable) -> Callable:
    """
    Decorator to measure and log the time a function takes to execute.

    Works with both sync and async functions.
    """

    @functools.wraps(func)
    def sync_wrapper(*args, **kwargs) -> Any:  # noqa: ANN401
        from loguru import logger as runtime_logger  # noqa: PLC0415

        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        hours, remainder = divmod(elapsed_time, 3600)
        minutes, seconds = divmod(remainder, 60)
        runtime_logger.info(f"{func.__name__} executed in {int(hours)}h {int(minutes)}m {seconds:.2f}s")
        return result

    @functools.wraps(func)
    async def async_wrapper(*args, **kwargs) -> Any:  # noqa: ANN401
        from loguru import logger as runtime_logger  # noqa: PLC0415

        start_time = time.time()
        result = await func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        hours, remainder = divmod(elapsed_time, 3600)
        minutes, seconds = divmod(remainder, 60)
        runtime_logger.info(f"{func.__name__} executed in {int(hours)}h {int(minutes)}m {seconds:.2f}s")
        return result

    # Check if the function is async
    if asyncio.iscoroutinefunction(func):
        return async_wrapper
    return sync_wrapper
