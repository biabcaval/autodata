import os
import re
import socket
from urllib.parse import unquote, urlparse

import requests
import socks
from loguru import logger

from musicdata.utils.files import sanitize_filename

# Save the original `socket.getaddrinfo` function.
original_getaddrinfo = socket.getaddrinfo


def get_session(proxy_list: list | dict | None = None) -> requests.Session:
    s = requests.Session()
    if proxy_list:
        s.proxies.update(proxy_list)
    return s


def download_file(
    url: str,
    session: requests.Session | None = None,
    timeout: int = 60,
) -> tuple[bytes, str]:
    """Download file from a given URL and return the file data and filename.

    Args:
        url (str): The URL to download the file from.
        session (requests.Session): The session to use for the request.

    Returns:
        tuple: A tuple containing the file data (bytes) and the filename (str).

    Example:
        file_data, file_name = download_file(file_url, session)
    """
    file_name = _parse_file_name(url)

    try:
        response = session.get(url, timeout=timeout) if session else requests.get(url, timeout=timeout)
        response.raise_for_status()
    except Exception:
        logger.exception(f"Unable to download file {url}")
        raise

    return response.content, file_name


def _parse_file_name(url: str) -> str:
    parsed_url = urlparse(url)

    # Check if the input is a valid URL by verifying scheme and netloc
    if parsed_url.scheme and parsed_url.netloc:  # noqa: SIM108
        file_name = os.path.basename(parsed_url.path)
    else:
        file_name = os.path.basename(url)

    # Decode the filename to avoid double encoding
    decoded_file_name = file_name
    while True:
        unquoted_file_name = unquote(decoded_file_name)
        if unquoted_file_name == decoded_file_name:
            break
        decoded_file_name = unquoted_file_name
    return sanitize_filename(decoded_file_name)


def set_default_socks_proxy(socks5: str) -> None:
    """Set default SOCKS5 proxy for all requests done through the socket module.

    Args:

        socks5 (str): SOCKS5 proxy in the format `socks5://user:password@host:port`
    """
    regex = r"socks5://(?P<user>.+):(?P<pwd>.+)@(?P<host>.+):(?P<port>\d+)"
    match = re.match(regex, socks5)
    socks.set_default_proxy(
        socks.SOCKS5,
        addr=match["host"],
        port=int(match["port"]),
        username=match["user"],
        password=match["pwd"],
    )
    socket.socket = socks.socksocket
    logger.info("Default SOCKS5 proxy set")


def set_openers_to_ipv4() -> None:
    """Set the default `socket.getaddrinfo` function to a custom one that forces IPv4."""
    socket.getaddrinfo = ipv4_getaddrinfo
    logger.info("Default socket.getaddrinfo set to IPv4")


def set_openers_to_original() -> None:
    """Set the default `socket.getaddrinfo` function to the original one."""
    socket.getaddrinfo = original_getaddrinfo
    logger.info("Default socket.getaddrinfo set to original")


def ipv4_getaddrinfo(*args, **kwargs) -> list:
    """A custom `getaddrinfo` function that forces IPv4.
    Filter out all responses that are not IPv4.
    """
    responses = original_getaddrinfo(*args, **kwargs)
    ipv4_responses = [response for response in responses if response[0] == socket.AF_INET]
    return ipv4_responses
