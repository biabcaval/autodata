"""System utilities for detecting hardware resources in containerized environments."""

import math
import os
from pathlib import Path

from joblib import cpu_count as joblib_cpu_count
from loguru import logger

# Define cgroup paths
CGROUP_V2_BASE_PATH = Path("/sys/fs/cgroup")
PROC_SELF_CGROUP_PATH = Path("/proc/self/cgroup")


def get_effective_cpu_count() -> int:
    """
    Get the effective CPU count, respecting container (cgroup) limits.

    This function detects CPU limits in containerized environments (Docker, Kubernetes)
    using a hybrid approach that combines battle-tested libraries with custom cgroup v2 support.

    Detection strategy:
    1. Try cgroup v2 (modern Kubernetes): Walk hierarchy reading cpu.max files
    2. Fallback to joblib.cpu_count() (handles v1, affinity, and bare metal)
    3. Ultimate fallback to os.cpu_count()

    The cgroup v2 detection walks up the hierarchy to find the most restrictive limit,
    which is important for nested cgroups in Kubernetes. Joblib's cpu_count handles
    cgroup v1, CPU affinity, and various platform-specific constraints.

    Returns:
        Number of effective CPUs available to the process.
        Rounds up fractional CPUs (e.g., 1.5 → 2) to match Kubernetes behavior.

    Examples:
        >>> # On bare metal with 8 CPUs
        >>> get_effective_cpu_count()
        8

        >>> # In Kubernetes pod with CPU limit of 4
        >>> get_effective_cpu_count()
        4

        >>> # In Docker container with --cpus=2.5
        >>> get_effective_cpu_count()
        3  # Rounded up from 2.5 (matches K8s behavior)
    """
    # Try cgroup v2 first (modern Kubernetes, Docker)
    try:
        v2_cpu_count = _get_cgroup_v2_cpu_limit()
        if v2_cpu_count is not None:
            logger.debug(f"Detected {v2_cpu_count} CPUs from cgroup v2")
            return v2_cpu_count
    except Exception as e:  # noqa: BLE001 - catch all errors to prevent crashes
        # Don't let v2 detection crash the app
        logger.error(f"cgroup v2 detection failed unexpectedly: {e}", exc_info=True)

    # Fallback to joblib.cpu_count() (handles v1, affinity, bare metal)
    try:
        logger.debug("Falling back to joblib.cpu_count() (for v1, affinity, or bare metal)")
        v1_or_fallback_count = joblib_cpu_count()

        # joblib.cpu_count() always returns at least 1, but check to be safe
        if v1_or_fallback_count is None or v1_or_fallback_count < 1:
            logger.warning("joblib.cpu_count() returned invalid value, falling back to os.cpu_count()")
            return os.cpu_count() or 4

        # Successfully got CPU count from joblib
        logger.debug(f"Detected {v1_or_fallback_count} CPUs from joblib.cpu_count()")
        return v1_or_fallback_count  # noqa: TRY300

    except Exception as e:  # noqa: BLE001 - catch all errors to prevent crashes
        logger.error(f"joblib.cpu_count() failed: {e}, using final fallback os.cpu_count()", exc_info=True)
        return os.cpu_count() or 4


def _get_cgroup_v2_cpu_limit() -> int | None:  # noqa: C901, PLR0912 - complexity needed for robustness
    """
    Read CPU limit from cgroup v2 by walking up the hierarchy.

    cgroup v2 uses a unified hierarchy where limits are hierarchical - the effective
    limit is the most restrictive (minimum) found when walking from the process's
    cgroup up to the root.

    Algorithm:
    1. Read /proc/self/cgroup to find our cgroup path (format: "0::/path/to/cgroup")
    2. Walk up from our cgroup to the root
    3. At each level, read cpu.max if it exists
    4. Track the minimum (most restrictive) limit found
    5. Round up fractional CPUs (matches Kubernetes scheduling behavior)

    Returns:
        Number of CPUs if successfully detected, None otherwise.

    Note:
        - cpu.max format: "$QUOTA $PERIOD" (both in microseconds)
        - Example: "200000 100000" = 200ms quota per 100ms period = 2 CPUs
        - "max 100000" means UNLIMITED (no CPU restrictions)
        - The "max" keyword is NOT a maximum value, it means "no quota limit"
    """
    if not CGROUP_V2_BASE_PATH.exists() or not PROC_SELF_CGROUP_PATH.exists():
        logger.debug("cgroup v2 paths not found")
        return None

    try:
        # Find the cgroup v2 path for the current process
        cgroup_path_str = ""
        with PROC_SELF_CGROUP_PATH.open() as f:
            for line in f:
                # cgroup v2 format: "0::/path/to/cgroup"
                if line.startswith("0::"):
                    cgroup_path_str = line.strip().split(":", 2)[-1]
                    break

        if not cgroup_path_str:
            logger.debug("cgroup v2 path (0::) not found in /proc/self/cgroup")
            return None

        # Start from our cgroup and walk up to root
        current_path = CGROUP_V2_BASE_PATH / cgroup_path_str.lstrip("/")
        min_cpu_limit = float("inf")
        found_limit = False

        # Walk up the hierarchy
        while str(current_path).startswith(str(CGROUP_V2_BASE_PATH)) and current_path != CGROUP_V2_BASE_PATH.parent:
            cpu_max_file = current_path / "cpu.max"

            if cpu_max_file.exists():
                try:
                    content = cpu_max_file.read_text().strip()
                    parts = content.split()

                    # cpu.max format: "$QUOTA $PERIOD" (both in microseconds)
                    # - "max 100000" means unlimited quota (no CPU restrictions)
                    # - "400000 100000" means 4 CPUs (400000/100000 = 4.0)
                    # The "max" keyword indicates no limit, NOT a maximum value
                    if len(parts) == 2 and parts[0] != "max":  # noqa: PLR2004
                        quota = int(parts[0])
                        period = int(parts[1])

                        if period > 0:
                            limit = quota / period
                            min_cpu_limit = min(min_cpu_limit, limit)
                            found_limit = True
                            logger.debug(f"Found cgroup v2 limit at {cpu_max_file}: {limit:.2f} CPUs")

                except (OSError, ValueError, ZeroDivisionError) as e:
                    logger.warning(f"Error reading or parsing {cpu_max_file}: {e}")
                except Exception as e:  # noqa: BLE001 - catch all to continue hierarchy walk
                    logger.error(f"Unexpected error processing {cpu_max_file}: {e}")

            # Move to parent directory
            current_path = current_path.parent

        if found_limit and min_cpu_limit != float("inf"):
            # Round up, matching Kubernetes behavior
            # (e.g., 1.5 CPU limit means the pod can use up to 2 cores)
            cpu_count = math.ceil(min_cpu_limit)
            return max(1, cpu_count)

        # No limit found - fall through to next detection method
        logger.debug("No cgroup v2 'cpu.max' limit found in hierarchy")
        return None  # noqa: TRY300

    except (OSError, PermissionError) as e:
        logger.warning(f"Could not read cgroup v2 files: {e}")
        return None
    except Exception as e:  # noqa: BLE001 - catch all errors to prevent crashes
        logger.error(f"Unexpected error during cgroup v2 detection: {e}", exc_info=True)
        return None
