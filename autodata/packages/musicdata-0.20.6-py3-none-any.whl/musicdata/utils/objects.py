import queue
from collections.abc import Generator
from contextlib import contextmanager
from functools import reduce
from typing import Any


class ResourceQueue:
    def __init__(self, items: list) -> None:
        self.queue = queue.Queue()
        for item in items:
            self.queue.put(item)

    @contextmanager
    def resource(self) -> Generator[Any, None, None]:
        resource = self.queue.get()
        try:
            yield resource
        finally:
            self.queue.put(resource)


def has_nested_attribute(obj: Any, attr_path: str) -> bool:
    """Checks if an object has a nested attribute.

    Args:
        obj: The object to check.
        attr_path: The path to the nested attribute.

    Returns:
        True if the object has the nested attribute, False otherwise.
    """
    try:
        reduce(getattr, attr_path.split("."), obj)
    except AttributeError:
        return False
    return True


def flatten(list_of_lists: list[list[Any]]) -> list[Any]:
    """Flattens a list of lists."""

    def flatten_helper(lst: list[Any]) -> list[Any]:
        """Helper function to flatten a list."""
        result = []
        for item in lst:
            if isinstance(item, list):
                result.extend(flatten_helper(item))
            else:
                result.append(item)
        return result

    return flatten_helper(list_of_lists)
