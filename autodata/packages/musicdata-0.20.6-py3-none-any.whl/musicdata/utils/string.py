import re
import unicodedata
import warnings

import orjson
from cryptography.fernet import Fernet
from loguru import logger

STRICT_NORMALIZE_RE = re.compile(r"[^\w\-\/\| ]")
NON_WORD_RE = re.compile(r"\W")
MULTIPLE_SPACES_RE = re.compile(r"\s{2,}")
HTML_CLEANR = re.compile("<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});")


class ValueEncryptor:
    """
    A class to handle encryption and decryption of values using Fernet symmetric encryption.

    DEPRECATED: This class is deprecated and will be removed in a future version.
    Use JWEEncryptor instead for improved security and functionality.
    """

    def __init__(self, key: bytes) -> None:
        """
        Initializes the ValueEncryptor with a specific encryption key.

        Args:
            key (bytes): The Fernet key.

        Raises:
            TypeError: If key is not bytes.
            ValueError: If key is invalid.
        """
        warnings.warn(
            "ValueEncryptor is deprecated and will be removed in a future version. "
            "Use JWEEncryptor instead for improved security and functionality.",
            DeprecationWarning,
            stacklevel=2,
        )

        if not isinstance(key, bytes):
            msg = "Key must be bytes."
            raise TypeError(msg)
        self.fernet = Fernet(key)

    def encrypt_value(self, value: str) -> str:
        """
        Encrypts a value using Fernet encryption.

        Args:
            value (str): The value to encrypt.

        Returns:
            str: The encrypted value encoded in Base64.

        Raises:
            TypeError: If value is not a string.
            ValueError: If encryption fails.
        """
        if not isinstance(value, str):
            msg = "Value must be a string."
            raise TypeError(msg)
        try:
            encrypted_bytes = self.fernet.encrypt(value.encode("utf-8"))
            return encrypted_bytes.decode("utf-8")
        except Exception as e:
            logger.exception("Failed to encrypt value")
            msg = "Encryption failed."
            raise ValueError(msg) from e

    def decrypt_value(self, encrypted_value: str) -> str:
        """
        Decrypts a previously encrypted value.

        Args:
            encrypted_value (str): The encrypted value to decrypt.

        Returns:
            str: The original value.

        Raises:
            TypeError: If encrypted_value is not a string.
            ValueError: If decryption fails.
        """
        if not isinstance(encrypted_value, str):
            msg = "Encrypted value must be a string."
            raise TypeError(msg)
        try:
            decrypted_bytes = self.fernet.decrypt(encrypted_value.encode("utf-8"))
            return decrypted_bytes.decode("utf-8")
        except Exception as e:
            logger.exception("Failed to decrypt value")
            msg = "Decryption failed."
            raise ValueError(msg) from e


def normalize_text(text: str) -> str:
    # Convert to lowercase, remove diacritics and special characters
    clean_text = unicodedata.normalize("NFKD", text.lower()).encode("ascii", errors="ignore").decode("utf-8")
    clean_text = re.sub(STRICT_NORMALIZE_RE, "", clean_text)  # Remove chars that don't match
    clean_text = re.sub(NON_WORD_RE, " ", clean_text)  # Replace remaining non-word
    return re.sub(MULTIPLE_SPACES_RE, " ", clean_text)  # Remove multiple spaces


def clean_html(html_text: str) -> str:
    """Removes HTML tags from the string."""
    return re.sub(HTML_CLEANR, "", html_text)


def format_json_text(text: str) -> str:
    """Formats a JSON string to be more readable."""
    json_data = orjson.loads(text)
    return orjson.dumps(json_data).decode()


def contains_any(text: str, substrings: list[str]) -> bool:
    """Returns True if any of the substrings are in text (case-insensitive)."""
    return any(substring.lower() in text.lower() for substring in substrings)


def str_to_bool(s: str) -> bool:
    return False if s is None else s.lower() in {"true", "t", "yes", "1"}
