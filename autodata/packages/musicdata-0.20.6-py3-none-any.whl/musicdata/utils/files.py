import hashlib
import os
import re
import shutil
from collections.abc import Generator, Iterable
from contextlib import contextmanager
from pathlib import Path
from subprocess import CalledProcessError, check_output, run
from typing import cast
from uuid import uuid4

import filetype
import orjson
from loguru import logger
from pathvalidate import sanitize_filename as _pv_sanitize_filename
from pathvalidate import sanitize_filepath as _pv_sanitize_filepath
from pydub import AudioSegment

from musicdata.utils.string import MULTIPLE_SPACES_RE

AUDIO_EXTENSIONS = {
    ".wav": True,
    ".wave": True,
    ".flac": True,
    ".aiff": True,
    ".aif": True,
    ".aifc": True,
    ".alac": True,
    ".caf": True,
    ".ape": True,
    ".wv": True,
    ".tta": True,
    ".opus": False,
    ".ogg": False,
    ".m4a": False,  # Not always lossless
    ".aac": False,
    ".mp4a": False,
    ".mp3": False,
}  # Sorted by codec quality. Boolean value indicates if it is lossless or not.
LOSSLESS_AUDIO_EXTENSIONS = [ext for ext, is_lossless in AUDIO_EXTENSIONS.items() if is_lossless]
FFMPEG_ARGS = [
    "ffmpeg",
    "-hide_banner",
    "-loglevel",
    "error",
    "-y",
]
LONG_FMT_TO_EXT_MAP = {
    "3GPP": "3gp",
    "3GPP2": "3g2",
    "AAC (Advanced Audio Codec)": "aac",
    "AC-3 (Audio Codec 3)": "ac3",
    "AIFF (Audio Interchange File Format)": "aiff",
    "ALAC (Apple Lossless Audio Codec)": "m4a",
    "AMR (Adaptive Multi-Rate)": "amr",
    "ASF (Advanced / Active Streaming Format)": "asf",
    "Audio IFF": "aiff",
    "AVI (Audio Video Interleaved)": "avi",
    "AVI": "avi",
    "BMP image": "bmp",
    "DTS (Digital Theater Systems)": "dts",
    "FLAC (Free Lossless Audio Codec)": "flac",
    "FLV": "flv",
    "GIF image": "gif",
    "Matroska / WebM": "mkv",
    "Monkey's Audio": "ape",
    "MP2/3 (MPEG audio layer 2/3)": "mp3",
    "MPEG Audio": "mp3",
    "MPEG-1 Systems / MPEG program stream": "mpg",
    "MPEG-4": "mp4",
    "MPEG-PS (MPEG-2 Program Stream)": "mpeg",
    "MPEG-PS": "mpeg",
    "MPEG-TS": "ts",
    "Ogg": "ogg",
    "Opus": "opus",
    "QuickTime / MOV": "mov",
    "raw ADTS AAC (Advanced Audio Coding)": "aac",
    "raw FLAC": "flac",
    "RealMedia": "rm",
    "True Audio": "tta",
    "Vorbis": "oga",
    "WAV / WAVE (Waveform Audio)": "wav",
    "WavPack": "wv",
    "WebM": "webm",
    "Windows Media": "wmv",
}
CODEC_TO_EXT_MAP = {
    "aac": "m4a",
    "ac3": "ac3",
    "adpcm_ima_wav": "wav",
    "adpcm_ms": "wav",
    "alac": "m4a",
    "amr_nb": "amr",
    "amr_wb": "amr",
    "ape": "ape",
    "atrac3": "aa3",
    "atrac3p": "aa3",
    "dts": "dts",
    "eac3": "ac3",
    "flac": "flac",
    "g722": "g722",
    "g726": "g726",
    "gsm_ms": "gsm",
    "libopus": "opus",
    "libvorbis": "ogg",
    "mlp": "mlp",
    "mp2": "mp2",
    "mp3": "mp3",
    "ogg": "ogg",
    "opus": "opus",
    "pcm_a-law": "wav",
    "pcm_f32le": "wav",
    "pcm_mu-law": "wav",
    "pcm_s16be": "aiff",
    "pcm_s16le": "wav",
    "pcm_s24be": "aiff",
    "pcm_s24le": "wav",
    "pcm_s32be": "aiff",
    "pcm_s32le": "wav",
    "pcm_u8": "wav",
    "qdm2": "qdm",
    "real_144": "ra",
    "real_288": "ra",
    "realbounce": "ra",
    "speex": "spx",
    "truehd": "thd",
    "vorbis": "ogg",
    "wav": "wav",
    "wma": "wma",
    "wmalossless": "wma",
}


class FilesError(Exception):
    """Base class for exceptions in this module."""


class UnknownMimeTypeError(FilesError):
    """Raised when the file type cannot be determined."""

    def __init__(self, file_path: str | Path) -> None:
        super().__init__(f"Unable to determine the MIME type of '{file_path}'")


class GuessExtensionError(FilesError):
    """Raised when the file extension cannot be determined."""

    def __init__(self, file_path: str | Path) -> None:
        super().__init__(f"Unable to determine file extension of '{file_path}'")


class InvalidMediaFileError(FilesError):
    """Raised when the file is not a media file."""

    def __init__(self, file_path: str | Path) -> None:
        super().__init__(f"File '{file_path}' is not a valid media file")


class NotAnAudioFileError(FilesError):
    pass


class InvalidFileNameError(FilesError):
    """Raised when a file name is considered invalid."""


class FileNameTooLongError(FilesError):
    """Raised when a file name is equal to or longer than 255 characters."""


class AudioExtensionsDict(dict):
    def __getitem__(self, key: str) -> str:
        try:
            return super().__getitem__(key)
        except KeyError as e:
            msg = f"The audio extension {key} is not supported"
            raise ValueError(msg) from e


AUDIO_EXTS_PRIORITY = AudioExtensionsDict(
    {key: i for i, key in enumerate(AUDIO_EXTENSIONS)},
)


class MediaFile:
    """Class used to handle everything related to media files.

    Needs ffmpeg and ffprobe to be installed in the system. ffprobe is a
    multimedia stream analyzer that is part of the FFmpeg project. It is
    used to extract information about the format of the audio file. ffmpeg
    is a command-line tool to convert multimedia files between formats.
    """

    _binaries_checked = False

    def __init__(self, file_path: str | Path) -> None:
        self.__class__.check_binaries()

        self.file = Path(file_path)
        self._check_file_exists()

        self.media_info = self._get_media_info()
        self.stream_types = self._get_stream_types()
        self._check_media_file()

        self._md5_hash: str | None = None
        self._guessed_extension: str | None = None
        self._AudioSegment: AudioSegment | None = None

    @staticmethod
    def _check_ffprobe() -> None:
        if not shutil.which("ffprobe"):
            msg = "ffprobe not found in the system"
            raise RuntimeError(msg)

    @staticmethod
    def _check_ffpmeg() -> None:
        if not shutil.which("ffmpeg"):
            msg = "ffmpeg not found in the system"
            raise RuntimeError(msg)

    @classmethod
    def check_binaries(cls) -> None:
        if not cls._binaries_checked:
            cls._check_ffprobe()
            cls._check_ffpmeg()
            cls._binaries_checked = True

    @property
    def guessed_extension(self) -> str:
        if self._guessed_extension is None:
            self._guessed_extension = self._guess_media_extension()
        return self._guessed_extension

    @property
    def duration(self) -> float:
        duration = self.media_info["format"].get("duration")
        if duration is None:
            return self.audio_segment.duration_seconds
        return float(duration)

    @property
    def audio_segment(self) -> AudioSegment:
        if self._AudioSegment is None:
            try:
                self._AudioSegment = AudioSegment.from_file(self.file)
            except Exception as e:
                raise InvalidMediaFileError(self.file) from e
        return self._AudioSegment

    def _check_file_exists(self) -> None:
        if self.file.exists() is False:
            msg = f"File {self.file} not found"
            raise FileNotFoundError(msg)

    def _guess_media_extension(self) -> str:
        # 1. Try filetype library (magic bytes) - works for all media types
        extension = guess_extension(self.file)
        if extension:
            return extension

        # 2. For audio-only files, try codec detection (most specific for audio)
        # This helps cases like AAC codec that should be .m4a not .mp4
        if self._has_only_audio_streams():
            try:
                codec_ext = self.guess_audio_stream_extension()
                if codec_ext:
                    return codec_ext
            except (FilesError, ValueError) as e:
                # Codec detection failed, fall back to format mappings
                logger.debug(f"Codec detection failed for {self.file}: {e}")

        # 3. Fall back to format mappings (works for all media types)
        extension = self._guess_extension_with_ffprobe()

        # 4. Last resort: original extension
        return extension or self.file.suffix.lstrip(".").lower()

    def _get_media_info(self) -> dict:
        """Gets the information of the media file.

        Raises:
            InvalidMediaFileError: If the ffprobe command fails.
        """
        command = [
            "ffprobe",
            "-v",
            "quiet",
            "-print_format",
            "json",
            "-show_streams",
            "-show_format",
            self.file,
        ]
        try:
            output = check_output(command, shell=False)
        except CalledProcessError as e:
            raise InvalidMediaFileError(self.file) from e
        return orjson.loads(output)

    def _get_stream_types(self) -> set[str]:
        return {stream["codec_type"] for stream in self.media_info["streams"]}

    def _check_media_file(self) -> None:
        """Checks if the file is a valid media file."""
        if "audio" not in self.stream_types and "video" not in self.stream_types:
            raise InvalidMediaFileError(self.file)

    def _guess_extension_with_ffprobe(self) -> str:
        """Gets the media file format using ffprobe."""
        format_name = self.media_info["format"]["format_name"]
        format_long_name = self.media_info["format"]["format_long_name"]

        # First, try to find the extension using the format_long_name
        extension = LONG_FMT_TO_EXT_MAP.get(format_long_name)

        # If not found, then try to find the extension using the format_name
        if not extension:
            logger.warning(f"Extension not found for format '{format_long_name}'")
            extension = format_name.split(",")[0] if "," in format_name else format_name
        return extension.lower()

    def _has_only_audio_streams(self) -> bool:
        """Returns True if the file has only audio streams and no video streams."""
        has_audio = False
        has_video = False
        for stream in self.media_info["streams"]:
            if stream["codec_type"] == "audio":
                has_audio = True
            elif stream["codec_type"] == "video":  # noqa: SIM102
                # Ignore video streams that are album art (attached_pic == 1)
                if not (stream.get("disposition", {}).get("attached_pic", 0)):
                    has_video = True

        if has_audio and has_video:
            logger.debug(f"File {self.file} has both audio and video streams.")
        if not has_audio:
            logger.info(f"File {self.file} has no audio streams.")
        return has_audio and not has_video

    def get_md5_hash(self) -> str:
        if self._md5_hash is None:
            self._md5_hash = get_md5_hash(self.file)
        return self._md5_hash

    def guess_audio_stream_extension(self) -> str | None:
        stream_types = [stream["codec_type"] for stream in self.media_info["streams"]]
        if stream_types.count("audio") != 1:
            msg = "File do not have just one audio stream"
            raise FilesError(msg)

        for stream in self.media_info["streams"]:
            if stream["codec_type"] == "audio":
                extension = CODEC_TO_EXT_MAP.get(stream["codec_name"])
                if extension is None:
                    msg = f"The audio codec {stream['codec_name']} is not supported"
                    raise ValueError(msg)
                return extension.lower()
        return None

    def convert_to_audio(self, codec_args: Iterable, *, extension: str, remove_original: bool = True) -> "MediaFile":
        """Converts a media file into an audio file with the specified codec args.

        The new file replaces the original one if the conversion is successful.

        Args:
            codec_args (Iterable): The codec arguments to use for the conversion.
            extension (str): The extension for the new audio file.
            remove_original (bool): If True, deletes the original file after successful conversion.

        Examples:

        ```python
            media.convert_to_audio(["copy"], extension=".aac")
            media.convert_to_audio(["flac"], extension=".flac")
            media.convert_to_audio(["libmp3lame", "-qscale:a", "2"], extension=".mp3")
            media.convert_to_audio(["-acodec", "aac", "-b:a", "256k", "-ar", "16000", "-ac", "1"], extension=".aac")
        ```
        """
        if isinstance(codec_args, str):
            codec_args = [codec_args]
        extension = _pad_extension(extension)
        output_path = self.file.with_suffix(extension)

        # Safeguard: avoid writing output to the same path as input
        try:
            same_target = output_path.resolve() == self.file.resolve()
        except Exception:  # noqa: BLE001
            # Fallback: string compare if resolve() fails for any reason
            same_target = str(output_path) == str(self.file)

        # Determine final output path upfront
        if same_target and not remove_original:
            # Same extension but keeping original - need unique name
            unique_suffix = str(uuid4())[:8]
            final_output = self.file.with_name(f"{self.file.stem}_{unique_suffix}{extension}")
        elif same_target and remove_original:
            # Same extension and replacing original
            final_output = self.file
        else:
            # Different extension
            final_output = output_path

        # Create temp file for atomic write (avoids partial files if ffmpeg crashes)
        tmp_output = final_output.with_name(f"{final_output.stem}.tmp{final_output.suffix}")

        ffmpeg_args = FFMPEG_ARGS.copy()
        ffmpeg_args.extend(
            ["-i", str(self.file), "-vn", "-c:a", *codec_args, str(tmp_output)],
        )
        try:
            run(ffmpeg_args, check=True, shell=False, capture_output=True)  # noqa: S603
        except CalledProcessError as e:
            msg = f"Failed to convert audio: {e.stderr.decode()}"
            raise RuntimeError(msg) from e

        # Atomic rename from temp to final
        os.replace(tmp_output, final_output)

        # Clean up original if requested (only for different extensions)
        if not same_target and remove_original and self.file.exists():
            self.file.unlink()

        return MediaFile(final_output)

    def strip_metadata(
        self,
        output_path: str | None = None,
        *,
        replace_original: bool = False,
        normalize_extension: bool = True,
    ) -> "MediaFile":
        """Wrapper to create a metadata-free copy, preserving audio codec/container.

        If output_path is not provided, a sibling file named "<stem>.clean<suffix>" is created.
        By default, does not replace the original file; set replace_original=True to replace it.
        By default, the destination suffix is inferred from the single audio stream codec (e.g., AAC -> .m4a)
        when possible. Disable with normalize_extension=False to retain the original suffix.

        Returns a MediaFile pointing to the cleaned artifact (original path if replaced, else output path).
        """
        # Decide destination suffix
        dest_suffix = self.file.suffix
        if normalize_extension:
            try:
                guessed_ext = self.guess_audio_stream_extension()
                if guessed_ext and f".{guessed_ext}" != dest_suffix:
                    dest_suffix = f".{guessed_ext}"
            except (FilesError, ValueError) as e:
                # Fall back to comprehensive extension guessing logic
                logger.warning(
                    f"Could not normalize extension via audio stream for {self.file}: {e}, falling back to guessed_extension"
                )
                guessed_ext = self.guessed_extension
                if guessed_ext and f".{guessed_ext}" != dest_suffix:
                    dest_suffix = f".{guessed_ext}"

        # Decide destination path
        if output_path is None:
            output_path = str(self.file.with_name(f"{self.file.stem}.clean{dest_suffix}"))
        elif normalize_extension and Path(output_path).suffix != dest_suffix:
            output_path = str(Path(output_path).with_suffix(dest_suffix))

        # Perform cleaning via module-level utility
        strip_metadata(str(self.file), output_path)

        # Replace original if requested
        if replace_original:
            os.replace(output_path, self.file)
            return MediaFile(self.file)

        return MediaFile(output_path)

    def is_audio_file(self) -> bool:
        """Returns True if the file is an audio file, False otherwise."""
        try:
            file_type = get_mime_file_type(self.file)
        except UnknownMimeTypeError:
            return self._has_only_audio_streams()
        return file_type == "audio"

    def is_lossless_audio(self) -> bool:
        """Returns True if the file is a lossless audio format, False otherwise."""
        extension = self.file.suffix or f".{self.guessed_extension}"
        return extension.lower() in LOSSLESS_AUDIO_EXTENSIONS

    def __repr__(self) -> str:
        return f'<{self.__class__.__name__}("{self.file}")>'


@contextmanager
def auto_remove_file(file_path: str) -> Generator[None, None, None]:
    """Context manager that removes the file at the end of the block."""
    try:
        yield
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)


def is_lossless_extension(file_path: str) -> bool:
    """Returns True if the file is a lossless audio format, False otherwise.

    For improved detection when working with local files, use the `is_lossless_audio`
    method of the AudioFile class.
    """
    extension = get_extension(file_path)
    return extension.lower() in LOSSLESS_AUDIO_EXTENSIONS


def sort_audio_files_by_extension(file_paths: Iterable[str]) -> list[str]:
    """Sorts the files in decrescent order of audio quality. Files with extensions that
    are not predefined are placed at the end of the list.
    """

    def get_codec_priority(file_path: str) -> int:
        file_extension = get_extension(file_path)
        priority = AUDIO_EXTS_PRIORITY.get(file_extension)
        return priority if isinstance(priority, int) else len(AUDIO_EXTS_PRIORITY)

    return sorted(file_paths, key=get_codec_priority)


def filter_lower_quality_audio_files(
    file_paths: list[str] | set[str],
    extension: str,
) -> list[str]:
    """Filters out audio files that have a lower quality extension than the
    one specified.
    """
    extension = _pad_extension(extension)
    index = AUDIO_EXTS_PRIORITY[extension]
    higher_res = []
    for file_path in file_paths:
        file_extension = get_extension(file_path)
        priority = AUDIO_EXTS_PRIORITY.get(file_extension)
        if isinstance(priority, int) and isinstance(index, int) and priority < index:
            higher_res.append(file_path)
    return higher_res


def get_md5_hash(file_path: str | Path) -> str:
    """Returns the md5 hash of the file."""
    hash_md5 = hashlib.md5()  # noqa: S324
    with open(file_path, "rb") as f:
        # Reads in chunks, until an empty bytes object is returned, which means EOF
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def get_mime_file_type(file_path: str | Path) -> str:
    """Returns the file type (value on the left of the slash in a mimetype).

    Args:
        file_path (str): Path to the file.

    Returns:
        str: "audio", "video", "image", etc.

    Raises:
        UnknownMimeTypeError: If the mimetype cannot be guessed.
    """
    file = filetype.guess(file_path)
    if file is None or getattr(file, "mime", None) is None:
        raise UnknownMimeTypeError(file_path)
    return cast("str", file.mime).split("/")[0]


def get_extension(file_path: str) -> str:
    if extension := os.path.splitext(file_path)[-1].lower():
        return extension
    msg = f"File {file_path} has no extension"
    raise ValueError(msg)


def guess_extension(file_path: str | Path) -> str | None:
    """Returns the extension of the file or None if the extension
    cannot be guessed. Uses the filetype library to guess the extension.

    DO NOT USE this directly when working with media files. The guess_media_extension
    method of the MediaFile instance should be used instead. It provides a more
    robust detection for media files.
    """
    file_type = filetype.guess(file_path)
    return getattr(file_type, "extension", None)


def run_ffmpeg(args: list[str]) -> None:
    """Process using ffmpeg"""
    ffmpeg_args = FFMPEG_ARGS.copy()
    ffmpeg_args.extend(args)
    try:
        run(ffmpeg_args, check=True, shell=False, capture_output=True)
    except CalledProcessError as e:
        msg = f"Failed to run ffmpeg: {e.stderr.decode()}"
        raise RuntimeError(msg) from e


def mix_audio_files(input_files: list[str], output_file: str) -> None:
    """Mixes the input files into a single file and saves it to the output
    directory.
    """
    if len(input_files) <= 1:
        msg = "At least two input files are required"
        raise ValueError(msg)
    input_args = _pad_input_files(input_files)
    ffmpeg_args = FFMPEG_ARGS.copy()
    ffmpeg_args.extend(
        [
            *input_args,
            "-filter_complex",
            f"amix=inputs={len(input_files)}:duration=shortest:normalize=0",
            output_file,
        ],
    )
    try:
        run(ffmpeg_args, check=True, shell=False, capture_output=True)
    except CalledProcessError as e:
        msg = f"Failed to mix audio: {e.stderr.decode()}"
        raise RuntimeError(msg) from e


def strip_metadata(input_file: str, output_file: str) -> None:
    """Create a clean copy of an audio file without any metadata, preserving the
    original audio codec and stream.

    This function remuxes the audio stream (no re-encoding) and removes global and
    stream-level tags, chapters, video/attached picture streams and other side data that are
    commonly used to store album art and metadata. The output container is
    inferred from the output_file extension.

    Args:
        input_file: Local path to the source media file.
        output_file: Local path to write the cleaned media file to.
    """
    ffmpeg_args = [
        "-i",
        input_file,
        # Enable deterministic output
        "-bitexact",
        # Only keep audio streams
        "-map",
        "0:a",
        # Copy audio stream without re-encoding
        "-c:a",
        "copy",
        # Drop all global/stream metadata and chapters
        "-map_metadata",
        "-1",
        "-map_metadata:s",
        "-1",
        "-map_chapters",
        "-1",
        # Ensure no video streams (e.g., attached pictures)
        "-vn",
        output_file,
    ]
    run_ffmpeg(ffmpeg_args)


def ensure_folder_exists(folder: str) -> None:
    if not os.path.exists(folder):
        os.makedirs(folder)


def sanitize_filename(filename: str) -> str:
    """Sanitizes a filename by removing characters that are not allowed in a filename on most operating systems."""
    forbidden_extra = {"#"}
    sanitized = "".join(c for c in filename if c not in forbidden_extra)
    sanitized = _pv_sanitize_filename(sanitized)
    sanitized = re.sub(MULTIPLE_SPACES_RE, " ", sanitized)

    if not sanitized:
        raise InvalidFileNameError(filename)
    pathvalidator_max_length = 255
    if len(sanitized) >= pathvalidator_max_length:  # Check if name was truncated by pathvalidator
        raise FileNameTooLongError(filename)

    return sanitized


def sanitize_filepath(filename: str) -> str:
    """Sanitizes a filepath by removing characters that are not allowed in a filename on most operating systems."""
    # forbidden_extra = {"#"}
    # sanitized = "".join(c for c in filename if c not in forbidden_extra)
    sanitized = _pv_sanitize_filepath(filename)
    sanitized = re.sub(MULTIPLE_SPACES_RE, " ", sanitized)

    if not sanitized:
        raise InvalidFileNameError(filename)
    pathvalidator_max_length = 255
    if len(sanitized) >= pathvalidator_max_length:  # Check if name was truncated by pathvalidator
        raise FileNameTooLongError(filename)

    return sanitized


def _pad_input_files(input_files: list[str]) -> list[str]:
    """Pads the input files with the -i flag to be used with ffmpeg."""
    args = []
    for file in input_files:
        args.extend(["-i", file])
    return args


def _pad_extension(extension: str) -> str:
    return extension if extension.startswith(".") else f".{extension}"


def find_project_root(start_path: str | Path) -> Path:
    """Find the project root directory by looking for common project markers."""
    markers = [".git", "conda.yaml", "pyproject.toml", "requirements.txt", "setup.py"]

    if isinstance(start_path, str):
        start_path = Path(start_path)

    current_path = start_path.resolve()
    root_path = current_path.root

    while current_path != root_path:
        if any((current_path / marker).exists() for marker in markers):
            return current_path
        current_path = current_path.parent

    msg = f"Could not determine project root. Searched up to filesystem root {root_path} for markers: {markers}"
    raise FileNotFoundError(msg)


def normalize_extension(extension: str) -> str:
    """Normalizes an extension to lowercase."""
    norm_ext = extension.strip(" .").lower()
    if norm_ext == "aif":
        return "aiff"
    if norm_ext == "wave":
        return "wav"
    return norm_ext
