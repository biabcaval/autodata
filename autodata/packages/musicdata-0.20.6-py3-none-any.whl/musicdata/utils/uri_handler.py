"""URI handling utilities using fsspec for unified filesystem access.

This module provides a clean abstraction for reading files from any URI supported by fsspec,
including local files, GCS, S3, HTTP, Azure, and many more protocols.
"""

from typing import Any

import fsspec
from loguru import logger


def read_text_from_uri(uri: str, encoding: str = "utf-8", **kwargs) -> str:
    """Read text content from any URI using fsspec.

    This function always returns text (str) and handles encoding automatically.
    Use this for configuration files, CSV files, JSON, etc.

    Supports all fsspec protocols including:
    - Local files: /path/to/file, file:///path/to/file, ./relative/path
    - GCS: gs://bucket/path/to/file
    - S3: s3://bucket/path/to/file
    - HTTP/HTTPS: https://example.com/file
    - Azure: az://container/path/to/file
    - And many more via fsspec

    Args:
        uri: The URI to read from
        encoding: Text encoding (default: utf-8)
        **kwargs: Additional arguments passed to fsspec.open()

    Returns:
        Text content of the file as string

    Raises:
        FileNotFoundError: If the file doesn't exist
        PermissionError: If access is denied
        UnicodeDecodeError: If encoding fails
    """
    logger.debug(f"Reading text from URI: {uri}")

    try:
        # Use fsspec.open() with text mode and encoding
        with fsspec.open(uri, mode="r", encoding=encoding, **kwargs) as f:
            content = f.read()  # type: ignore[reportAttributeAccessIssue]

            # Ensure we return a string
            if isinstance(content, str):
                return content
            if isinstance(content, bytes):
                return content.decode(encoding)
            return str(content)

    except FileNotFoundError:
        logger.error(f"File not found: {uri}")
        raise
    except PermissionError:
        logger.error(f"Permission denied accessing: {uri}")
        raise
    except UnicodeDecodeError as e:
        logger.error(f"Encoding error reading {uri}: {e}")
        raise
    except Exception as e:
        logger.error(f"Error reading from {uri}: {e}")
        raise


def read_bytes_from_uri(uri: str, **kwargs) -> bytes:
    """Read binary content from any URI using fsspec.

    This function always returns bytes and preserves binary data.
    Use this for images, compressed files, or when you want to handle encoding yourself.

    Supports all fsspec protocols including:
    - Local files: /path/to/file, file:///path/to/file, ./relative/path
    - GCS: gs://bucket/path/to/file
    - S3: s3://bucket/path/to/file
    - HTTP/HTTPS: https://example.com/file
    - Azure: az://container/path/to/file
    - And many more via fsspec

    Args:
        uri: The URI to read from
        **kwargs: Additional arguments passed to fsspec.open()

    Returns:
        Binary content of the file as bytes

    Raises:
        FileNotFoundError: If the file doesn't exist
        PermissionError: If access is denied
    """
    logger.debug(f"Reading bytes from URI: {uri}")

    try:
        # Use fsspec.open() with binary mode
        with fsspec.open(uri, mode="rb", **kwargs) as f:
            content = f.read()  # type: ignore[reportAttributeAccessIssue]

            # Ensure we return bytes
            if isinstance(content, bytes):
                return content
            if isinstance(content, str):
                return content.encode("utf-8")
            # Handle any other type by converting to string then bytes
            return str(content).encode("utf-8")

    except FileNotFoundError:
        logger.error(f"File not found: {uri}")
        raise
    except PermissionError:
        logger.error(f"Permission denied accessing: {uri}")
        raise
    except Exception as e:
        logger.error(f"Error reading from {uri}: {e}")
        raise


def is_remote_uri(uri: str) -> bool:
    """Check if a URI points to a remote resource.

    Args:
        uri: The URI to check

    Returns:
        True if the URI is remote (requires network access), False if it's local
    """
    # Simple and reliable check - this covers the most common cases
    return uri.startswith(("gs://", "s3://", "http://", "https://", "az://", "abfs://", "ftp://", "sftp://"))


def get_protocol_from_uri(uri: str) -> str:
    """Extract the protocol from a URI.

    Args:
        uri: The URI to analyze

    Returns:
        Protocol name (e.g., 'gs', 's3', 'http', 'file')
    """
    if "://" in uri:
        return uri.split("://", 1)[0]
    return "file"  # Local file path


def validate_uri_accessibility(uri: str) -> bool:
    """Check if a URI is accessible without reading its content.

    Args:
        uri: The URI to validate

    Returns:
        True if the URI is accessible, False otherwise
    """
    try:
        # Try to get filesystem info without reading the file
        fs = fsspec.get_filesystem_class(uri)  # noqa: F841
    except Exception as e:  # noqa: BLE001
        logger.debug(f"URI validation failed for {uri}: {e}")
        return False

    return True


def get_supported_protocols() -> list[str]:
    """Get list of supported protocols via fsspec.

    Returns:
        List of supported protocol schemes
    """
    protocols = []
    try:
        # Try to get protocols from registry
        available = fsspec.available_protocols()
        for protocol in available:
            if isinstance(protocol, str):
                protocols.append(protocol)
            elif isinstance(protocol, (list, tuple)):
                protocols.extend(protocol)
    except AttributeError:
        # Fallback if available_protocols() is not available
        protocols = ["file", "local", "gs", "s3", "http", "https", "az", "abfs"]

    return sorted(set(protocols))  # Remove duplicates and sort


def get_uri_info(uri: str) -> dict[str, Any]:
    """Get information about a URI.

    Args:
        uri: The URI to analyze

    Returns:
        Dictionary with URI information including protocol, is_remote, etc.
    """
    return {
        "uri": uri,
        "protocol": get_protocol_from_uri(uri),
        "is_remote": is_remote_uri(uri),
        "is_accessible": validate_uri_accessibility(uri),
    }


def read_from_uri(uri: str, mode: str = "r", encoding: str = "utf-8", **kwargs) -> str | bytes:
    """Read content from any URI using fsspec with flexible return type.

    This is a generic function that returns str for text modes and bytes for binary modes.
    For type-safe usage, prefer read_text_from_uri() or read_bytes_from_uri().

    Args:
        uri: The URI to read from
        mode: File mode - "r" for text, "rb" for binary, etc.
        encoding: Text encoding (used only for text modes)
        **kwargs: Additional arguments passed to fsspec.open()

    Returns:
        str for text modes, bytes for binary modes

    Raises:
        FileNotFoundError: If the file doesn't exist
        PermissionError: If access is denied
        UnicodeDecodeError: If encoding fails (text modes only)
    """
    if mode.startswith("r") and "b" not in mode:
        # Text mode - use read_text_from_uri
        return read_text_from_uri(uri, encoding=encoding, **kwargs)
    # Binary mode - use read_bytes_from_uri
    return read_bytes_from_uri(uri, **kwargs)
