import argparse
from pathlib import Path

import orjson
from loguru import logger


def parse_output_path() -> argparse.Namespace:
    """Parses the output path received from Kubeflow Pipelines."""
    # Defining and parsing the command-line arguments
    parser = argparse.ArgumentParser(description="Parses the output path argument")

    # Path must be passed in, not hardcoded
    parser.add_argument(
        "--output-path",
        type=str,
        default="output/kfp_output",
        help="Path of the local file where the Output data should be written.",
    )
    args = parser.parse_args()
    logger.info(f"Output path is '{args.output_path}'")

    # Creating the directory where the output file has to be written to (the
    # directory may or may not exist).
    Path(args.output_path).parent.mkdir(parents=True, exist_ok=True)

    return args


def write_output(path: str, data: dict) -> None:
    """Stores data in the output file for future utilization by subsequent steps
    in the pipeline.

    The data is available as text in the pipeline, use `orjson.loads()` to parse it.
    There is no need to read the contents of the file because Kubeflow does that
    automatically."""
    with open(path, "wb") as f:
        f.write(orjson.dumps(data))
