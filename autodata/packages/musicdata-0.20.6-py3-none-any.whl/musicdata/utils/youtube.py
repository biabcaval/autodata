import re

import yt_dlp

from musicdata.utils.string import contains_any, normalize_text


# See help(yt_dlp.postprocessor.PostProcessor)
class PathStoragePP(yt_dlp.postprocessor.PostProcessor):
    """Stores the downloaded file path in the `files` attribute.

    Example::

        with yt_dlp.YoutubeDL() as ydl:
            files_pp = PathStoragePP()

            # "when" can take any value in yt_dlp.utils.POSTPROCESS_WHEN
            ydl.add_post_processor(files_pp, when="post_process")
            ydl.download(URLS)

        print(files_pp.file)
        print(files_pp.files)
        print(files_pp.pop())
    """

    def __init__(self):
        super().__init__()
        self._files = []

    def run(self, info):
        self.to_screen(f"Downloaded '{info['filepath']}'")
        self._files.append(info["filepath"])
        return [], info

    @property
    def files(self) -> list[str]:
        return self._files

    @property
    def file(self) -> str | None:
        return self._files[0] if self._files else None

    def clear(self) -> None:
        self._files.clear()

    def pop(self) -> str:
        return self._files.pop()


class YoutubeDL:
    def __init__(self, proxy: str | None = None):
        self.proxy = proxy
        self.ydl_base_opts = {
            "quiet": True,
            "extract_flat": True,
            "format": "best",
            "noplaylist": True,
            "noprogress": True,
            "no_warnings": True,
            "ignoreerrors": True,
            "proxy": self.proxy,
        }

    def search(self, query: str):
        """Searches for a query and returns a list of results.

        Examples::

            yt.search("ytsearchall:ai cover")
            yt.search("ytsearch20:ai cover")
        """
        with yt_dlp.YoutubeDL(self.ydl_base_opts) as ydl:
            search_result = ydl.extract_info(query, download=False, process=False)
            return search_result["entries"]

    def get_audio_opts(self, output_folder: str, codec: str | None = "opus"):
        audio_opts = {
            "format": "bestaudio/best",
            "outtmpl": f"{output_folder}/%(title)s.%(ext)s",
            "postprocessors": [
                {
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": codec,
                },
            ],
        }
        ydl_opts = self.ydl_base_opts.copy()
        ydl_opts.update(audio_opts)
        return ydl_opts


def basic_filter(
    entry: dict,
    contains: list[str] | None = None,
    not_contains: list[str] | None = None,
    ignore_shorts: bool | None = True,
) -> str | None:
    """Filters out shorts, upcoming videos and videos without partial title matches.

    Both `contains` and `not_contains` parameters work by checking if ANY of the strings
    match the title.

    If a more customized filter is required, use this function as a template.
    """
    # Ignore videos without title
    video_title = entry.get("title")
    if not video_title:
        return "Title not found"
    clean_video_title = normalize_text(video_title)

    # Ignore shorts
    if ignore_shorts:
        url = entry.get("url")
        if url and "/shorts/" in url:
            return "Ignore YouTube Shorts"

    # Ignore upcoming
    live_status = entry.get("live_status")
    if live_status and live_status == "is_upcoming":
        return "Video was not released yet"

    # Ignore videos without a match in the title
    if contains:
        if not contains_any(clean_video_title, contains):
            return "Expected text not found in the title"

    # Ignore videos with blacklisted text in the title
    if not_contains:
        if contains_any(clean_video_title, not_contains):
            return "Blacklisted text in the title"

    # Returns None to keep compatibility with `match_filter` parameter of ydl
    # This allows the video to be downloaded
    return None


def filter_entries(entries: list[dict], text_in_title: str):
    return [e for e in entries if basic_filter(e, text_in_title) is None]


def is_valid_youtube_id(youtube_id):
    return bool(re.match(r"^[a-zA-Z0-9_-]{11}$", youtube_id))
