import hashlib
import os
from pathlib import Path
from typing import Any

import orjson
from jwcrypto import jwe, jwk


def load_rsa_public_key_pem(path: Path) -> jwk.JWK:
    pem = path.read_bytes()
    key = jwk.JWK()
    key.import_from_pem(pem)
    return key


def load_rsa_private_key_pem(path: Path, passphrase: str | None = None) -> jwk.JWK:
    pem = path.read_bytes()
    key = jwk.JWK()
    key.import_from_pem(pem, password=(passphrase.encode("utf-8") if passphrase else None))
    return key


def load_rsa_public_key_pem_text(pem_text: str) -> jwk.JWK:
    """Load a public RSA key from PEM content (not a file path)."""
    key = jwk.JWK()
    key.import_from_pem(pem_text.encode("utf-8"))
    return key


def load_rsa_private_key_pem_text(pem_text: str, passphrase: str | None = None) -> jwk.JWK:
    """Load a private RSA key from PEM content (not a file path)."""
    key = jwk.JWK()
    key.import_from_pem(pem_text.encode("utf-8"), password=(passphrase.encode("utf-8") if passphrase else None))
    return key


class JWEEncryptor:
    def __init__(self, public_key: jwk.JWK | None = None, private_key: jwk.JWK | None = None) -> None:
        if public_key is None and private_key is None:
            msg = "At least one key (public_key or private_key) must be provided"
            raise ValueError(msg)

        self._pub = public_key
        self._priv = private_key

    @classmethod
    def from_key_files(
        cls,
        public_key_path: Path | None = None,
        private_key_path: Path | None = None,
        passphrase: str | None = None,
    ) -> "JWEEncryptor":
        pub = load_rsa_public_key_pem(public_key_path) if public_key_path else None
        priv = load_rsa_private_key_pem(private_key_path, passphrase=passphrase) if private_key_path else None
        return cls(public_key=pub, private_key=priv)

    @classmethod
    def from_env(
        cls,
        public_env: str = "ENCRYPTION_PUBLIC_KEY_PATH",
        private_env: str = "ENCRYPTION_PRIVATE_KEY_PATH",
        passphrase_env: str = "ENCRYPTION_PRIVATE_KEY_PASSPHRASE",  # noqa: S107
        *,
        public_env_data: str = "ENCRYPTION_PUBLIC_KEY",
        private_env_data: str = "ENCRYPTION_PRIVATE_KEY",
    ) -> "JWEEncryptor":
        """Create an encryptor from environment variables.

        Resolution order prefers inlined PEM content and falls back to file paths:
        1) If ``public_env_data`` exists, treat it as PEM content for the public key.
           Otherwise, if ``public_env`` exists, treat it as a file system path.
        2) If ``private_env_data`` exists, treat it as PEM content for the private key.
           Otherwise, if ``private_env`` exists, treat it as a file system path.

        The private key passphrase is read from ``passphrase_env`` when present.
        """
        passphrase = os.getenv(passphrase_env)

        # Public key: prefer content env var, then path env var
        pub: jwk.JWK | None = None
        pub_text = os.getenv(public_env_data)
        if pub_text:
            pub = load_rsa_public_key_pem_text(pub_text)
        else:
            pub_path = os.getenv(public_env)
            if pub_path:
                pub = load_rsa_public_key_pem(Path(pub_path))

        # Private key: prefer content env var, then path env var
        priv: jwk.JWK | None = None
        priv_text = os.getenv(private_env_data)
        if priv_text:
            priv = load_rsa_private_key_pem_text(priv_text, passphrase=passphrase)
        else:
            priv_path = os.getenv(private_env)
            if priv_path:
                priv = load_rsa_private_key_pem(Path(priv_path), passphrase=passphrase)

        return cls(public_key=pub, private_key=priv)

    def encrypt_dict(self, data: dict[str, Any]) -> str:
        """
        Encrypt a dictionary and return the JWE JSON string.

        Args:
            data: Dictionary to encrypt

        Returns:
            JWE JSON string
        """
        if self._pub is None:
            msg = "Public key not set"
            raise ValueError(msg)
        plaintext = orjson.dumps(data, option=orjson.OPT_SORT_KEYS)

        protected_header = {"alg": "RSA-OAEP-256", "enc": "A256GCM"}
        token = jwe.JWE(plaintext, protected=orjson.dumps(protected_header).decode("utf-8"))
        token.add_recipient(self._pub)
        return token.serialize(compact=False)

    def encrypt_dict_with_hash(self, data: dict[str, Any]) -> tuple[str, str]:
        """
        Encrypt a dictionary and return both the JWE JSON and SHA256 hash of plaintext.

        This enables fast comparison without decryption by comparing hashes instead.

        Args:
            data: Dictionary to encrypt

        Returns:
            Tuple of (jwe_json, plaintext_hash_hex)
        """
        if self._pub is None:
            msg = "Public key not set"
            raise ValueError(msg)

        plaintext_bytes = orjson.dumps(data, option=orjson.OPT_SORT_KEYS)

        # Compute SHA256 hash of the canonical plaintext for fast comparison
        plaintext_hash = hashlib.sha256(plaintext_bytes).hexdigest()

        # Encrypt the plaintext
        protected_header = {"alg": "RSA-OAEP-256", "enc": "A256GCM"}
        token = jwe.JWE(plaintext_bytes, protected=orjson.dumps(protected_header).decode("utf-8"))
        token.add_recipient(self._pub)
        jwe_json = token.serialize(compact=False)

        return jwe_json, plaintext_hash

    def decrypt_to_dict(self, jwe_json: str) -> dict[str, Any]:
        if self._priv is None:
            msg = "Private key not set"
            raise ValueError(msg)
        token = jwe.JWE()
        token.deserialize(jwe_json)
        token.decrypt(self._priv)
        return orjson.loads(token.payload)


if __name__ == "__main__":
    encryptor = JWEEncryptor.from_key_files(
        public_key_path=Path("pub.pem"),
        private_key_path=Path("priv.pem"),
        passphrase="test-pass",  # noqa: S106
    )
    ciphertext = encryptor.encrypt_dict({"hello": "world"})
    print(ciphertext)
    print(encryptor.decrypt_to_dict(ciphertext))
