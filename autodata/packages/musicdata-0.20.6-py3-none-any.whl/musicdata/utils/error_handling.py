import time
import warnings
from collections.abc import Callable
from functools import wraps
from typing import Any

from loguru import logger


class RetryError(Exception):
    pass


def retry(
    num_retries: int = 3,
    wait_time: float = 1,
    backoff_factor: float | None = None,
    max_wait_time: float | None = None,
    ignored_exceptions: list[type[BaseException]] | None = None,
) -> Callable:
    """
    Retry decorator for functions that may fail.

    DEPRECATED: This decorator is deprecated and will be removed in a future version.
    Use the `stamina` library instead for more robust and feature-rich retry functionality.
    """
    warnings.warn(
        "The retry decorator is deprecated and will be removed in a future version. "
        "Use the `stamina` library instead for more robust and feature-rich retry functionality.",
        DeprecationWarning,
        stacklevel=2,
    )

    if ignored_exceptions is None:
        ignored_exceptions = []

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args: tuple, **kwargs: dict) -> Any:  # noqa: ANN401
            current_wait_time = wait_time
            last_exception = None
            for i in range(num_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    for ignored_exception in ignored_exceptions:
                        if isinstance(e, ignored_exception):
                            raise  # Don't retry for ignored exceptions
                    last_exception = e
                    logger.warning(
                        f"Failed with {e}. Retrying in {current_wait_time} seconds ({i + 1}/{num_retries})...",
                    )
                    time.sleep(current_wait_time)
                    if backoff_factor is not None:
                        current_wait_time *= backoff_factor
                        if max_wait_time is not None:
                            current_wait_time = min(current_wait_time, max_wait_time)

            msg = f"{func.__name__} failed after {num_retries} retries"
            raise RetryError(msg) from last_exception

        return wrapper

    return decorator
