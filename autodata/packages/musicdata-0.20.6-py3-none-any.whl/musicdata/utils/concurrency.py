from enum import Enum
from threading import local

from requests import Session

from musicdata.utils.http_requests import get_session
from musicdata.utils.system import get_effective_cpu_count


class ParallelOperationType(Enum):
    """Types of parallel operations with different resource characteristics."""

    # I/O bound operations that can use more workers than CPU cores
    IO_BOUND = "io_bound"
    # Purely network/API bound operations (no DB, low CPU)
    NETWORK_BOUND = "network_bound"
    # CPU bound operations that should be limited to CPU cores
    CPU_BOUND = "cpu_bound"
    # Database operations that should respect connection pool limits
    DB_INTENSIVE = "db_intensive"
    # Mixed operations with both I/O and database work
    MIXED_IO_DB = "mixed_io_db"


def get_thread_req_session(
    thread_local: local,
    proxy_list: list | dict | None = None,
) -> Session:
    if not hasattr(thread_local, "req_session"):
        thread_local.req_session = get_session(proxy_list)
    return thread_local.req_session


def get_max_workers(
    operation_type: ParallelOperationType,
    item_count: int,
    *,
    db_pool_size: int = 50,
    max_workers_override: int | None = None,
) -> int:
    """
    Calculate optimal number of workers for parallel operations.

    This centralizes worker calculation logic based on:
    - Database connection pool size
    - Operation characteristics (I/O vs CPU vs DB intensive)
    - Number of items to process
    - System resources

    Args:
        operation_type: Type of operation to optimize for
        item_count: Number of items that will be processed
        db_pool_size: Size of the database connection pool (default: 50)
        max_workers_override: Optional override for max workers (for testing/special cases)

    Returns:
        Optimal number of workers for the operation
    """
    if max_workers_override is not None:
        return min(max_workers_override, item_count)

    cpu_count = get_effective_cpu_count()

    # Calculate base workers based on operation type
    if operation_type == ParallelOperationType.NETWORK_BOUND:
        # Pure network operations can use many more threads (4x CPU)
        # and don't need to be constrained by DB pool size
        base_workers = cpu_count * 4
        return min(
            int(base_workers),
            item_count,
            100,  # Reasonable safety cap for network threads
        )
    elif operation_type == ParallelOperationType.IO_BOUND:  # noqa: RET505
        # I/O bound can use more workers than CPU cores
        base_workers = cpu_count * 2
    elif operation_type == ParallelOperationType.CPU_BOUND:
        # CPU bound should be limited to CPU cores
        base_workers = cpu_count
    elif operation_type == ParallelOperationType.DB_INTENSIVE:
        # Database intensive should respect connection pool
        base_workers = max(1, db_pool_size)
    elif operation_type == ParallelOperationType.MIXED_IO_DB:
        # Mixed operations balance I/O and DB constraints
        base_workers = min(cpu_count * 1.5, db_pool_size * 0.8)
    else:
        # Fallback to conservative approach
        base_workers = min(cpu_count, db_pool_size // 2)

    # Apply final constraints
    max_workers = min(
        int(base_workers),
        item_count,  # Never more workers than items
        db_pool_size,  # Never exceed pool size
    )

    return max(1, max_workers)  # Always at least 1 worker
